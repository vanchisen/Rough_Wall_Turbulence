/*
 * proto.h
 *
 * This file conatins function prototypes
 *
 * Started 8/27/94
 * George
 *
 * $Id: proto.h,v 1.1 2004/01/27 23:47:34 ssherw Exp $
 *
 */


/* entrypoint.o */
int PMETIS(int *, int *, int *, int *, int *, int *, int *, int *, int *, int *, int *);
int KMETIS(int *, int *, int *, int *, int *, int *, int *, int *, int *, int *, int *);
int OMETIS(int *, int *, int *, int *, int *, int *, int *);
