//This program transforms Gmsh *.msh to Nektar *.rea file
//Any question please contact with Zhicheng Wang (wangzhicheng09@gmail.com)


//Element and nodes numbers in the input file start from 0 !!!!!!!!!
//For connectivity matrix element numbers srart from 1 !!!!!!!
//There is a HACK for the naca -- 
#include "gmsh2rea.h"

/*** gmsh phsyical boundary***/
/***  1  -> inflow uniform velocity***/
/***  2  -> outflow, adiabatic ***/
/***  3  -> periodic along x direction bottom  ***/
/***  4  -> periodic along x direction top    ***/
/***  5  -> periodic along y direction left  ***/
/***  6  -> periodic along y direction right ***/
/***  7,8,9,10  -> Isothermal wall, Adiabatic, Iso-flux, Robin straight wall ***/
/***  11,12,13,14  ->  correspoding curved walls ***/
/***  15 -> outflow with fixed tempertuare***/
/***  17 -> inflow fixed temperture, prescribed velocity 1***/
/***  18 -> inflow fixed temperture, prescribed velocity 2***/
/***  31  -> velocity periodic, temperature constant 0,  down  border ***/
/***  41  -> velocity periodic, temperature constant 0,  up    border ***/
/***  51  -> velocity periodic, temperature constant 0,  left  border ***/
/***  61  -> velocity periodic, temperature constant 0,  right border ***/
/***  71  -> symmetric boundary ***/ /**velocity and pressure gradients are zero**/

//#define THERMO
//#define CONJUGATE_HEAT

double eps = 1e-6;

void Mesh::Gmsh_Read_Analysis()
{  
  int i,j,ii,jj;
  int va,vb,na,nb,flag;
  char  buf[BUFSIZ];
  char  dummy[BUFSIZ];
  FILE *mshin;


  sprintf(buf, "%s.msh", strtok(session_name, "\n"));
  if((mshin = fopen(buf, "r")) == (FILE*) NULL) {
    fprintf(stderr, "ATTENTION: unable to open the input file -- %s.\n",buf);
    exit(-1);
  }
  else{
    fprintf(stderr, "Reading %s file\n",buf);
  }

  fgets(buf,  BUFSIZ, mshin);

  if(strstr(buf, "$MeshFormt"))
    {
      fprintf(stderr, " We use Gmsh 2.0 only ...");
      exit(-1);
    }

 fgets(dummy,  BUFSIZ, mshin);//skip two lines
 fgets(dummy,  BUFSIZ, mshin);
 fgets(dummy,  BUFSIZ, mshin);

// char *p;
// while(p = fgets(buf, BUFSIZ, mshin))
//   if(strstr(p, 'Nodes'))
//     break;
 
 fgets(buf,  BUFSIZ, mshin);
 sscanf(buf, "%d", &NN);

// fprintf(stdout, "number of nodes = %d  buf = %s \n",NN,buf);
  
  X_node=(double*) calloc(NN,sizeof(double));
  Y_node=(double*) calloc(NN,sizeof(double));

 
// while(p = fgets(buf, BUFSIZ, mshin))
//   if(strstr(p, 'Nodes'))
//     break;
// 
//  fgets(dummy,  BUFSIZ, mshin); // skip one line

  double min_dist = 10e6;
  double Z_node;
  double V_index;
  for(int i=0;i<NN;++i){
    fscanf(mshin, "%lf%lf%lf%lf", &V_index,&X_node[i],&Y_node[i],&Z_node);
//    fprintf(stdout, " x = %f, y = %f \n",X_node[i],Y_node[i]);
    double dist = fabs(sqrt(X_node[i]*X_node[i]+Y_node[i]*Y_node[i])-0.5);
    if(dist<1e-5)
      dist = 10e6;

    min_dist = MIN(dist, min_dist);

    fgets(buf,  BUFSIZ, mshin);
  }

//  fprintf(stdout,"min distance to wall = %lf \n",min_dist);
  //fprintf(stdout,"x1 = %lf x2 = %lf x3 = %lf x4 = %lf \n",X_node[1],X_node[5],X_node[41],X_node[40]);
 // fgets(dummy,  BUFSIZ, mshin);
  
  if(strstr(dummy, "$EndNodes"))
    {
      fprintf(stderr, " We reading...");
      exit(-1);
    }

  fgets(dummy,  BUFSIZ, mshin); // skip "$Elements" 
  fgets(dummy,  BUFSIZ, mshin); // skip "$Elements" 

  int NE_gmsh; //include the boundary element
  fgets(buf,  BUFSIZ, mshin);
  sscanf(buf, "%d", &NE_gmsh);
  
//  fprintf(stdout,"number of elements = %d buf = %s \n", NE_gmsh, buf);

  int elm_num,shape,num_phys,phys1,phys2,node1,node2,node3,node4;
  int NE_boundary = 0;
  for(int i=0; i<NE_gmsh; ++i)
   {
    fgets(buf,  BUFSIZ, mshin);
    sscanf(buf,"%d%d",&elm_num,&shape);
//    fscanf(mshin, "%d%d%d%d%d%d%d%d%d", &elm_num,&shape,&num_phys, &phys1, &phys2, &node1, &node2, &node3, &node4);

    if(shape == 1)
     NE_boundary++;
   }

  NE = NE_gmsh - NE_boundary;
  
  Elmt_Node = (int**) calloc(4,sizeof(int*));
  for(i=0;i<4;++i) Elmt_Node[i]= (int*) calloc(NE,sizeof(int)); 
  
  Elmt_Face = (int**) calloc(NE,sizeof(int*));
  for(i=0;i<NE;++i) Elmt_Face[i]= (int*) calloc(4,sizeof(int));

  Elmt_Elmt = (int**) calloc(NE,sizeof(int*));
  for(i=0;i<NE;++i) Elmt_Elmt[i]= (int*) calloc(4,sizeof(int)); 

  int **Face_Node;
  Face_Node = (int**) calloc(3,sizeof(int*));
  for(i=0;i<3;++i) Face_Node[i]= (int*) calloc(NE_boundary,sizeof(int)); 

#ifdef CONJUGATE_HEAT 
  Elmt_Group = (int*) calloc(NE,sizeof(int));
#endif

  printf("node=%d  element=%d  boundary=%d\n",NN,NE,NE_boundary);

  rewind(mshin);
  findSection("Elements", buf, mshin);

  fgets(buf,  BUFSIZ, mshin);// skip one line

  int element_index = 0, boundary_index = 0;
  for(int k=0; k<NE_boundary; ++k)
  {
//    sscanf(buf,"%d%d",&elm_num,&shape);
    fscanf(mshin, "%d%*c %d%*c %d%*c %d%*c %d%*c %d%*c %d", &elm_num,&shape,&num_phys, &phys1, &phys2, &node1, &node2);
    fgets(buf,  BUFSIZ, mshin);
//    fscanf(infile,"%d%*c %d%*c %d%*c %d",&Elmt_Node[0][i], &Elmt_Node[1][i],&Elmt_Node[2][i],&Elmt_Node[3][i]);
//    fscanf(mshin, "%d%d%d%d%d%d%d%d%d", &elm_num,&shape,&num_phys, &phys1, &phys2, &node1, &node2, &node3, &node4);
//    fgets(buf,  BUFSIZ, mshin);

//    if(shape == 1)
//     {
//      sscanf(buf, "%d%d%d%d%d%d%d", &elm_num,&shape,&num_phys, &phys1, &phys2, &node1, &node2);
      Face_Node[0][k] = phys1;
      Face_Node[1][k] = node1-1;
      Face_Node[2][k] = node2-1;
//      boundary_index++;
//     }
   }
//    else if (shape == 3)
  int num_reorder = 0;
  int tmp;
  PointF v0,v1,v2,v3;
  for(int k=0; k<NE; ++k)
     {
      fscanf(mshin, "%d%*c %d%*c %d%*c %d%*c %d%*c %d%*c %d%*c %d%*c %d", &elm_num,&shape,&num_phys, &phys1, &phys2, &node1, &node2, &node3, &node4);
      fgets(buf,  BUFSIZ, mshin);
      
//      fprintf(stderr,"Need to fix the orientation of quad ! \n");
      Elmt_Node[0][k] = node1-1; 
      Elmt_Node[1][k] = node2-1; 
      Elmt_Node[2][k] = node3-1;
      Elmt_Node[3][k] = node4-1; 

#if 1
      v0.x = X_node[node1-1];
      v0.y = Y_node[node1-1];

      v1.x = X_node[node2-1];
      v1.y = Y_node[node2-1];

      v2.x = X_node[node3-1];
      v2.y = Y_node[node3-1];

      v3.x = X_node[node4-1];
      v3.y = Y_node[node4-1];
    
      double jab =  Jacobian(v0, v1, v2, v3);
    
      if(jab<0.) //reorder
       {
        num_reorder++;
//        fprintf(stdout," Re-order element %d  num = %d \n",k,num_reorder);

        Elmt_Node[0][k] = node4-1; 
        Elmt_Node[1][k] = node3-1; 
        Elmt_Node[2][k] = node2-1; 
        Elmt_Node[3][k] = node1-1;
      }
#endif
//        Elmt_Node[0][k] = node4-1; 
//        Elmt_Node[1][k] = node3-1; 
//        Elmt_Node[2][k] = node2-1; 
//        Elmt_Node[3][k] = node1-1;
//      
//     fprintf(stdout,"elm = %d  node1 = %d node2 = %d node3 = %d node4 = %d \n",element_index,node1,node2,node3,node4);
//      element_index++;
#ifdef CONJUGATE_HEAT
      Elmt_Group[k] = phys1;
#endif
     }
//    else
//     {
//       fprintf(stderr, "We use quadrature mesh only !!!");
//       exit(-1);
//     }
//   }

  for (int i = 0; i < NE; ++i){
 //   fprintf(stdout," set link of element %d \n",i);
    for (int j = 0; j < 4; ++j){
      va = Elmt_Node[j][i];
      vb = Elmt_Node[(j+1)%4][i];
      
      flag = 0;
      for (int ii = 0; ii < NE; ++ii)
	if (ii != i)
	  for (int jj = 0; jj < 4; ++jj){
	    na = Elmt_Node[jj][ii];
	    nb = Elmt_Node[(jj+1)%4][ii];
            if (((va==na)&&(vb==nb))||((va==nb)&&(vb==na))){
	       flag = 1;
               Elmt_Elmt[i][j]=ii;
               Elmt_Face[i][j]=jj;
	    }
	  }
     if (flag==0){
        for (int bii = 0; bii <NE_boundary ; ++bii)
         {
	           na = Face_Node[1][bii];
	           nb = Face_Node[2][bii];
           if (((va==na)&&(vb==nb))||((va==nb)&&(vb==na)))
            {
             Elmt_Elmt[i][j]=-1; 
             Elmt_Face[i][j]=Face_Node[0][bii]; 
            } 
         }
     }//flag=0
    }
  }

  fclose(mshin);   
}



void Mesh::rea_output()
{
  FILE *reaout;
  FILE *curout;
  int i,k,j,s;
  int na,nb,ma,mb;
  int k1,k2; 
  char buf[BUFSIZ];
#ifdef THERMO
  double  hc = 500.;
  double  Ta = 0.0;
//  double  rho_cp_min = 385.*1380.; 
  double  rho_cp_min = 1.127*1005.; //for air 
//  double  rho_cp_min = 1.127*1005; 
  double  robin_coeff = hc/rho_cp_min; 
//  double  kinvis = 1.1942e-4; 
  double  kinvis = 2.3928e-5; 
#endif
  
  sprintf(buf, "%s.rea", strtok(session_name, "\n"));
  if((reaout = fopen(buf, "w")) == (FILE*) NULL) {
    fprintf(stderr, "ATTENTION: unable to open the rea file -- %s.\n",buf);
    exit(-1);
  }
  
  fprintf(reaout,"****** PARAMETERS *****\n");
  fprintf(reaout," Nektar file \n");
  fprintf(reaout," 2 DIMENSIONAL RUN\n");
 #ifdef THERMO
  fprintf(reaout," 10 PARAMETERS FOLLOW\n");
 #else
  fprintf(reaout," 8 PARAMETERS FOLLOW\n");
 #endif
  fprintf(reaout," %g              KINVIS\n",0.01);
 #ifdef THERMO
  fprintf(reaout," 0.71            PRANDTL\n");
  fprintf(reaout," %g              ROBIN_COEFF\n",robin_coeff);
 #endif
  fprintf(reaout," 100001          NSTEPS\n");
  fprintf(reaout," 0.001           DT\n");
  fprintf(reaout," 100             IOSTEP\n");
  fprintf(reaout," 1               EQTYPE\n");
  fprintf(reaout," 2               INTYPE\n");
  fprintf(reaout," 4               MODES\n");
  fprintf(reaout," 100             HISSTEP\n");
  //fprintf(reaout,"   1.                   uvel\n");
  fprintf(reaout," 0  Lines of passive scalar data follows2 CONDUCT; 2RHOCP\n");
  fprintf(reaout," 0  LOGICAL SWITCHES FOLLOW\n");
  fprintf(reaout," Not used \n");
  fprintf(reaout," **MESH DATA** 1st line is X of corner 1,2,3,4. 2nd line is Y.\n");
  fprintf(reaout," %d  %d  %d \n", NE, 2, 1);
  
  // print out elements 
  for (k = 0; k < NE; ++k){
#ifdef CONJUGATE_HEAT
    fprintf (reaout,"Element %d Quad  Group %d \n", k+1,Elmt_Group[k]);
#else
    fprintf (reaout,"Element %d Quad \n", k+1);
#endif
  
    fprintf(reaout,"%lf %lf %lf %lf \n", X_node[Elmt_Node[0][k]],
                                         X_node[Elmt_Node[1][k]],
                                         X_node[Elmt_Node[2][k]],
                                         X_node[Elmt_Node[3][k]]);

    fprintf(reaout,"%lf %lf %lf %lf \n", Y_node[Elmt_Node[0][k]],
                                         Y_node[Elmt_Node[1][k]],
                                         Y_node[Elmt_Node[2][k]],
                                         Y_node[Elmt_Node[3][k]]);
  }
 
  
  fprintf(reaout," ***** CURVED SIDE DATA ***** \n");

  int num_type = 0;
  int num_curved1 = 0;
  int num_curved2 = 0;
  int num_curved3 = 0;
  int num_curved4 = 0;
  int num_curved5 = 0;
  int num_curved6 = 0;
  int num_curved7 = 0;
  int num_curved8 = 0;
  for (k = 0; k < NE; ++k)
   for (i = 0; i < 4; ++i) 
   {
     if ( (Elmt_Face[k][i] == 11) )
        num_curved1++;
     else if ( (Elmt_Face[k][i] == 12) )
        num_curved2++;
     else if ( (Elmt_Face[k][i] == 13) )
        num_curved3++;
     else if ( (Elmt_Face[k][i] == 14) )
        num_curved4++;
     else if ( (Elmt_Face[k][i] == 101) )
        num_curved5++;
     else if ( (Elmt_Face[k][i] == 102) )
        num_curved6++;
     else if ( (Elmt_Face[k][i] == 112) )
        num_curved7++;
     else if ( (Elmt_Face[k][i] == 113) )
        num_curved8++;
   }

  if(num_curved1)
    num_type++;

  if(num_curved2)
    num_type++;

  if(num_curved3)
    num_type++;

  if(num_curved4)
    num_type++;

  if(num_curved5)
    num_type++;

  if(num_curved6)
    num_type++;

  if(num_curved7)
    num_type++;

  if(num_curved8)
    num_type++;

  int num_curved = num_curved1+num_curved2+num_curved3+num_curved4+num_curved5
                   +num_curved6;

  if(num_type >0 )
   {
    fprintf(reaout," %#4d Number of curve types\n",num_type);
    fprintf(reaout," Circle                 \n");
    fprintf(reaout," 0.000000 0.000000 0.50000 a \n");
    fprintf(reaout," %#4d Curved sides follow\n",num_curved);
    
    for (k = 0; k < NE; ++k)
    for (i = 0; i < 4; ++i) 
    {
       if ( (Elmt_Face[k][i] == 11) )
          fprintf (reaout,"%#4d %#4d  a \n", i+1, k+1);
       else if ( (Elmt_Face[k][i] == 12) )
          fprintf (reaout,"%#4d %#4d  b \n", i+1, k+1);
       else if ( (Elmt_Face[k][i] == 13) )
          fprintf (reaout,"%#4d %#4d  c \n", i+1, k+1);
       else if ( (Elmt_Face[k][i] == 14) )
          fprintf (reaout,"%#4d %#4d  d \n", i+1, k+1);
       else if ( (Elmt_Face[k][i] == 101) )
          fprintf (reaout,"%#4d %#4d  e \n", i+1, k+1);
       else if ( (Elmt_Face[k][i] == 102) )
          fprintf (reaout,"%#4d %#4d  f \n", i+1, k+1);
       else if ( (Elmt_Face[k][i] == 112) )
          fprintf (reaout,"%#4d %#4d  g \n", i+1, k+1);
       else if ( (Elmt_Face[k][i] == 113) )
          fprintf (reaout,"%#4d %#4d  h \n", i+1, k+1);
     }
   }
  else
   {
    fprintf(reaout," 0 Number of curve types\n");
   }

  fprintf(reaout," ***** BOUNDARY CONDITIONS ***** \n");
  fprintf(reaout," ***** FLUID BOUNDARY CONDITIONS ***** \n");
  
  int num =0;
  // print out element connectivity 
  for (k = 0; k < NE; ++k){
   for (i = 0; i < 4; ++i) 
   {
      if (Elmt_Elmt[k][i]!=-1)
       {
	      fprintf (reaout," E %#4d %#4d %#4d %#4d\n", k+1, i+1, Elmt_Elmt[k][i]+1, Elmt_Face[k][i]+1);

//        if(k+1 == 3172)
//	      fprintf (stdout," E %#4d %#4d %#4d %#4d\n", k+1, i+1, Elmt_Elmt[k][i]+1, Elmt_Face[k][i]+1);

       }
      else 
      {
        na = Elmt_Node[i][k];
        nb = Elmt_Node[(i+1)%4][k];
       
       if( Elmt_Face[k][i] == 1){
          fprintf (reaout," v %#4d %#4d %#4d %#4d  0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," u = 0.5*(1.0+tanh((RADIUS-abs(y))/DSIGMA))*U_Bulk*1.5*(RADIUS*RADIUS-y^2)/RADIUS/RADIUS\n");
//          fprintf (reaout," u = 0.5*(1.0+tanh((RADIUS-sqrt(y*y+(z-0.5*LZ)^2))/DSIGMA))*U_Bulk*1.5*(RADIUS*RADIUS-y^2-(z-0.5*LZ)^2)/RADIUS/RADIUS\n");
//          fprintf (reaout," u = 16.0*x*x*(1.0-x)*(1.0-x)*(0.5+tanh(8.0*(t-0.5)/2.0))\n");
//          fprintf (reaout," u = 16.0*x*x*(1.0-x)*(1.0-x)\n");
//
//          fprintf (reaout," u = 1.0\n");
//          fprintf (reaout," v = 0.0\n");
//          fprintf (reaout," w = 0.0\n");
//
//          fprintf (reaout," W %#4d %#4d 0.000  0.000\n", k+1, i+1);
          fprintf (reaout," u = (1-step(z,ZSHEAR))*sqrt((z/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)*(z/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)-1.0)/(z/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)*EXP_A*(exp(z/EXP_B+1))+(step(z,ZSHEAR))*(ZA+ZB*z+ZC*z*z+ZD*z*z*z) \n");
          fprintf (reaout," v = 0.0\n");
//          fprintf (reaout," w = 0.0\n");
          fprintf (reaout," w = (1-step(z,ZSHEAR))*1.0/(z/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)*EXP_A*(exp(z/EXP_B+1))+(step(z,ZSHEAR))*(ZA2+ZB2*z+ZC2*z*z+ZD2*z*z*z) \n");
///          fprintf (reaout," u = (1-step2(z,ZSHEAR))*(UMAX+slope1*z)+(step2(z,ZSHEAR))*(slope2*z+UMAX-LZ*slope2) \n");
//          fprintf (reaout," u = (1.-step2(z,ZZ2))*(UMIN+(tanh((ZZ1-z)/ETAZ)+1.)/2.*(UMAX-UMIN))+step2(z,ZZ2)*(UMIN+(tanh((z-ZZ3)/ETAZ)+1.)/2.*(UMAX-UMIN))\n");
#if 0
          fprintf (reaout," v %#4d %#4d %#4d %#4d  0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," u = (1.-step(z,ZZ2))*(UMIN+(tanh((z-ZZ1)/ETAZ)+1.)/2.*(UMAX-UMIN))+step(z,ZZ2)*(UMIN+(tanh((ZZ3-z)/ETAZ)+1.)/2.*(UMAX-UMIN))\n");
//          fprintf (reaout," u = 0.5*(tanh((RADIUS-sqrt((z-LZ/2)*(z-LZ/2)+y*y))/0.00048)+1.)*((1.+tanh(y/sqrt(2)/DSIGMA))*USG+(1.-tanh(y/sqrt(2)/DSIGMA))*USL)*2*(1.-((z-LZ/2)*(z-LZ/2)+y*y)/RADIUS/RADIUS) \n"); 
//          fprintf (reaout," u = 2.0*sin(PI*x)*sin(PI*x)*sin(2*PI*y)*sin(2*PI*z)*cos(PI*t/DPERID) \n");
//          fprintf (reaout," v = -sin(2*PI*x)*sin(PI*y)*sin(PI*y)*sin(2*PI*z)*cos(PI*t/DPERID) \n");
//          fprintf (reaout," w = -sin(2*PI*x)*sin(2*PI*y)*sin(PI*z)*sin(PI*z)*cos(PI*t/DPERID) \n");
#endif
//          fprintf (reaout, "u = DA*cos(a0*x)*cos(b0*y)*cos(c0*z)*sin(W0*t) \n");
//          fprintf (reaout, "v = 0.0 \n");
//          fprintf (reaout, "w = DB*sin(a0*x)*cos(b0*y)*sin(c0*z)*sin(W0*t) \n");
        }
     else if( Elmt_Face[k][i] == 101){
          fprintf (reaout," v %#4d %#4d %#4d %#4d  0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," u = DU_INFTY*cos(DINFLOW_ANGLE)\n");
//          fprintf (reaout," v = DU_INFTY*sin(DINFLOW_ANGLE)\n");
//          fprintf (reaout," u = DU_INFTY*cos(DAOA/180.0*PI*0.5*(sin(2.0*DFREQ*PI*t)+1.0))\n");
//          fprintf (reaout," v = DU_INFTY*sin(DAOA/180.0*PI*0.5*(sin(2.0*DFREQ*PI*t)+1.0))\n");
//          fprintf (reaout," w = 0.0\n");
//          fprintf (reaout," u = ((1-step(z,ZSHEAR))*(UMAX+slope*z)+(step(z,ZSHEAR))*(ZA+ZB*z+ZC*z*z+ZD*z*z*z))*cos(D_theta) \n");

//            fprintf(reaout," u = (1-step(z,ZSHEAR))*sqrt((z*DLCO/ZSHEAR/SCR_B+1.0)*(z*DLCO/ZSHEAR/SCR_B+1.0)-1.0)/(z*DLCO/ZSHEAR/SCR_B+1.0)*((log((z*DLCO/ZSHEAR+DLOG_A)/DLOG_B)+DLOG_C)/DLOG_D)+(step(z,ZSHEAR))*(ZA+ZB*z+ZC*z*z+ZD*z*z*z) \n");
//            fprintf(reaout," v = 0.0 \n");
//            fprintf(reaout," w = (1-step(z,ZSHEAR))*1.0/(z*DLCO/ZSHEAR/SCR_B+1.0)*((log((z*DLCO/ZSHEAR+DLOG_A)/DLOG_B)+DLOG_C)/DLOG_D)+(step(z,ZSHEAR))*(ZA2+ZB2*z+ZC2*z*z+ZD2*z*z*z) \n");

            fprintf(reaout," u = (1-step(z,ZSHEAR))*((log((z*DLCO/ZSHEAR+DLOG_A)/DLOG_B)+DLOG_C)/DLOG_D)+(step(z,ZSHEAR))*(ZA+ZB*z+ZC*z*z+ZD*z*z*z) \n");
            fprintf(reaout," v = 0.0 \n");
            fprintf(reaout," w = (1-step(z,ZSHEAR))*((log((z*DLCO/ZSHEAR+DLOG_A)/DLOG_B)+DLOG_C)/DLOG_D)+(step(z,ZSHEAR))*(ZA2+ZB2*z+ZC2*z*z+ZD2*z*z*z) \n");

//           fprintf (reaout," u = (1.-step2(z,ZZ2))*(UMIN+(tanh((ZZ1-z)/ETAZ)+1.)/2.*(UMAX-UMIN))+step2(z,ZZ2)*(UMIN+(tanh((z-ZZ3)/ETAZ)+1.)/2.*(UMAX-UMIN))\n");
//           fprintf (reaout," v = 0.0 \n");
//           fprintf (reaout," w = 0.0 \n");


//            fprintf(reaout," u = (1-step(z,ZSHEAR))*sqrt((z*DLCO/ZSHEAR/SCR_B+1.0)*(z*DLCO/ZSHEAR/SCR_B+1.0)-1.0)/(z*DLCO/ZSHEAR/SCR_B+1.0)*EXP_A*(exp(z*DLCO/ZSHEAR/EXP_B+1))+(step(z,ZSHEAR))*(ZA+ZB*z+ZC*z*z+ZD*z*z*z) \n");
//            fprintf(reaout," v = 0.0 \n");
//            fprintf(reaout," w = (1-step(z,ZSHEAR))*1.0/(z*DLCO/ZSHEAR/SCR_B+1.0)*EXP_A*(exp(z*DLCO/ZSHEAR/EXP_B+1))+(step(z,ZSHEAR))*(ZA2+ZB2*z+ZC2*z*z+ZD2*z*z*z) \n");


//          fprintf (reaout," v = ((1-step(z,ZSHEAR))*(UMAX+slope*z)+(step(z,ZSHEAR))*(ZA+ZB*z+ZC*z*z+ZD*z*z*z))*sin(D_theta)\n");
//          fprintf (reaout," w = 0.0\n");
//          fprintf (reaout," u = (1-step(z,ZSHEAR))*sqrt((z*DLCO/ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)*(z*DLCO/ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)-1.0)/(z*DLCO/ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)*EXP_A*(exp(z*DLCO/ZSHEAR/EXP_B+1))+(step(z,ZSHEAR))*(ZA+ZB*z+ZC*z*z+ZD*z*z*z) \n");
//          fprintf (reaout," v = 0.0\n");
//          fprintf (reaout," w = (1-step(z,ZSHEAR))*1.0/(z*DLCO/ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)*EXP_A*(exp(z*DLCO/ZSHEAR/EXP_B+1))+(step(z,ZSHEAR))*(ZA2+ZB2*z+ZC2*z*z+ZD2*z*z*z) \n");
//          fprintf (reaout," u = (1-step(z,ZSHEAR))*sqrt((z*((SCR_B+SCR_AMP*sin(SCR_FREQ*t)*cosh(asinh(ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t)))-1)/(log(UMAX_O/UMIN_O*exp(1.0))-1.0))/ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)*(z*((SCR_B+SCR_AMP*sin(SCR_FREQ*t)*cosh(asinh(ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t)))-1)/(log(UMAX_O/UMIN_O*exp(1.0))-1.0))/ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)-1.0)/(z*((SCR_B+SCR_AMP*sin(SCR_FREQ*t)*cosh(asinh(ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t)))-1)/(log(UMAX_O/UMIN_O*exp(1.0))-1.0))/ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)*(UMIN_O/exp(1.0))*(exp(z*((SCR_B+SCR_AMP*sin(SCR_FREQ*t)*cosh(asinh(ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t)))-1)/(log(UMAX_O/UMIN_O*exp(1.0))-1.0))/ZSHEAR/((SCR_B+SCR_AMP*sin(SCR_FREQ*t)*cosh(asinh(ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t)))-1)/(Log(UMAX_O/UMIN_O*exp(1.0))-1.0))+1))+(step(z,ZSHEAR))*(ZA+ZB*z+ZC*z*z+ZD*z*z*z) \n");
//          fprintf (reaout," v = 0.0\n");
//          fprintf (reaout," w = (1-step(z,ZSHEAR))*1.0/(z*((SCR_B+SCR_AMP*sin(SCR_FREQ*t)*cosh(asinh(ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t)))-1)/(log(UMAX_O/UMIN_O*exp(1.0))-1.0))/ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t))+1.0)*(UMIN_O/exp(1.0))*(exp(z*((SCR_B+SCR_AMP*sin(SCR_FREQ*t)*cosh(asinh(ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t)))-1)/(log(UMAX_O/UMIN_O*exp(1.0))-1.0))/ZSHEAR/EXP_B+1))+(step(z,ZSHEAR))*(ZA2+ZB2*z+ZC2*z*z+ZD2*z*z*z) \n");
        }
//  EXP_A     UMIN_O/exp(1.0) 
//  EXP_B     (SCR_B+SCR_AMP*sin(SCR_FREQ*t)*cosh(asinh(ZSHEAR/(SCR_B+SCR_AMP*sin(SCR_FREQ*t)))-1)/(log(UMAX_O/UMIN_O*exp(1.0))-1.0)
        else if ( (Elmt_Face[k][i] == 7) || (Elmt_Face[k][i] == 8) || (Elmt_Face[k][i] == 9) || (Elmt_Face[k][i] == 10) || (Elmt_Face[k][i] == 71) ) {
            fprintf (reaout," W %#4d %#4d 0.000  0.000\n", k+1, i+1);
        }
        else if ( (Elmt_Face[k][i] == 11) || (Elmt_Face[k][i] == 12) || (Elmt_Face[k][i] == 13) || (Elmt_Face[k][i] == 14) ) {
            fprintf (reaout," W %#4d %#4d 0.000  0.000\n", k+1, i+1);
//            fprintf (reaout," O %#4d %#4d 0.000  0.000\n", k+1, i+1);
        }
        else if ( (Elmt_Face[k][i] == 112) ) {
          fprintf (reaout," t %#4d %#4d %#4d %#4d  0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," v %#4d %#4d %#4d %#4d  0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," u = -D_U1*sin(ang(x-DX1,y-DY1))\n");
          fprintf (reaout," v = D_U1*cos(ang(x-DX1,y-DY1))\n");
          fprintf (reaout," w = 0.0\n");
        }
        else if ( (Elmt_Face[k][i] == 113) ) {
          fprintf (reaout," x %#4d %#4d %#4d %#4d  0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," v %#4d %#4d %#4d %#4d  0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," u = -D_U2*sin(ang(x-DX2,y-DY2))\n");
          fprintf (reaout," v = D_U2*cos(ang(x-DX2,y-DY2))\n");
          fprintf (reaout," w = 0.0\n");
        }

//        else if ( (Elmt_Face[k][i] == 3) || (Elmt_Face[k][i] == 4) ){ // periodic boundary along x direction
        else if ( (Elmt_Face[k][i] == 3) || (Elmt_Face[k][i] == 4) 
                  || (Elmt_Face[k][i] == 31) || (Elmt_Face[k][i] == 41) ) //velocity periodic, temperature constant 
        { // periodic boundary along x direction
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
                 if(ii == NE)
                  {
                   fprintf(stderr,"periodic boundary along x, can't find correspnding periodic node for %g %g \n",xv,yv);
                   exit(-1);
                  }
	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( (fabs(xv-xn)<eps)&&(fabs(yv+yn)<eps) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
               }
          }
//        else if ( (Elmt_Face[k][i] == 5) || (Elmt_Face[k][i] == 6) ){ // periodic boundary along y direction
        else if ( (Elmt_Face[k][i] == 5) || (Elmt_Face[k][i] == 6)  // periodic boundary along y direction
                  || (Elmt_Face[k][i] == 51) || (Elmt_Face[k][i] == 61) ) //velocity periodic, temperature constant 
          {
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
//                 if(ii == NE)
//                  {
//                    fprintf(stdout, "error in setting periodic boundary \n");
//                    exit(-1);
//                  }
                   if(ii == NE)
                    {
                     fprintf(stderr,"periodic boundary along y, can't find correspnding periodic node for %g %g \n",xv,yv);
                     exit(-1);
                    }

	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( fabs(xv+xn)<eps )
                 {
                  if ( fabs(yv-yn)<eps )
//                 if ( (fabs(xv+xn)<eps)&&(fabs(yv-yn)<eps) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
//                    fprintf (stderr," E %#4d %#4d %#4d %#4d %g %g %g %g %g\n", k+1, i+1, ii+1, jj+1,xv,yv,xn,yn,fabs(yv-yn));
                 }
               }

          }

        else if ( (Elmt_Face[k][i] == 2) || (Elmt_Face[k][i] == 15) || (Elmt_Face[k][i] == 102))// outflow boundary
         {

          fprintf (reaout," O %#4d %#4d 0.000  0.000\n", k+1, i+1);
         }
        else if( Elmt_Face[k][i] == 17){
          fprintf (reaout," v %#4d %#4d %#4d %#4d  0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," u = 0.0 \n");
          fprintf (reaout," v = 0.5*(tanh((DRADIUS_INFLOW-sqrt((z-0.5*LZ)^2+(x-7.25)^2))/INTERF_THICK)+1.)*0.2*(1.-((x-7.25)^2+(z-0.5*LZ)^2))/DRADIUS_INFLOW/DRADIUS_INFLOW \n"); //negative y direction is into the domain
          fprintf (reaout," w = 0.0 \n");
        }
        else if( Elmt_Face[k][i] == 18){
          fprintf (reaout," v %#4d %#4d %#4d %#4d  0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," u = 0.2*(y-0.1778)*(y-0.3556)/0.0889/0.0889 \n");
          fprintf (reaout," u = 1.0 \n");
          fprintf (reaout," v = 0.0 \n");
          fprintf (reaout," w = 0.0 \n");
        }
        else if ( (Elmt_Face[k][i] == 71) )// outflow boundary
         {

          fprintf (reaout," K %#4d %#4d 0.000  0.000\n", k+1, i+1);
         }
        else
         {
           fprintf(stderr, "Fluid boundary element %d face %d  physical ID = %d Not Implemented Yet \n",k+1,i+1,Elmt_Face[k][i]);
           exit(-1);
         }

      }
    }
  }
   fprintf(stdout," %d periodic boundary edges have been found ... \n",num);
 
 #ifdef PHASEFIELD
  fprintf(reaout," ***** PHASE FIELD BOUNDARY CONDITIONS *****\n");

  for (k = 0; k < NE; ++k){
   for (i = 0; i < 4; ++i) 
   {
      if (Elmt_Elmt[k][i]!=-1)
	      fprintf (reaout," E %#4d %#4d %#4d %#4d\n", k+1, i+1, Elmt_Elmt[k][i]+1, Elmt_Face[k][i]+1);
      else 
      {
        na = Elmt_Node[i][k];
        nb = Elmt_Node[(i+1)%4][k];

       if( (Elmt_Face[k][i] == 2) || (Elmt_Face[k][i] == 71) ) // outflow boundary for thermal equ
         {
           fprintf (reaout," G %#4d %#4d  0.000  0.000\n", k+1, i+1);
//           fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
//           fprintf (reaout," t = -1 \n");
         }

        else if ( (Elmt_Face[k][i] == 3) || (Elmt_Face[k][i] == 4) ){ // periodic boundary along x direction
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
                 if(ii == NE)
                  {
                    fprintf(stdout, "error in setting periodic boundary \n");
                    exit(-1);
                  }
	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( (fabs(xv-xn)<1e-6)&&(fabs(yv+yn)<1e-6) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
               }
          }
        else if ( (Elmt_Face[k][i] == 5) || (Elmt_Face[k][i] == 6) ){ // periodic boundary along y direction
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
                 if(ii == NE)
                  {
                    fprintf(stdout, "error in setting periodic boundary \n");
                    exit(-1);
                  }
	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( (fabs(xv+xn)<1e-6)&&(fabs(yv-yn)<1e-6) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
               }
          }
       else {
           fprintf (reaout," G %#4d %#4d  0.000  0.000\n", k+1, i+1);
        }
      }
   }
  }

 #endif


 #ifdef THERMO
  fprintf(reaout," ***** THERMAL BOUNDARY CONDITIONS *****\n");

  for (k = 0; k < NE; ++k){
   for (i = 0; i < 4; ++i) 
   {
      if (Elmt_Elmt[k][i]!=-1)
	      fprintf (reaout," E %#4d %#4d %#4d %#4d\n", k+1, i+1, Elmt_Elmt[k][i]+1, Elmt_Face[k][i]+1);
      else 
      {
        na = Elmt_Node[i][k];
        nb = Elmt_Node[(i+1)%4][k];
       
       if( ( Elmt_Face[k][i] == 1) || (Elmt_Face[k][i] == 31) || (Elmt_Face[k][i] == 41) || (Elmt_Face[k][i] == 51) || (Elmt_Face[k][i] == 61) ){ //periodic 
//          fprintf (reaout," V %#4d %#4d  0.000  0.000  0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = 0.0 \n");
//          fprintf (reaout," t = bump2(y,8,-2.1651,2.1651)\n");
//          fprintf (reaout," t = DSATURATION_TEMP \n");
        }
       else if(Elmt_Face[k][i] == 101) {
            double  theta = M_PI/3.0;
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            double LY = 2.5*sin(theta);
            double dy = LY/16.0;
            
            int bump_index = floor((yv+LY+dy*0.5)/dy);

            if( bump_index%2 == 0)
             {
              fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
              fprintf (reaout," t = 0.0 \n");
             }
           else
            {
              fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
              fprintf (reaout," t = 1.0 \n");
            }
//          fprintf (reaout," V %#4d %#4d  0.000  0.000  0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," t = 0.0 \n");
//          fprintf (reaout," t = bump2(y,8,-2.1651,2.1651)\n");
//          fprintf (reaout," t = DSATURATION_TEMP \n");
        }
        else if ( Elmt_Face[k][i] == 18) {// inflow 
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," t = 1.0 \n");
          fprintf (reaout," t = 1.0+sin(2.0*3.1415926535*9.0*y) \n");
         }
        else if ( Elmt_Face[k][i] == 7) {// straight isothermal wall boundary 
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = DWALL_TEMP \n");
//          fprintf (reaout," O %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
         }
        else if ( Elmt_Face[k][i] == 71) {// straight isothermal wall boundary 
        //  fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
        //  fprintf (reaout," t = DWALL_TEMP1 \n");
          fprintf (reaout," O %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
         }
        

        else if ( Elmt_Face[k][i] == 8 ){// straight adiabatic  wall
          fprintf (reaout," O %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
        }
        else if ( Elmt_Face[k][i] == 9 ){// straight const flux  wall
          fprintf (reaout," F %#4d %#4d   DWALL_FLUX 0.000 0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," V %#4d %#4d  318 0.000 0.000\n", k+1, i+1, 0, 0);
        }
        else if ( Elmt_Face[k][i] == 10 ){// straight adiabatic  wall
          fprintf (reaout," R %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," h       = %.4f \n",hc);
          fprintf (reaout," T_infty = %.4f \n",Ta);
          fprintf (reaout," sigma   = %.4f \n", robin_coeff/kinvis);
        }
        else if ( Elmt_Face[k][i] == 11 ){// curved isothermal wall
          fprintf (reaout," O %#4d %#4d  0.000  0.000\n", k+1, i+1);
//          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," t = 1.0 \n");
//          fprintf (reaout," t = DWALL_TEMP*0.5*(1.0+cos(DNUM_WAVES*ang(x,y))) \n");
        }
        else if ( Elmt_Face[k][i] == 12 ){// curved adiabatic wall
          fprintf (reaout," O %#4d %#4d  0.000  0.000\n", k+1, i+1);
//          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," t = 1.0 \n");
        }
 //       else if ( Elmt_Face[k][i] == 112 ){// curved adiabatic wall
//          fprintf (reaout," O %#4d %#4d  0.000  0.000\n", k+1, i+1);
//          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," t = DWALL_TEMP*0.5*(1.0+cos(DNUM_WAVES*ang(x,y))) \n");
//        }
        else if ( Elmt_Face[k][i] == 13 ){// iso_flux curved wall
          fprintf (reaout," F %#4d %#4d  1.0  0.000 0.000\n", k+1, i+1);
        }
        else if ( ( Elmt_Face[k][i] == 14 ) || ( Elmt_Face[k][i] == 112 ) ||( Elmt_Face[k][i] == 113 ) ) {// curved adiabatic  wall
          fprintf (reaout," O %#4d %#4d  0.000  0.000\n", k+1, i+1);
//          fprintf (reaout," R %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," h       = %.4f \n",hc);
//          fprintf (reaout," T_infty = %.4f \n",Ta);
//          fprintf (reaout," sigma   = %.4f \n", robin_coeff/kinvis);
        }

        else if ( (Elmt_Face[k][i] == 3) || (Elmt_Face[k][i] == 4) ){ // periodic boundary along x direction
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
                 if(ii == NE)
                  {
                    fprintf(stdout, "error in setting periodic boundary \n");
                    exit(-1);
                  }
	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( (fabs(xv-xn)<1e-6)&&(fabs(yv+yn)<1e-6) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
               }
          }
        else if ( (Elmt_Face[k][i] == 5) || (Elmt_Face[k][i] == 6) ){ // periodic boundary along y direction
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
                 if(ii == NE)
                  {
                    fprintf(stdout, "error in setting periodic boundary \n");
                    exit(-1);
                  }
	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( (fabs(xv+xn)<1e-6)&&(fabs(yv-yn)<1e-6) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
               }
          }

        else if ( Elmt_Face[k][i] == 2) // outflow boundary for thermal equ
         {
           fprintf (reaout," O %#4d %#4d  0.000  0.000\n", k+1, i+1);
         }
        else if (Elmt_Face[k][i] == 15) // outflow boundary but temperature is fixed
         {
//          fprintf (reaout," V %#4d %#4d  0.000  0.000  0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = 0.0 \n");
//           fprintf (reaout," V %#4d %#4d 0.000 0.000 0.000\n", k+1, i+1, 0, 0);
         }
        else if (Elmt_Face[k][i] == 17) // inflow boundary but temperature is fixed
         {
          fprintf (reaout," V %#4d %#4d  308  0.000  0.000\n", k+1, i+1, 0, 0);
//           fprintf (reaout," V %#4d %#4d 0.000 0.000 0.000\n", k+1, i+1, 0, 0);
         }
        else
         {
           fprintf(stderr, "Elmt_Face[k][i] = %d Not Implemented Yet in thermal \n",Elmt_Face[k][i]);
           exit(-1);
         }

      }
    }
  }

 #else
  fprintf(reaout," ***** NO THERMAL BOUNDARY CONDITIONS *****\n");
 #endif

 #ifdef ELECTRO_FLUID
  fprintf(reaout," ***** ELECTRIC POTENTIAL *****\n");

  for (k = 0; k < NE; ++k){
   for (i = 0; i < 4; ++i) 
   {
      if (Elmt_Elmt[k][i]!=-1)
	      fprintf (reaout," E %#4d %#4d %#4d %#4d\n", k+1, i+1, Elmt_Elmt[k][i]+1, Elmt_Face[k][i]+1);
      else 
      {
        na = Elmt_Node[i][k];
        nb = Elmt_Node[(i+1)%4][k];
       
       if( Elmt_Face[k][i] == 1) {
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = 0.0 \n");
        }
       else if ( Elmt_Face[k][i] == 7) {// straight isothermal wall boundary 
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = DHIGH_POTENTIAL+DELTA_POTENTIAL*sin(DOMEGA_POTENTIAL*t) \n");
//          fprintf (reaout," t = DHIGH_POTENTIAL \n");
         }
       else if ( Elmt_Face[k][i] == 8 ){// straight adiabatic  wall
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = DLOW_POTENTIAL \n");
        }
       else if ( Elmt_Face[k][i] == 9 ){// straight const flux  wall
          fprintf (reaout," F %#4d %#4d   1. 0.000 0.000\n", k+1, i+1, 0, 0);
        }
       else if ( Elmt_Face[k][i] == 10 ){// straight adiabatic  wall
          fprintf (reaout," F %#4d %#4d   1. 0.000 0.000\n", k+1, i+1, 0, 0);
        }
       else if ( Elmt_Face[k][i] == 11 ){// curved isothermal wall
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = 1.0 \n");
        }
        else if ( Elmt_Face[k][i] == 12 ){// curved adiabatic wall
          fprintf (reaout," O %#4d %#4d  0.000  0.000\n", k+1, i+1);
        }
       else if ( Elmt_Face[k][i] == 13 ){// iso_flux curved wall
          fprintf (reaout," F %#4d %#4d  1.0  0.000 0.000\n", k+1, i+1);
        }
       else if ( Elmt_Face[k][i] == 14 ){// curved adiabatic  wall
          fprintf (reaout," O %#4d %#4d  0.000  0.000\n", k+1, i+1);
        }

        else if ( (Elmt_Face[k][i] == 3) || (Elmt_Face[k][i] == 4) ){ // periodic boundary along x direction
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
                 if(ii == NE)
                  {
                    fprintf(stdout, "error in setting periodic boundary \n");
                    exit(-1);
                  }
	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( (fabs(xv-xn)<1e-6)&&(fabs(yv+yn)<1e-6) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
               }
          }
        else if ( (Elmt_Face[k][i] == 5) || (Elmt_Face[k][i] == 6) ){ // periodic boundary along y direction
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
                 if(ii == NE)
                  {
                    fprintf(stdout, "error in setting periodic boundary \n");
                    exit(-1);
                  }
	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( (fabs(xv+xn)<1e-6)&&(fabs(yv-yn)<1e-6) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
               }
          }
        else
         {
           fprintf(stderr, "Elmt_Face[k][i] = %d Not Implemented Yet in thermal \n",Elmt_Face[k][i]);
           exit(-1);
         }

      }
    }
  }

  fprintf(reaout," ***** CATIONS CONCENTRATION *****\n");

  for (k = 0; k < NE; ++k){
   for (i = 0; i < 4; ++i) 
   {
      if (Elmt_Elmt[k][i]!=-1)
	      fprintf (reaout," E %#4d %#4d %#4d %#4d\n", k+1, i+1, Elmt_Elmt[k][i]+1, Elmt_Face[k][i]+1);
      else 
      {
        na = Elmt_Node[i][k];
        nb = Elmt_Node[(i+1)%4][k];
       
       if( Elmt_Face[k][i] == 1) {
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = 0.0 \n");
        }
       else if (  Elmt_Face[k][i] == 7) {// straight isothermal wall boundary 
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," t = DLOW_C_PLUS \n");
          fprintf (reaout," t = 1.0 \n");
         }
       else if ( Elmt_Face[k][i] == 8 ){// straight adiabatic  wall
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
//          fprintf (reaout," t = DHIGH_C_PLUS \n");
          fprintf (reaout," t = 2.0 \n");
        }
       else if ( Elmt_Face[k][i] == 9 ){// straight const flux  wall
          fprintf (reaout," F %#4d %#4d   1. 0.000 0.000\n", k+1, i+1, 0, 0);
        }
       else if ( Elmt_Face[k][i] == 10 ){// straight adiabatic  wall
          fprintf (reaout," F %#4d %#4d   1. 0.000 0.000\n", k+1, i+1, 0, 0);
        }
       else if ( Elmt_Face[k][i] == 11 ){// curved isothermal wall
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = 1.0 \n");
        }
        else if ( Elmt_Face[k][i] == 12 ){// curved adiabatic wall
          fprintf (reaout," O %#4d %#4d  0.000  0.000\n", k+1, i+1);
        }
       else if ( Elmt_Face[k][i] == 13 ){// iso_flux curved wall
          fprintf (reaout," F %#4d %#4d  1.0  0.000 0.000\n", k+1, i+1);
        }
       else if ( Elmt_Face[k][i] == 14 ){// curved adiabatic  wall
          fprintf (reaout," O %#4d %#4d  0.000  0.000\n", k+1, i+1);
        }

        else if ( (Elmt_Face[k][i] == 3) || (Elmt_Face[k][i] == 4) ){ // periodic boundary along x direction
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
                 if(ii == NE)
                  {
                    fprintf(stdout, "error in setting periodic boundary \n");
                    exit(-1);
                  }
	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( (fabs(xv-xn)<1e-6)&&(fabs(yv+yn)<1e-6) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
               }
          }
        else if ( (Elmt_Face[k][i] == 5) || (Elmt_Face[k][i] == 6) ){ // periodic boundary along y direction
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
                 if(ii == NE)
                  {
                    fprintf(stdout, "error in setting periodic boundary \n");
                    exit(-1);
                  }
	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( (fabs(xv+xn)<1e-6)&&(fabs(yv-yn)<1e-6) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
               }
          }
        else
         {
           fprintf(stderr, "Elmt_Face[k][i] = %d Not Implemented Yet in thermal \n",Elmt_Face[k][i]);
           exit(-1);
         }

      }
    }
  }


  fprintf(reaout," ***** ANIONS CONCENTRATION *****\n");

  for (k = 0; k < NE; ++k){
   for (i = 0; i < 4; ++i) 
   {
      if (Elmt_Elmt[k][i]!=-1)
	      fprintf (reaout," E %#4d %#4d %#4d %#4d\n", k+1, i+1, Elmt_Elmt[k][i]+1, Elmt_Face[k][i]+1);
      else 
      {
        na = Elmt_Node[i][k];
        nb = Elmt_Node[(i+1)%4][k];
       
       if( Elmt_Face[k][i] == 1) {
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = 0.0 \n");
        }
       else if ( Elmt_Face[k][i] == 7) {// straight isothermal wall boundary 
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = 1.0 \n");
//          fprintf (reaout," O %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
         }
       else if ( Elmt_Face[k][i] == 8 ){// straight adiabatic  wall
          fprintf (reaout," O %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
        }
       else if ( Elmt_Face[k][i] == 9 ){// straight const flux  wall
          fprintf (reaout," F %#4d %#4d   1. 0.000 0.000\n", k+1, i+1, 0, 0);
        }
       else if ( Elmt_Face[k][i] == 10 ){// straight adiabatic  wall
          fprintf (reaout," F %#4d %#4d   1. 0.000 0.000\n", k+1, i+1, 0, 0);
        }
       else if ( Elmt_Face[k][i] == 11 ){// curved isothermal wall
          fprintf (reaout," v %#4d %#4d  0.000 0.000 0.000\n", k+1, i+1, 0, 0);
          fprintf (reaout," t = 1.0 \n");
        }
        else if ( Elmt_Face[k][i] == 12 ){// curved adiabatic wall
          fprintf (reaout," O %#4d %#4d  0.000  0.000\n", k+1, i+1);
        }
       else if ( Elmt_Face[k][i] == 13 ){// iso_flux curved wall
          fprintf (reaout," F %#4d %#4d  1.0  0.000 0.000\n", k+1, i+1);
        }
       else if ( Elmt_Face[k][i] == 14 ){// curved adiabatic  wall
          fprintf (reaout," O %#4d %#4d  0.000  0.000\n", k+1, i+1);
        }

        else if ( (Elmt_Face[k][i] == 3) || (Elmt_Face[k][i] == 4) ){ // periodic boundary along x direction
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
                 if(ii == NE)
                  {
                    fprintf(stdout, "error in setting periodic boundary \n");
                    exit(-1);
                  }
	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( (fabs(xv-xn)<1e-6)&&(fabs(yv+yn)<1e-6) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
               }
          }
        else if ( (Elmt_Face[k][i] == 5) || (Elmt_Face[k][i] == 6) ){ // periodic boundary along y direction
            double xv = 0.5*(X_node[na]+X_node[nb]);
            double yv = 0.5*(Y_node[na]+Y_node[nb]);
            for (int ii = 0; ii <NE ; ++ii)
              if(ii != k)
	            for (int jj = 0; jj < 4; ++jj)
               {
                 if(ii == NE)
                  {
                    fprintf(stdout, "error in setting periodic boundary \n");
                    exit(-1);
                  }
	               int va = Elmt_Node[jj][ii];
	               int vb = Elmt_Node[(jj+1)%4][ii];
                 double xn = 0.5*(X_node[va]+X_node[vb]);
                 double yn = 0.5*(Y_node[va]+Y_node[vb]);
                 if ( (fabs(xv+xn)<1e-6)&&(fabs(yv-yn)<1e-6) )
                   {
                    num++;
                    fprintf (reaout," E %#4d %#4d %#4d %#4d \n", k+1, i+1, ii+1, jj+1);
                   }
               }
          }
        else
         {
           fprintf(stderr, "Elmt_Face[k][i] = %d Not Implemented Yet in thermal \n",Elmt_Face[k][i]);
           exit(-1);
         }

      }
    }
  }
#endif

 #ifdef THERMO
  fprintf(reaout," 5         INITIAL CONDITIONS *****\n");
 #else
  fprintf(reaout," 4         INITIAL CONDITIONS *****\n");
 #endif
  fprintf(reaout," Given \n");
  fprintf(reaout," u = 0.0 \n");
  fprintf(reaout," v = 0.0 \n");
  fprintf(reaout," w = 0.0 \n");
 #ifdef THERMO
  fprintf(reaout," t = 0.0 \n");
 #endif
  fprintf(reaout," ***** DRIVE FORCE DATA ***** PRESSURE GRAD, FLOW, Q\n");
 #ifdef THERMO
  fprintf(reaout," 4                 Lines of Drive force data follow\n");
 #else
  fprintf(reaout," 3                 Lines of Drive force data follow\n");
 #endif
  fprintf(reaout," FFX = 0 \n");
  fprintf(reaout," FFY = 0 \n");
  fprintf(reaout," FFZ = 0 \n");
 #ifdef THERMO
  fprintf(reaout," FFT = 0 \n");
 #endif
  fprintf(reaout," ***** Variable Property Data ***** Overrrides Parameter data.\n");
  fprintf(reaout," 1 Lines follow.\n");
  fprintf(reaout," 0 PACKETS OF DATA FOLLOW\n");
  fprintf(reaout," ***** HISTORY AND INTEGRAL DATA *****\n");
  fprintf(reaout," 0   POINTS.  Hcode, I,J,H,IEL\n");
  fclose(reaout);
}


int main () {
  Mesh *mesh = new Mesh();
  
  fprintf(stderr, "++++++++++++++++++++\n"); 
  fprintf(stderr,"Gmsh 2D -> NEKTAR 2D\n");
  
//  char *buf = (char*) calloc(BUFSIZ,sizeof(char));
//  fgets(mesh->session_name,);
//  sprintf(mesh->session_name, "rect_cables_new1");
//  sprintf(mesh->session_name, "cyl_spm_2d_new");
  fprintf(stderr, "Enter project name: "); 
  fgets(mesh->session_name, BUFSIZ, stdin);
  
  mesh->Gmsh_Read_Analysis();
  
  mesh->rea_output();

  }
