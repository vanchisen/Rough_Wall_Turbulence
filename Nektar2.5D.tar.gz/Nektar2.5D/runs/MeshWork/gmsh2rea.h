#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <math.h>

class Mesh{
  private:
  int NN;
  int NE;
  double *X_node,*Y_node;
  int **Elmt_Node, **Elmt_Face, **Elmt_Elmt, *Face_Node;
  int *Elmt_Group;
  public:
  Mesh(){
  NN = 0; NE=0;
  };
  char session_name[BUFSIZ];
  void Gmsh_Read_Analysis();
  void rea_output();
  ~Mesh(){};
};

static char *findSection (char *name, char *buf, FILE *fp){
  char *p;
  while (p = fgets (buf, BUFSIZ, fp))
    if (strstr (p, name))
      break;
  return p;
};

struct PointF{
  double x;
  double y;
};


double CrossProductZ(const PointF &a, const PointF &b)
{
  return a.x *b.y - a.y*b.x;
}

double Orientation(const PointF &a, const PointF &b, const PointF &c)
{ 
  return CrossProductZ(a,b)+CrossProductZ(b,c)+CrossProductZ(c,a);
}

double Jacobian(const PointF &v0, const PointF &v1, const PointF &v2, const PointF &v3){

  //returns the Jacobian for 4 given vertices
  double xr = (v1.x - v0.x)/2.;
  double yr = (v1.y - v0.y)/2.;
  
  double xs = (v2.x - v0.x)/2.;
  double ys = (v2.y - v0.y)/2.;
  
  return xr*ys-xs*yr;
};

#define MAX(a,b) ((a) > (b) ? a : b)
#define MIN(a,b) ((a) < (b) ? a : b)



