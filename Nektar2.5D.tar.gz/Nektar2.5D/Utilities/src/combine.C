/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/combine.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <nektarF.h>
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
//static char  usage_[128];

char *prog   = "combine";
char *usage  = "combine: [options] -l val1 -s val2 -m file1.fld file2[.fld]\n";
char *author = "";
char *rcsid  = "";
char *help   = 
"-l val1   ... the scaling value (default 1)\n"
"-s val2   ... the scaling value (default 0)\n"
" output: val1*file1 + val2*file2\n";

/* ---------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f);
static Field *sortHeaders(Field *fld,int nfld);
int readHeaderF(FILE* fp, Field *f);
int writeFieldF (FILE *fp, Field *f, Element *E);

main (int argc, char *argv[]){
  register  int i;
  Field     fld, fld1, *fout;
  FileList  f;
  FILE      *fp,*fp1;
  char      fname[BUFSIZ], tmpname[BUFSIZ], syscall[BUFSIZ];
  int       nfields, dlen;
  double    val1,val2,**u;
  int       nf1,n,m,nz;
  int       dump=0;
  Element_List **U;

  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);
  

  memset(&fld , '\0', sizeof (Field));
  memset(&fld1, '\0', sizeof (Field));

#ifdef DEBUG
  debug_out = stdout;
#endif

  val1 = dparam("Val1");
  val2 = dparam("Val2");
  
  fprintf(stderr,"I get here 0 \n");

  sprintf(fname,"%s",f.mesh.name);
  if((fp = fopen(fname,"r")) == (FILE *) NULL){
    sprintf(fname,"%s.fld",f.mesh.name);
    if((fp = fopen(fname,"r")) == (FILE *) NULL){
      fprintf(stderr,"%s: unable to open the input file -- "
	      "%s or  %s.fld \n",prog,f.mesh.name,f.mesh.name);
      exit(1);
    }
  }
 
  fprintf(stderr,"I get here 01 \n");

  dump = readHeaderF (f.in.fp, &fld);
  U = (Element_List **) malloc((nfields = strlen(fld.type))*sizeof(Element_List *));
//  readField  (fp, &fld);
  readFieldF(fp, &fld, U[0]);

  fprintf(stderr,"I get here 1 \n");
  
  sprintf(fname,"%s",f.in.name);
  if((fp1 = fopen(fname,"r")) == (FILE *) NULL){
    sprintf(fname,"%s.fld",f.in.name);
    if((fp1 = fopen(fname,"r")) == (FILE *) NULL){
      fprintf(stderr,"%s: unable to open the input file -- "
	      "%s or  %s.fld \n",prog,f.in.name,f.in.name);
      exit(1);
    }
  }
//  readField (fp1, &fld1);
  readFieldF(fp1, &fld1, U[0]);
  
  fprintf(stderr,"I get here 2 \n");

  dlen = data_len(fld1.nel,fld1.size,fld1.nfacet, fld1.dim);
  nfields = (int) strlen (fld1.type);
  
  if((fld1.nz > 2)||(fld.nz > 2))
    {fprintf(stderr,"Expected field nz <= 2\n"); exit(1);}
  
  if(!fld1.nfacet) {fprintf(stderr,"fld1 does not have a facet length defined"
			      "probably due to and old file input "
			      "format: Needs fixing"); exit(1);}

  // reset number of planes to be 4
  nz = 4;
  
  u = dmatrix(0,nfields-1,0,nz*dlen-1);    
  dzero(nfields*nz*dlen,u[0],1);
  
  nf1 = (int) strlen(fld.type);

  // copy in data from fld
  for(n = 0; n < nfields; ++n){
    // put first field into first two dumps
    for(m = 0; m < nf1; ++m)
      if(fld.type[m] == fld1.type[n])
	dsmul(fld.nz*dlen, val1, fld.data[m], 1, u[n], 1);
    
    // fld1 data, remember different part of second mode for w
    if (n==2&&(fld1.nz == 1))
      dsmul(fld1.nz*dlen, val2, fld1.data[n], 1, u[n]+3*dlen, 1);
    else
      dsmul(fld1.nz*dlen, val2, fld1.data[n], 1, u[n]+2*dlen, 1);

    // free up data in fld1.data
    if(fld1.data[n]) free(fld1.data[n]);
    // set fld1 to u[n]
    fld1.data[n] = u[n];
  }

  fld1.nz = nz; 
//  writeFieldF(f.out.fp,&fld1);

  writeFieldF(f.out.fp, &fld1,U[0]->fhead);

  return 0;
}


/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f){
  char  c;
  
  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }
  
  iparam_set("Dump", 0);
  
  while (--argc && (*++argv)[0] == '-') {
    while (c = *++argv[0])                  /* more to parse... */
      switch (c) {
      case 'l':
	if (*++argv[0]) 
	  dparam_set("Val1", atof(*argv));
	else {
	  dparam_set("Val1", atof(*++argv));
	  argc--;
	}
	(*argv)[1] = '\0';
	break;
      case 's':
	if (*++argv[0]) 
	  dparam_set("Val2", atof(*argv));
	else {
	  dparam_set("Val2", atof(*++argv));
	  argc--;
	}
	(*argv)[1] = '\0';
	break;
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }
  f->in.name = strdup(*argv);
  /* open input file */

  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }
  
  return;
}
