#include <stdio.h>
#include <stdarg.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <polylib.h>
#include "veclib.h"
#include "hotel.h"
#include "nekstruct.h"
#include "Tri.h"
#include "Quad.h"
#include "nektarF.h"
// ce107
#ifndef OLDFFTS
#include <rfftw.h>
static rfftw_plan rplan, rplan_inv;
static rfftw_plan rplan32, rplan_inv32;
#endif

Element *ee;

#define WARN fprintf(stderr,"Call to void Element function\n");
#define Eloop(E) for(ee=E;ee;ee=ee->next)
#define Zloop(i) for(i = 0; i < nz; ++i)

Fourier_List::Fourier_List(){
  fhead   = (Element*)NULL;
  nel     = 0;
  hjtot   = 0;
  htot    = 0;
  base_h  = (double *)0;
  base_hj = (double *)0;
  
  nz      = 1;
  nztot   = 1;
  flevels = (Element_List**)NULL;
}

Fourier_List::Fourier_List(Element **hea, int n){
  flist  = hea;
  fhead  = *hea;
  nel    = countelements(*hea);
#ifdef DEBUG
  if(n!=nel)
    fprintf(stderr,"Fourier_List::Fourier_List error list incomplete\n");
#endif
  hjtot  = 0;
  htot   = 0;
  base_h = (double *)0;
  base_hj= (double *)0;

  nz      = 1;
  nztot   = 1;
  flevels = (Element_List**)NULL;
}

Element *Fourier_List::operator()(int i){
#ifdef DEBUG
  if(i>nel-1) 
    fprintf(stderr,"Fourier_List::operator() bounds error\n");
#endif
  return flist[i];
}

Element *Fourier_List::operator[](int i){
#ifdef DEBUG
  if(i>nel-1) 
    fprintf(stderr,"Fourier_List::operator() bounds error\n");
#endif
  return flist[i];
}

void Fourier_List::Cat_mem(){
  htot = 0;
  hjtot = 0;
  Eloop(fhead){
    htot  += ee->qa*ee->qb;
    hjtot += ee->Nmodes;
  }
  
  base_h  = dvector(0, nz*htot-1);
  base_hj = dvector(0, nz*hjtot-1);
  
  dzero(nz*htot,   base_h, 1);
  dzero(nz*hjtot, base_hj, 1);

  Mem_shift(base_h, base_hj);
}


void Fourier_List::Mem_shift(double *new_h, double *new_hj){
  int i;
  base_h  = new_h;
  base_hj = new_hj;

  Zloop(i){
    flevels[i]->Mem_shift(new_h, new_hj);
    new_h  += htot;
    new_hj += hjtot;
    flevels[i]->htot = htot;
    flevels[i]->hjtot = hjtot;
  }
}

void Fourier_List::Trans(Element_List *EL, Nek_Trans_Type ntt){
  // Treat FFT as a global operation
  if(ntt == F_to_P || ntt == P_to_F)
    FFT(EL, ntt);
  else{
    int i;
    Zloop(i)
      flevels[i]->Trans(EL->flevels[i], ntt);
  }
}

void Fourier_List::Iprod(Element_List *EL){
  int i;
  Zloop(i)
    flevels[i]->Iprod(EL->flevels[i]);
}

void Fourier_List::Grad(Element_List *AL, Element_List *BL, Element_List *CL,
			char Trip){
  if(nz > 1 && CL && (Trip == 'a' || Trip ==  'z'))
    Grad_z(CL);

  int i;
  if(AL && BL)
    Zloop(i)
      flevels[i]->Grad(AL->flevels[i], BL->flevels[i], 0, Trip);
  else if(AL)
    Zloop(i)
      flevels[i]->Grad(AL->flevels[i], 0, 0, Trip);
  else if(BL)
    Zloop(i)
      flevels[i]->Grad(0, BL->flevels[i], 0, Trip);
}

void Fourier_List::Grad_d(double *AL, double *BL, double *CL,
			char Trip){
  
  if(nz > 1 && CL && (Trip == 'a' || Trip ==  'z' || Trip == 'A' ||Trip == 'Z'))
    Grad_z_d(CL);

  int i;
  if (Trip == 'A' || Trip == 'X' || Trip == 'Y')
    nz = 3*nz/2;
  
  if(AL && BL)
    Zloop(i){
      flevels[i]->Grad_d(AL,BL,0,Trip);
      AL += htot; BL += htot;
    }
  else if(AL)
    Zloop(i){
      flevels[i]->Grad_d(AL, 0,0,Trip);
      AL += htot; 
    } 
  else if(BL)
    Zloop(i){
      flevels[i]->Grad_d(0, BL,0,Trip);
      BL += htot; 
    } 
  nz = option("NZ");
}

void Fourier_List::Grad_h(double *EL, double *AL, double *BL, double *CL,
			  char Trip){
  
  if(nz > 1 && CL && (Trip == 'a' || Trip ==  'z' || Trip == 'A' ||Trip == 'Z')) {
    fprintf(stderr,"Not implemented - not intended\n");
    exit (-1);
  }
  
  int i;
  if (Trip == 'A' || Trip == 'X' || Trip == 'Y') {
    nz = 3*nz/2;
    Trip = tolower(Trip);
  }

  if(AL && BL)
    Zloop(i){
      flevels[0]->Grad_h(EL,AL,BL,0,Trip);
      EL += htot; AL += htot; BL += htot;
    }
  else if(AL)
    Zloop(i){
      flevels[0]->Grad_h(EL, AL, 0,0,Trip);
      EL += htot; AL += htot; 
    } 
  else if(BL)
    Zloop(i){
      flevels[0]->Grad_h(EL, 0, BL,0,Trip);
      EL += htot; BL += htot; 
    } 
  nz = option("NZ");
}

void Fourier_List::HelmHoltz(Dorp *lambda){
  fprintf(stderr,"Fourier_List::HelmHoltz not implemented\n");
}

void Fourier_List::Set_field(char *string){
  int i;
  dzero(nz*htot, base_h, 1);
  Zloop(i){
    dparam_set("z", zmesh(i));
    flevels[i]->Set_field(string);
  }
}

void Fourier_List::Set_state(char st){
  int i;
  Zloop(i)
    flevels[i]->Set_state(st);
}

void Fourier_List::zerofield(){
  dzero(hjtot*nz, base_hj, 1);
  dzero(htot*nz,  base_h, 1);
}

Element_List* Fourier_List::gen_aux_field(char ty){
  Fourier_List *el = (Fourier_List*) new Fourier_List();

  el->nel         = nel;
  el->nz          = nz;
  el->nztot       = nztot;
  
  el->flevels     = (Element_List**) malloc(nz*sizeof(Element_List*));
  
  int i;
  Zloop(i){
    el->flevels[i] = flevels[i]->gen_aux_field(ty);
    el->htot = htot;
    el->hjtot = hjtot;
  }
  
  el->flist        = el->flevels[0]->flist;
  el->fhead        = el->flevels[0]->fhead;
  el->Cat_mem();

  return (Element_List*) el;
}

void Fourier_List::Terror(char *string){
  int i;
  Zloop(i)
    flevels[i]->Terror(string);
}


int parid(int i){
  int ret = option("NZ")*option("PROCID") + i;
  return ret;
}

double zmesh(int i){
  return  dparam("LZ")*(1.0*parid(i))/(option("NZTOT"));
}

double Beta2(int i){
  return  (parid(i)==1) ? pow(2.0*M_PI*(option("NZTOT")/2)/dparam("LZ"),2):
    pow(2.0*M_PI*(parid(i)/2)/dparam("LZ"),2);
}

double  Beta(int i){
  return  (parid(i)==1) ? 2.0*M_PI*(option("NZTOT")/2)/dparam("LZ"):
    2.0*M_PI*(parid(i)/2)/dparam("LZ"); 
}


int data_len(int nel,int *size, Element *E);
int  count_facets(Element *E);

void Fourier_List::FFT(Element_List *EL, Nek_Trans_Type ntt){
  if(nz>1){
    double *base_from;
    double *base_to;
    int     ntot;
    int j;

    EL->Set_state(fhead->state);
    
    if(fhead->state == 'p'){
      base_from = base_h;
      base_to   = EL->base_h;
      ntot      = htot;
    }
    else{
      base_from = base_hj;
      base_to   = EL->base_hj;
      ntot      = hjtot;
    }
    
    double *tmp = dvector(0, nz-1);
    
#ifdef OLDFFTS
    int     dir = (ntt==P_to_F) ? -1:1;
    for(int i = 0; i < ntot; ++i){
      dcopy(nz, base_from+i, ntot, tmp, 1);
      realft(nz/2, tmp, dir);    
      dcopy(nz, tmp, 1, base_to+i, ntot);
    }
#else
    if (ntt==F_to_P) {
      if (!rplan_inv) 
	rplan_inv = rfftw_create_plan(nztot, FFTW_BACKWARD, 
				      FFTW_MEASURE | FFTW_IN_PLACE, 
				      COMPLEX_TO_REAL);
      for(int i = 0; i < ntot; ++i){
	dcopy(nz, base_from+i, ntot, tmp, 1);
	rfftw(rplan_inv, 1, (FFTW_COMPLEX *) tmp, 1, 0, 0, 0, 0);
	dcopy(nz, tmp, 1, base_to+i, ntot);
      }
    } else {
      if (!rplan) 
	rplan = rfftw_create_plan(nztot, FFTW_FORWARD, 
				  FFTW_MEASURE | FFTW_IN_PLACE, 
				  REAL_TO_COMPLEX);
      for(int i = 0; i < ntot; ++i){
	dcopy(nz, base_from+i, ntot, tmp, 1);
	rfftw(rplan, 1, (FFTW_COMPLEX *) tmp, 1, 0, 0, 0, 0);
	dcopy(nz, tmp, 1, base_to+i, ntot);
      }
    }
#endif
  }
}    


void Fourier_List::Grad_z(Element_List *EL){
  if(fhead->state == 'p')
    Grad_z_d(EL->base_h);
  else
    Grad_z_d(EL->base_hj);
  
#if 0

  double *Ur;
  double *dUdz_r;
  int     ntot;
  int     i = 0;
  double *tmp, bet;
  
  EL->Set_state(fhead->state);
  if(fhead->state == 'p'){
    ntot   = htot;
    Ur     = base_h;     
    dUdz_r = EL->base_h;
  }
  else{
    ntot   = hjtot;
    Ur     = base_hj;    
    dUdz_r = EL->base_hj;
  }

  if(!parid(i)){
    dzero(2*ntot,dUdz_r,1);
    i += 2;
    if(i >= nz) return;
    dUdz_r += 2*ntot;
    Ur     += 2*ntot;
  }

  tmp = dvector(0,ntot-1);
  /* compute: dU/dz = i beta k ( Ur + i Ui) = beta k ( -Ui + i Ur ) */
  for(; i < nz; i += 2){
    bet     = Beta(i);    dsmul(ntot,bet,Ur,1,tmp,1);
    bet     = -bet;       dsmul(ntot,bet,Ur+ntot,1,dUdz_r,1);
    dcopy(ntot,tmp,1,dUdz_r+ntot,1);
    Ur     += 2*ntot;  
    dUdz_r += 2*ntot;  
  }
  free(tmp);
#endif
}


void Fourier_List::Grad_z_d(double *EL){
  double *Ur;
  double *dUdz_r;
  int     ntot;
  int     i = 0;
  double *tmp, bet;
  
  if(fhead->state == 'p'){
    ntot   = htot;
    Ur     = base_h;     
  }
  else{
    ntot   = hjtot;
    Ur     = base_hj;    
  }
  
  dUdz_r = EL;

  if(!parid(i)){
    dzero(2*ntot,dUdz_r,1);
    i += 2;
    if(i >= nz) return;
    dUdz_r += 2*ntot;
    Ur     += 2*ntot;
  }

  tmp = dvector(0,ntot-1);
  /* compute: dU/dz = i beta k ( Ur + i Ui) = beta k ( -Ui + i Ur ) */
  for(; i < nz; i += 2){
    bet     = Beta(i);    dsmul(ntot,bet,Ur,1,tmp,1);
    bet     = -bet;       dsmul(ntot,bet,Ur+ntot,1,dUdz_r,1);
    dcopy(ntot,tmp,1,dUdz_r+ntot,1);
    Ur     += 2*ntot;  
    dUdz_r += 2*ntot;  
  }
  free(tmp);
}


#define DESCRIP 25
static int gettypes    (char *t, char *s),
           checkfmt    (char *format);

static char *fourier_hdr_fmt[] = { 
  "%-25s "            "Session\n",
  "%-25s "            "Created\n",
  "%-5c Fourier Hybrid      " "State 'p' = physical, 't' transformed\n",
  "%-5d %-5d %-5d %-5d   "    "Number of Elements; Dim of run; Lmax; NZ\n",
  "%-25d "            "Step\n",
  "%-25.6g "          "Time\n",
  "%-25.6g "          "Time step\n",
  "%-11.6g %-11.6g   " "Kinvis; LZ\n",
  "%-25s "            "Fields Written\n",
  "%-25s "            "Format\n"
  };
#define READLINE(fmt,arg) \
  if (fscanf(fp,fmt,arg)==EOF) return -1; fgets(buf,BUFSIZ,fp)

int readHeaderF(FILE* fp, Field *f){
  register int  nfields;
  char     buf[BUFSIZ];
  int      trip=0;
  if (fscanf (fp, "%s", buf) == EOF) return 0;            /* session name */
  f->name    = (char *)strdup (buf); fgets (buf, BUFSIZ, fp);
  fgets (buf, DESCRIP, fp);                               /* creation date */
  f->created = (char *)strdup (buf); fgets (buf, BUFSIZ, fp);
  
  READLINE ("%c"  , &f->state);                  /* simulation parameters */

  /* check to see if it is standard 2d file */
  if(strstr(buf,"Fourier")){
    trip = 1;
    fscanf(fp,"%d%d%d%d",&f->nel,&f->dim,&f->lmax,&f->nz);fgets(buf,BUFSIZ,fp);
  }
  else{
    fscanf(fp,"%d%d%d",&f->nel,&f->dim,&f->lmax);fgets(buf,BUFSIZ,fp);
    f->nz = 1;
  }
  
  READLINE ("%d"  , &f->step);                  
  READLINE ("%lf" , &f->time);
  READLINE ("%lf" , &f->time_step);
  if(trip){
    fscanf(fp,"%lf%lf " ,&f->kinvis,&f->lz);
    fgets(buf,BUFSIZ,fp);
  }
  else{
    READLINE ("%lf" , &f->kinvis);
    f->lz = 1.0;
  }
  
  nfields = gettypes (f->type, fgets(buf,BUFSIZ,fp));
  fscanf(fp, "%s", buf);
  if (strchr(f->format = (char *)strdup(buf),'-'))
    if (checkfmt (strchr(f->format,'-')+1))
      fputs ("Warning: field file may be in the wrong "
	     "format for this architecture\n", stderr);
  fgets (buf, BUFSIZ, fp);
  rewind(fp);
  return nfields;
}



/* ---------------------------------------------------------------------- *
 * readFieldF() -- Load a field file                                       *
 *                                                                        *
 * This function loads a field file into a Field structure.  The format   *
 * is a simple array, stored in 64-bit format.                            *
 *                                                                        *
 * Return value: number of variables loaded, 0 for EOF, -1 for error.     *
 * ---------------------------------------------------------------------- */


int readFieldF (FILE *fp, Field *f, Element_List *E)
{
  register int i, n, ntot, nfields;
  int      trip = 0;
  char     buf[BUFSIZ];
#ifdef _CRAY
  short *ssize;
#endif
  if (fscanf (fp, "%s", buf) == EOF) return 0;            /* session name */
  f->name    = (char *)strdup (buf); fgets (buf, BUFSIZ, fp);
  fgets (buf, DESCRIP, fp);                               /* creation date */
  f->created = (char *)strdup (buf); fgets (buf, BUFSIZ, fp);
  
  READLINE ("%c"  , &f->state);                  /* simulation parameters */

  /* check to see if it is standard 2d file */
  if(strstr(buf,"Fourier")){
    trip = 1;
    fscanf(fp,"%d%d%d%d",&f->nel,&f->dim,&f->lmax,&f->nz);fgets(buf,BUFSIZ,fp);
  }
  else{
    fscanf(fp,"%d%d%d",&f->nel,&f->dim,&f->lmax);fgets(buf,BUFSIZ,fp);
    f->nz = 1;
  }

  READLINE ("%d"  , &f->step);                  
  READLINE ("%lf" , &f->time);
  READLINE ("%lf" , &f->time_step);
  if(trip){
    fscanf(fp,"%lf%lf " ,&f->kinvis,&f->lz);
    fgets(buf,BUFSIZ,fp);
  }
  else{
    READLINE ("%lf" , &f->kinvis);
    f->lz = 1.0;
  }
  nfields = gettypes (f->type, fgets(buf,BUFSIZ,fp));
  fscanf(fp, "%s", buf);
  if (strchr(f->format = (char *)strdup(buf),'-'))
    if (checkfmt (strchr(f->format,'-')+1))
      fputs ("Warning: field file may be in the wrong "
	     "format for this architecture\n", stderr);
  fgets (buf, BUFSIZ, fp);

  /* allocate memory and load the data */
  
  int cnt = count_facets(E->fhead);
#ifndef FULL_FIELD
  int nltot, nrtot, skip1, skip2,
      proc   = 0, // option("PROCID"),
      NZ     = option("NZ"),
      NRZ    = min(NZ, f->nz - proc*NZ);
#endif

  switch (tolower(*f->format)) {
  case 'a':
    if(f->state == 't'){
      f->size = ivector(0,cnt-1);
      for(i = 0; i < cnt ; ++i) fscanf(fp,"%d",f->size+i);
    }
    else {
      fputs("Error: reading field file in physical space is "
	    "not implemented \n",stderr);
      exit(-1);
    }
    
    ntot = f->nz*data_len(f->nel,f->size, E->fhead);
#ifndef FULL_FIELD
    nltot = NZ*data_len(f->nel,f->size,E->fhead);
    nrtot = NRZ*data_len(f->nel,f->size,E->fhead);
    skip1 = nltot * proc;
    if (NRZ < 1) 
      return nfields;

    for (i = 0; i < skip1; i++)
      fgets(buf,BUFSIZ,fp);
#endif

    for(i = 0; i < nfields; ++i)
      if(!(f->data [i]))
	f->data[i] = dvector (0, nrtot-1);

    for (i = 0; i < nrtot; i++) {
      for (n = 0; n < nfields; n++)
	if (fscanf (fp, "%lf", f->data[n] + i) != 1) {
	  fprintf(stderr,"Error: reading field %c, point %d\n",f->type[n],i+1);
	  exit(-1);
	}
    }
    fgets (buf, BUFSIZ, fp);
    break;
    
  case 'b':
    if(f->state == 't'){
      f->size = ivector(0,cnt-1);
#ifdef _CRAY
      // int on Crays is 64b, short 32b - use short for portable fieldfiles
      ssize = (short *) calloc(cnt, sizeof(short));
      fread(ssize, sizeof(short), (size_t) cnt, fp);
      for (n = 0; n < cnt; n++)
        f->size[n] = (int) ssize[n];
      free (ssize);
#else
      fread(f->size, sizeof(int), (size_t) cnt,fp);
#endif
    }
    else {
      fputs("Error: reading field file in physical space is "
	    "not implemented \n",stderr);
      exit(-1);
    }

    ntot = f->nz*data_len(f->nel,f->size,E->fhead);
    
#ifndef FULL_FIELD
    nltot = NZ*data_len(f->nel,f->size,E->fhead);
    nrtot = NRZ*data_len(f->nel,f->size,E->fhead);
    skip1 = nltot * proc;
    skip2 = ntot - nrtot;
    if (NRZ < 1) 
      return nfields;

    fseek (fp, (long) (skip1*sizeof(double)), SEEK_CUR);
#endif

    for(i = 0; i < nfields; ++i)
      if(!(f->data [i]))
	f->data[i] = dvector (0, nrtot-1);
    
    for (n = 0; n < nfields; n++) {
      if (fread (f->data[n], sizeof(double), (size_t) nrtot, fp) != nrtot) {
	fprintf (stderr, "error reading field %c", f->type[n]);
	exit(-1);
      }
#ifndef FULL_FIELD
      fseek (fp, (long) (skip2*sizeof(double)), SEEK_CUR);
#endif
    }
    break;

  default:
    fprintf (stderr, "unknown field format -- %s\n", f->format);
    exit(-1);
    break;
  }

  return nfields;
}

/* ---------------------------------------------------------------------- *
 * writeField() -- Write a field file                                     *
 *                                                                        *
 * This function writes a field file from a Field structure.  The format  *
 * is a simple array, stored in 64-bit format.                            *
 *                                                                        *
 * Return value: number of variables written, -1 for error.               *
 * ---------------------------------------------------------------------- */
  
int writeFieldF (FILE *fp, Field *f, Element *E)
{
  int  nfields, ntot;
  char buf[BUFSIZ];
  register int i, n;
#ifdef _CRAY
  short *ssize;
#endif

  /* Write the header */
  fprintf (fp, fourier_hdr_fmt[0],  f->name);
  fprintf (fp, fourier_hdr_fmt[1],  f->created);
  fprintf (fp, fourier_hdr_fmt[2],  f->state);
  fprintf (fp, fourier_hdr_fmt[3],  f->nel, f->dim, f->lmax, f->nz);

  fprintf (fp, fourier_hdr_fmt[4],  f->step);
  fprintf (fp, fourier_hdr_fmt[5],  f->time);
  fprintf (fp, fourier_hdr_fmt[6],  f->time_step);

  fprintf (fp, fourier_hdr_fmt[7],  f->kinvis, f->lz);
  fprintf (fp, fourier_hdr_fmt[8],  f->type);
  fprintf (fp, fourier_hdr_fmt[9],  f->format);

  /* Write the field files  */
  if(f->state == 't'){
    ntot = f->nz*data_len(f->nel,f->size,E);
  }
  else{
    fprintf(stderr,"Not implemented\n");
    exit(-1);
  }
      
  nfields = (int) strlen (f->type);

  int cnt = count_facets(E);
  switch (tolower(*f->format)) {
  case 'a':
    for(i = 0; i < cnt; ++i)
      fprintf(fp,"%d ",f->size[i]);
    fputc('\n',fp);
    for (i = 0; i < ntot; i++) {
      for (n = 0; n < nfields; n++)
	fprintf (fp, "%#16.10g ", f->data[n][i]);
      fputc ('\n', fp);
    }
    break;
    
  case 'b':
#ifdef _CRAY
    // int on Crays is 64b, short 32b - use short for portable fieldfiles
    ssize = (short *) calloc(cnt, sizeof(short));
    for (n = 0; n < cnt; n++)
      ssize[n] = (short) f->size[n];
    fwrite(ssize, sizeof(short),  cnt, fp);
    free (ssize);
#else
    fwrite(f->size, sizeof(int),  cnt, fp);
#endif
    for (n = 0; n < nfields; n++)
      if (fwrite (f->data[n], sizeof(double), ntot, fp) != ntot) {
	fprintf  (stderr, "error writing field %c", f->type[n]);
	exit(-1);
      }
    break;
    
  default:
    sprintf  (buf, "unknown format -- %s", f->format);
    fprintf(stderr,buf);
    exit(-1);
    break;
  }

  fflush (fp);
  return nfields;
}


#ifndef BTYPE
#if defined(i860) || defined (__alpha) || defined (__WIN32__)
#define BTYPE "ieee_little_endian"
#endif
#
#if defined(_CRAY) && !defined (_CRAYMPP)
#define BTYPE "cray"
#endif /* ........... Cray Y-MP ........... */
#
#ifndef BTYPE
#define BTYPE "ieee_big_endian"
#endif /* default case in the absence of any other TYPE */
#endif /* ifndef TYPE */

void WritefieldF(FILE *fp, char *name, int step, double t,
		 int nfields, Element_List *U[]){
  register int n,i,j;
  time_t   tp;
  char     buf[128],state;
  Field    f;
  int      ntot;
#ifdef WASTE
  double   **u;
#endif
  register int k;
  int      nz     = U[0]->nz;
  int      nztot  = U[0]->nztot;
  int      procid = option("PROCID"), nprocs = 1;

  if(nfields > MAXFIELDS)
    error_msg(too many fields -- must be less than MAXFIELDS);

  state = U[0]->fhead->state;
  /* check to see if all fields in same state */
  for(i = 1; i < nfields; ++i)
    if(state != U[i]->fhead->state)
      {error_msg(Writefield--Fields  in different space);}
      
  /* Get the current date and time from the system */
  
  tp = time((time_t*)NULL);
  strftime(buf, 25, "%a %b %d %H:%M:%S %Y", localtime(&tp));
  
  /* Set up the field structure */
  f.name      =  name;
  f.created   =  buf;
  f.state     =  state;
  f.dim       =  DIM;
  f.nel       =  U[0]->nel;
  f.lmax      =  LGmax;
  f.step      =  step;
  f.time      =  t;
  f.nz        =  nztot;
  f.lz        =  dparam("LZ");
  f.time_step =  dparam("DT");
  f.kinvis    =  dparam("KINVIS");
  f.format    = (option("binary")) ? "binary-"BTYPE : "ascii";

  /* Generate the list of fields and assign data pointers */
  
  memset (f.type, '\0', MAXFIELDS);
  memset (f.data, '\0', MAXFIELDS * sizeof( double *));
  
  /* copyfield into matrix */
  if(state == 't'){
    int cnt = count_facets(U[0]->fhead);
    f.size = ivector(0,cnt-1);
    for(i = 0,n=0; i < f.nel; ++i){
      for(j = 0; j < U[0]->flist[i]->Nedges; ++j,++n)
	f.size[n] = U[0]->flist[i]->edge[j].l;
      
      for(j = 0; j < U[0]->flist[i]->Nfaces; ++j,++n)
	f.size[n] = U[0]->flist[i]->face[j].l;
    }
    
#ifdef WASTE
    ntot = U[0]->hjtot*nz;

    u = dmatrix(0,nfields-1,0,nprocs*ntot-1);    
    
    for(n = 0; n < nfields; ++n){
      f.type [n] = U[n]->fhead->type;
      f.data [n] = u[n];
      dcopy(ntot, U[n]->base_hj, 1, u[n], 1);
    }
#else
    for(n = 0; n < nfields; ++n){
      f.type [n] = U[n]->fhead->type;
      f.data [n] = U[n]->base_hj;
    }    
#endif
  }
  else{
    fprintf(stderr,"Not implemented\n");
    exit(-1);
  }

  writeFieldF(fp,&f,U[0]->fhead);
#ifdef WASTE
  free_dmatrix(u,0,0);
#endif

  free(f.size);

  return;
}



/*--------------------------------------------------------------------------*
 * This is a function that copies the field form the field structure 'f'    *
 * at the position given by pos to the Element 'U'. If in transformed space *
 * it allows the field to be copied at a different order. To do this it     *
 * either zeros the higher modes if U is higher than f else it ignores the  *
 * higher modes if f is higher than U                                       *
 *--------------------------------------------------------------------------*/
void copyfieldF(Field *f, int pos, Element_List *U){
  if(f->state == 'p'){ /* restart from fixed m physical field */
    fprintf(stderr,"Not implemented\n");
    exit(-1);
  }
  else{ /* restart from transformed field at any order */
    register int n,i;
    int      cl,l;
    int      *size  = f->size;
    double   *data  = f->data[pos];
    
    register int j,k;
    int  nz = f->nz;
    Element *E;
    
    for(k = 0; k < nz; ++k){
      size  = f->size;
      for(j = 0; j < f->nel; ++j){
	E = U->flevels[k]->flist[j];
	
	/* copy vertices */
	for(i = 0; i < E->Nverts; ++i){
	  E->vert[i].hj[0] = *data;
	  ++data;
	}
	
	/* copy edges */
	for (i = 0; i < E->Nedges; ++i){
	  if(l = E->edge[i].l){
	    dzero(l,E->edge[i].hj,1);
	    cl = min(l,*size);
	    dcopy(cl,data,1,E->edge[i].hj,1);
	  }
	  data += *size;
	  ++size;
	}
	
	/* copy faces */
	for(n = 0; n < E->Nfaces; ++n){
	  if(E->identify()==Nek_Tri){
	    if(l = E->face[n].l){
	      dzero(l*(l+1)/2,*E->face[n].hj,1);
	      cl = min(l,*size);
	      for(i = 0; i < cl; ++i){
		dcopy(cl-i,data,1,E->face[n].hj[i],1);
		data += *size-i;
	      }
	      for(i = cl; i < *size; ++i)
		data += *size-i;
	    }
	    else
	      for(i = 0; i < *size; ++i)
		data += *size-i;
	    ++size;
	  }
	  else{
	    if(l = E->face[n].l){
	      dzero(l*l,*E->face[n].hj,1);
	      cl = min(l,*size);
	      for(i = 0; i < cl; ++i){
		dcopy(cl,data,1,E->face[n].hj[i],1);
		data += *size;
		}
	      for(i = cl; i < *size; ++i)
		data += *size;
	    }
	    else
	      for(i = 0; i < *size; ++i)
		data += *size;
	    ++size;
	  }
	}
	E->state = 't';
      }
    }
  }
}

static int gettypes (char *t, char *s)
{
  char    *p = strstr (s, "Fields");
  register int n = 0;
  if (!p){ fprintf(stderr,"invalid \"Fields\" string");exit(-1);}
  memset(t, '\0', MAXFIELDS);
  while (s != p && n < MAXFIELDS) {
    if (isalpha(*s)) t[n++] = *s;
    s++;
  }
  return n;
}


/* Check binary format compatibility */
#if defined(__sgi) || defined(cm5) || defined(_AIX) || defined (__hpux) || defined (__sparc) || defined (_CRAYMPP)
#define ieeeb
#define ieee
#endif

#if defined(i860) || defined (__alpha) || defined (__WIN32__)
#define ieeel
#endif

static int checkfmt (char *arch)
{
  char        **p;
  static char *fmtlist[] = {
#if defined(ieeeb)                  /* ... IEEE big endian machine ..... */
    "ieee_big_endian",
    "sgi", "iris4d", "SGI", "IRIX", /* kept for compatibility purposes   */
    "IRIX64",                       /* ........ Silicon Graphics ....... */
    "AIX",                          /* .......... IBM RS/6000 .......... */
    "cm5",                          /* ........ Connection Machine ..... */
#endif
#
#if defined(ieeel)                  /* ... IEEE little endian machine .. */
    "ieee_little_endian",
    "i860",                         /* ........... Intel i860 .......... */
#endif
#
#if defined(ieee)                   /* ...... Generic IEEE machine ..... */
    "ieee", "sim860",               /* kept for compatibility purposes   */
#endif                              /* same as IEEE big endian           */
#
#if defined(_CRAY) && !defined (_CRAYMPP) /* ...... Cray PVP ........... */
    "cray", "CRAY",                 /* kept for compatibility purposes   */
#endif                              /* no conflict with T3* as it        */
#                                   /* precedes this line                */
     0 };   /* a NULL string pointer to signal the end of the list */

  for (p = fmtlist; *p; p++)
    if (strncmp (arch, *p, strlen(*p)) == 0)
      return 0;

  return 1;
}

#undef ieee
