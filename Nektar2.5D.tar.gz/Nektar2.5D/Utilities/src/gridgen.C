/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/gridgen.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <nektar.h>
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
static char  usage_[128];

#if DIM == 2
char *prog   = "gridgen2d";
char *usage  = "gridgen2d:  [options]  input[.rea]\n";
#else
char *prog   = "gridgen3d";
char *usage  = "gridgen3d:  [options]  input[.rea]\n";
#endif
char *author = "Spencer Sherwin";
char *rcsid  = "";
char *help   = 
  "-g      ... write out goemetry denoting singular points (3D only)\n"
  "-q      ... quadrature point spacing. Default is even spacing\n"
  "-R      ... range data information. must have mesh file (-m file) \n"
  "-b      ... make body elements specified in mesh file (-m file) \n"
  "-n #    ... Number of mesh points. Default is 15\n"
  "-s      ... dump output in single precision (%lf)\n";

/* ---------------------------------------------------------------------- */

typedef struct body{
  int N;       /* number of faces    */
  int *elmt;   /* element # of face  */ 
  int *faceid; /* face if in element */
} Body;

static Body bdy;

typedef struct range{
  double x[2];
  double y[2];
  double z[2];
} Range;

static Range *rnge;

static void setup (FileList *, Element **);
static void Get_Body(FILE *fp);
static void parse_util_args (int argc, char *argv[], FileList *f);
static void WriteMesh(Element *E, FILE *out);
static void triangle (Element *E, Coord *X);
static void circle   (Element *E, Coord *X);

static void dump_faces(FILE *out, Element *E, Coord X,  int zone );

main (int argc, char *argv[])
{
  FileList   f;
  Element   *master;

  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

#ifdef DEBUG 
  init_debug();
#endif
  
  setup (&f, &master);
  WriteMesh(master,f.out.fp);
  
  return 0;
}

static void setup (FileList *f, Element **U)
{
  int i,k;
  Curve *curve;

  ReadParams  (f->rea.fp);

  if((i=iparam("NORDER-req"))!=UNSET){
    iparam_set("LQUAD",i);
    iparam_set("MQUAD",i);
  }

  U[0] = ReadMesh(f->rea.fp, strtok(f->rea.name,"."));       /* Generate the list of elements */
  U[0]->Cat_mem();

  
#if DIM == 3
  if(f->mesh.name) Get_Body(f->mesh.fp);
#endif

  return;
}

static char *getcolour(void);
static int Check_range(Element *E);

static void WriteMesh(Element *E, FILE *out){
  register i;
  const    qa = E->qa, qb = E->qb, qc = E->qc;
  int      qt,zone;
  double   *z,*w;
  Coord    X,Y;
  char     *outformat,*Colour;
  Element *U;
  
  if(!option("Qpts")){  /* reset quadrature points */ 
    getzw(qa,&z,&w,'a');
    for(i = 0; i < qa; ++i) z[i] = 2.0*i/(double)(qa-1) -1.0;
    getzw(qb,&z,&w,'b');
    for(i = 0; i < qb; ++i) z[i] = 2.0*i/(double)(qb-1) -1.0;
#if DIM == 3
    getzw(qc,&z,&w,'c');
    for(i = 0; i < qc; ++i) z[i] = 2.0*i/(double)(qc-1) -1.0;
#endif

  
    /* force to regenerate basis for curved sides */
    reset_basis();
  }

#if DIM == 3
  if(option("SingMesh")){
    Y.x = dvector(0,20);
    Y.y = dvector(0,20);
    Y.z = dvector(0,20);
  }

  qt = qa*qb*qc;
  X.z = dvector(0,qt-1);
#else
  qt = qa*qb;
#endif
  X.x = dvector(0,qt-1);
  X.y = dvector(0,qt-1);

#if DIM == 3
  fprintf(out,"VARIABLES = x y z\n");

  if(option("Spre"))
    outformat = strdup("%lf \t %lf \t %lf\n");
  else
    outformat = strdup("%#16.12le \t %#16.12le \t %#16.12le\n");
#else
  /* write 2d header */
  if(option("Qpts"))
    fprintf(out,"%d %d %d %d Nr Ns Nz Nel Collocation spacing\n"
	    ,qa,qb,0,countelements(E));
  else
    fprintf(out,"%d %d %d %d Nr Ns Nz Nel Even spacing\n"
	    ,qa,qb,0,countelements(E));

  if(option("Spre"))
    outformat = strdup("%lf \t %lf\n");
  else
    outformat = strdup("%#16.12le \t %#16.12le\n");
#endif

#if DIM == 3 /* tecplot format */
    if(option("SingMesh")){
      for(; E; E = E->next){
	Colour = getcolour();
	coord(E,&X);
	fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
		E->id+1,2,2,2);
	fprintf(out, outformat, X.x[0],      X.y[0],      X.z[0]);
	fprintf(out, outformat, X.x[qa-1],   X.y[qa-1],   X.z[qa-1]);
	fprintf(out, outformat, X.x[qa*qb-1],X.y[qa*qb-1],X.z[qa*qb-1]);
	fprintf(out, outformat, X.x[qa*qb-1],X.y[qa*qb-1],X.z[qa*qb-1]);
	fprintf(out, outformat, X.x[qt-1],   X.y[qt-1],   X.z[qt-1]);
	fprintf(out, outformat, X.x[qt-1],   X.y[qt-1],   X.z[qt-1]);
	fprintf(out, outformat, X.x[qt-1],   X.y[qt-1],   X.z[qt-1]);
	fprintf(out, outformat, X.x[qt-1],   X.y[qt-1],   X.z[qt-1]);
	triangle(E,&Y);
	fprintf(out,"GEOMETRY T=LINE3D, C=%s\n",Colour);
	fputs("2\n",out);
	fputs("4\n",out);
	for(i = 0; i < 3; ++i)
	  fprintf(out,"%lf %lf %lf\n",Y.x[i],Y.y[i],Y.z[i]);
	fprintf(out,"%lf %lf %lf\n",Y.x[0],Y.y[0],Y.z[0]);
	circle(E,&Y);
	fputs("21\n",out);
	for(i = 0; i < 21; ++i)
	  fprintf(out,"%lf %lf %lf\n",Y.x[i],Y.y[i],Y.z[i]);
      }
    }
    else{
      for(zone = 0, U = E; U; U = U->next){
	if(Check_range(U)){
	  coord(U,&X);
	  fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
		  ++zone,qa,qb,qc);
	  for(i = 0; i < qt; ++i)
	    fprintf(out, outformat, X.x[i], X.y[i], X.z[i]);
	}
      }
    }
#else        /* sm format      */
  for(U=E; U; U = U->next){
    coord(U,&X);
    for(i = 0; i < qt; ++i)  fprintf(out, outformat, X.x[i], X.y[i]);
  }
  for(U=E; U; U = U->next)
    fprintf(out,"%d %d %d %d\n",U->edge[0].l,U->edge[1].l,
	    U->edge[2].l,U->face[0].l);
#endif

#if DIM == 3
  if(bdy.N) dump_faces(out,E,X,zone);
  free(X.z);
#endif
  free(X.x); free(X.y);

}

#define NCLRS 6
static char Colours[][8]={"RED", "GREEN", "BLUE", "CYAN","YELLOW", "PURPLE"};

static char *getcolour(void){
  int  num;
  static int clr=-1;
  num = ++clr%NCLRS;
  
  return Colours[num];  
}


/* coordinated to draw triangle for 3-D meshplot */
static void triangle(Element *E, Coord *X){
  Vert *v = E->vert;
  
  X->x[0] = v[2].x + 0.1*(0.5*v[0].x - v[2].x + 0.5*v[1].x);
  X->y[0] = v[2].y + 0.1*(0.5*v[0].y - v[2].y + 0.5*v[1].y);
  X->z[0] = v[2].z + 0.1*(0.5*v[0].z - v[2].z + 0.5*v[1].z);

  X->x[1] = X->x[0] + 0.2*(v[0].x - v[2].x);
  X->y[1] = X->y[0] + 0.2*(v[0].y - v[2].y);
  X->z[1] = X->z[0] + 0.2*(v[0].z - v[2].z);

  X->x[2] = X->x[1] + 0.2*(v[1].x - v[0].x);
  X->y[2] = X->y[1] + 0.2*(v[1].y - v[0].y);
  X->z[2] = X->z[1] + 0.2*(v[1].z - v[0].z);
}

static void circle(Element *E, Coord *X){
  register i;
  double v1x,v2x,v3x,v1y,v2y,v3y,v1z,v2z,v3z,vax,vay,vaz;
  double a,b,a2,a3,b3;
  Vert  *v = E->vert;
  
  v1x = v[0].x;
  v1y = v[0].y;
  v1z = v[0].z;
  
  v2x = 0.5*(v[1].x + v[2].x);
  v2y = 0.5*(v[1].y + v[2].y);
  v2z = 0.5*(v[1].z + v[2].z);

  v3x = v[3].x;
  v3y = v[3].y;
  v3z = v[3].z;

  a2 = sqrt((v2x-v1x)*(v2x-v1x)+(v2y-v1y)*(v2y-v1y)+(v2z-v1z)*(v2z-v1z));
  a3 = ((v3x-v1x)*(v2x-v1x) + (v3y-v1y)*(v2y-v1y) + (v3z-v1z)*(v2z-v1z))/a2;
  b3 = sqrt((v3x-v1x)*(v3x-v1x)+(v3y-v1y)*(v3y-v1y)+(v3z-v1z)*(v3z-v1z) 
	    - a3*a3);
  
  vax = v1x + a3*(v2x-v1x)/a2;
  vay = v1y + a3*(v2y-v1y)/a2;
  vaz = v1z + a3*(v2z-v1z)/a2;

  for(i = 0; i < 21; ++i){
    a = a3+0.05*b3*sin(2.0*M_PI*i/20.0);
    b = b3*(1-0.05*cos(2.0*M_PI*i/20.0));
    
    X->x[i] = (v1x*(a2 - a)/a2 + v2x*a/a2) + (vax*(b3-b)/b3 + v3x*b/b3) -vax;
    X->y[i] = (v1y*(a2 - a)/a2 + v2y*a/a2) + (vay*(b3-b)/b3 + v3y*b/b3) -vay;
    X->z[i] = (v1z*(a2 - a)/a2 + v2z*a/a2) + (vaz*(b3-b)/b3 + v3z*b/b3) -vaz;
  }  
  
}

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  int   i;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }

  option_set("SingMesh",NULL);

  while (--argc && (*++argv)[0] == '-') {
    while (c = *++argv[0])                  /* more to parse... */
      switch (c) {
      case 'b':
	option_set("Body",1);
	break;
      case 'R':
	option_set("Range",1);
	break;
      case 'g':
	option_set("SingMesh",1);
	break;
      case 's':
	option_set("Spre",1);
	break;
      case 'q':
	option_set("Qpts",1);
	break;  
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }
#if DIM ==2
  if(iparam("NORDER-req") == UNSET) iparam_set("NORDER-req",15);
#endif

  /* open the .rea file */

  if ((*argv)[0] == '-') {
    f->rea.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->rea.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.rea", *argv);
      if ((f->rea.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->rea.name = strdup(fname);
  }
  
  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}

#ifdef EXCLUDE
static int Check_range(Element *E){
  if(rnge){
    register i;

    for(i = 0; i < Nvert; ++i){
      if((E->vert[i].x < rnge->x[0])||(E->vert[i].x > rnge->x[1])) return 0;
      if((E->vert[i].y < rnge->y[0])||(E->vert[i].y > rnge->y[1])) return 0;
#if DIM == 3
      if((E->vert[i].z < rnge->z[0])||(E->vert[i].z > rnge->z[1])) return 0;
#endif
    }
  }
  return 1;
}
#else
static int Check_range(Element *E){
  if(rnge){
    register i;

    for(i = 0; i < Nvert; ++i){
#if DIM == 3
      if((E->vert[i].x > rnge->x[0])&&(E->vert[i].x < rnge->x[1]) 
	 && (E->vert[i].y > rnge->y[0])&&(E->vert[i].y < rnge->y[1]) 
         && (E->vert[i].z > rnge->z[0])&&(E->vert[i].z < rnge->z[1])) return 1;
#else
      if((E->vert[i].x > rnge->x[0])&&(E->vert[i].x < rnge->x[1]) 
	 && (E->vert[i].y > rnge->y[0])&&(E->vert[i].y < rnge->y[1])) return 1;
#endif
    }
    return 0;
  }
  else
    return 1;
}
#endif

#if DIM == 3
static void Get_Body(FILE *fp){
  register i;
  char buf[BUFSIZ],*s;
  int  N;

  if(option("Range")){
    rnge = (Range *)malloc(sizeof(Range));
    rewind(fp);  /* search for range data */
    while(s && !strstr((s=fgets(buf,BUFSIZ,fp)),"Range"));

    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->x,rnge->x+1);
    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->y,rnge->y+1);
#if DIM == 3
    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->z,rnge->z+1);
#endif
  }

  if(option("Body")){
    rewind(fp);/* search for body data  */
    while(s && !strstr((s=fgets(buf,BUFSIZ,fp)),"Body"));   
    
    if(s!=NULL){
      
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&N);
      
      bdy.N = N;
      bdy.elmt   = ivector(0,N-1);
      bdy.faceid = ivector(0,N-1);
      
      for(i = 0; i < N; ++i){
	fgets(buf,BUFSIZ,fp);
	sscanf(buf,"%d%d",bdy.elmt+i,bdy.faceid+i);
	--bdy.elmt[i];
	--bdy.faceid[i];
      }
    }
  }
}

static void dump_faces(FILE *out,Element *E, Coord X, int zone ){

  int      qa = E->qa, qb = E->qb, qc = E->qc;  
  register i,j,k,n;
  
  for(k = 0; k < bdy.N; ++k){
    coord(E+bdy.elmt[k],&X);
    
    switch(bdy.faceid[k]){
    case 0:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qa,qb,1);
    
      for(i = 0; i < qa*qb; ++i)
	fprintf(out,"%lg %lg %lg\n", X.x[i], X.y[i], X.z[i]);
      break;
    case 1:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qa,qc,1);
    
      for(i = 0; i < qc; ++i)
	for(j = 0; j < qa; ++j)
	  fprintf(out,"%lg %lg %lg \n", X.x[qa*qb*i+j],
		X.y[qa*qb*i+j], X.z[qa*qb*i+j]);
      break;
    case 2:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qb,qc,1);
    
      for(i = 0; i < qb*qc; ++i)
	fprintf(out,"%lg %lg %lg\n", X.x[qa-1 + i*qa],
		X.y[qa-1 + i*qa], X.z[qa-1 + i*qa]);
      break;
    case 3:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qb,qc,1);
    
      for(i = 0; i < qb*qc; ++i)
	fprintf(out,"%lg %lg %lg\n", X.x[i*qa],X.y[i*qa], X.z[i*qa]);
      break;
    }
  }
}
#endif
