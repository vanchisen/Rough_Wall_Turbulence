/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/nek2tec.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <nektarF.h>
#include "Quad.h"
#include "Tri.h"
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
static char  usage_[128];

char *prog   = "AvePlane";
char *usage  = "AvePlane:  [options]  -r file[.rea]  input[.fld]\n";
char *author = "";
char *rcsid  = "";
char *help   = 
  "-q     ... quadrature point spacing. Default is even spacing\n"
  "-R     ... range data information. must have mesh file specified\n"
  "-b     ... make body elements specified in mesh file\n"
#ifdef EDGES
  "-p #   ... edge expansion order\n"
  "-t #   ... fill percentage [0-1]\n"
#endif
#if DIM == 2
  "-n #   ... Number of mesh points. Default is 15\n";
#else
  "-n #   ... Number of mesh points.";
#endif

/* ---------------------------------------------------------------------- */

typedef struct body{
  int N;       /* number of faces    */
  int *elmt;   /* element # of face  */ 
  int *faceid; /* face if in element */
} Body;

static Body bdy;

typedef struct range{
  double x[2];
  double y[2];
  double z[2];
} Range;

static Range *rnge;

static void setup (FileList *f, Element_List **U, Field *fld);
static void Get_Body(FILE *fp);
static void dump_faces(FILE *out,Element **E, Coord X, int nel, int zone, 
		       int nfields);
static void parse_util_args (int argc, char *argv[], FileList *f);
static void Write(Element_List **E, FILE *out, int nfields);
int readHeaderF(FILE* fp, Field *f);

main (int argc, char *argv[])
{
  int       dump=0,nfields;
  Field     fld;
  FileList  f;
  Element_List **master;
  
  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

  memset(&fld, '\0', sizeof (Field));
  dump = readHeaderF (f.in.fp, &fld);
  if (!dump         ) error_msg(Restart: no dumps read from restart file);
  if (fld.dim != DIM) error_msg(Restart: file if wrong dimension);

  master = (Element_List **) 
    malloc((nfields = strlen(fld.type))*sizeof(Element_List *));

  setup (&f, master, &fld);

  Write(master,f.out.fp,nfields);
  
  return 0;
}

static void setup (FileList *f, Element_List **U, Field *fld)
{
  int i,k;
  int nfields = strlen(fld->type),NZ;
  Curve *curve;

  ReadParams  (f->rea.fp);

  // use all the Fourier planes as a default
  if ((NZ = option("NZTOT")) < 4) {
    option_set("NZ", fld->nz);
    option_set("NZTOT", fld->nz);
    NZ = fld->nz;
  } else // otherwise use value set at command line
    option_set("NZ", NZ);

  if((i=iparam("NORDER-req"))!=UNSET){
    iparam_set("LQUAD",i);
    iparam_set("MQUAD",i);
  }
  else if(option("Qpts")){
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax);
  }    
  else{
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax+1);
  }    
  
  iparam_set("MODES",fld->lmax);

  init_rfft_struct(); // initialize RFFT structures

  /* Generate the list of elements */
  U[0] = ReadMesh(f->rea.fp,strtok(f->rea.name,"."));     

//#ifdef OLD
//  readFieldF(f->in.fp, fld, U[0]);
//#else
 if(1||option("oldhybrid")) // at present need this to read in old files
  set_nfacet_list(U[0]);

//  readField(f->in.fp, fld);
  readFieldF(f->in.fp, fld, U[0]);
//#endif
  
#if DIM == 3
  if(f->mesh.name) Get_Body(f->mesh.fp);
#endif

  U[0]->fhead->type = fld->type[0];
#if 0
  int *fs = fld->size;
  for(k=0; k < fld->nel; ++k){
    U[0]->flist[k]->Mem_J(fs,'n');
    fs += U[0]->flist[k]->Nedges + U[0]->flist[k]->Nfaces;
    U[0]->flist[k]->Mem_Q();
  }
  U[0]->Cat_mem();
#endif
  
  copyfieldF(fld,0,U[0]);

  for(i = 1; i < nfields; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i];
    copyfieldF(fld,i,U[i]);
  }
  
  return;
}

static int Check_range(Element *E);
static void dump_edgebox(FILE *out, Coord *X, Element **E, 
		  int edge, int zone, int eid, int nfields);

static void Write(Element_List **E, FILE *out, int nfields){
  register int i,j,k,n;
  const int    qa = (*E)->fhead->qa, qb = (*E)->fhead->qb, 
               qc = (*E)->fhead->qc;
  int      qt,zone;
  double   *z,*w;
  Coord    X;
  char     *outformat;
  Element  *F;

  if(!option("Qpts")){  /* reset quadrature points */ 
    for(F=E[0]->fhead;F;F=F->next)
      if(F->identify() == Nek_Tri){
	Basis *b = F->getbasis();
	getzw(qa,&z,&w,'a');
	for(i = 0; i < qa; ++i) z[i] = 2.0*i/(double)(qa-1) -1.0;
	getzw(qb,&z,&w,'b');
	for(i = 0; i < qb; ++i) z[i] = 2.0*i/(double)(qb-1) -1.0;
	b->id = 0;
	break;
      }
    for(F=E[0]->fhead;F;F=F->next)
      if(F->identify() == Nek_Quad){
	Basis *b = F->getbasis();
	getzw(qa,&z,&w,'a');
	for(i = 0; i < qa; ++i) z[i] = 2.0*i/(double)(qa-1) -1.0;
	b->id = 0;
	break;
      }
  }

  for(i = 0; i < nfields; ++i)  E[i]->Trans(E[i], J_to_Q);
  if(option("Arnoldi")){
    int    htot   = E[0]->htot;
    double beta   = dparam("BETA");
    double *ev_re = dvector(0,htot-1);
    double *ev_im = dvector(0,htot-1);

    for(i = 0; i < nfields; ++i){
      dcopy(htot,E[i]->flevels[0]->base_h,1,ev_re,1);
      dcopy(htot,E[i]->flevels[1]->base_h,1,ev_im,1);
      
      for(j = 0; j < E[0]->nz; ++j){
	dsmul (htot, cos(beta*zmesh(j)), ev_re, 1, E[i]->flevels[0]->base_h,1);
	dsvtvm(htot, sin(beta*zmesh(j)), ev_im, 1, E[i]->flevels[0]->base_h,1,
	       E[i]->flevels[j]->base_h,1);
	dneg(htot,E[i]->flevels[j]->base_h,1);
      }
    }

    free(ev_re);   free(ev_im);
  }
  else
    for(i = 0; i < nfields; ++i)  E[i]->Trans(E[i], F_to_P);

//average between diffrent planes, i.e., plane j and plane NZ-j, j>0;
//
  for(k = 0,zone=0; k < E[0]->nel; ++k){
    int nz = E[0]->nz;
    //plane 0 is not involved
	 for(j = 1; j < E[0]->nz; ++j)
	  for(i = 0; i < E[0]->flist[k]->qa*E[0]->flist[k]->qb; ++i)
	   for(n = 0; n < nfields; ++n)
     {
        double ave_value= 0.5*(E[n]->flevels[j]->flist[k]->h[0][i]
                         +E[n]->flevels[nz-j]->flist[k]->h[0][i]);

	      E[n]->flevels[j]->flist[k]->h[0][i] = ave_value;
     }
  }
//
  qt = qa*qb;
  fprintf(out,"VARIABLES = x y z");


  X.x = dvector(0,QGmax*QGmax-1);
  X.y = dvector(0,QGmax*QGmax-1);

  for(i = 0; i < nfields; ++i)
    fprintf(out," %c", E[i]->fhead->type);
  fputc('\n',out);

  if(option("FEstorage")){
    for(k = 0,i=0,n=0; k < E[0]->nel; ++k){
      i += E[0]->flist[k]->qa*E[0]->flist[k]->qb;
      n += (E[0]->flist[k]->qa-1)*(E[0]->flist[k]->qb-1);
    }
    fprintf(out,"ZONE N=%d, E=%d, F=FEPOINT, ET=QUADRILATERAL\n", i, n);
    
    for(k = 0,zone=0; k < E[0]->nel; ++k){
      if(Check_range(E[0]->flist[k])){
	E[0]->flist[k]->coord(&X);
	for(j = 0; j < E[0]->nz; ++j)
	  for(i = 0; i < qt; ++i){
	    fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
	    for(n = 0; n < nfields; ++n)
	      fprintf(out," %lg",E[n]->flist[k]->h[0][i]);
	    fputc('\n',out);
	  }
      }
    }
    
    for(k = 0,n=1; k < E[0]->nel; ++k){
      for(i=0;i<E[0]->flist[k]->qb-1;++i)
	for(j=0;j<E[0]->flist[k]->qa-1;++j){
	  fprintf(out,"%d %d %d %d\n",n+j+i*E[0]->flist[k]->qa,
		  n+j+1+i*E[0]->flist[k]->qa,
		  n+j+1+(i+1)*E[0]->flist[k]->qa,
		  n+j+(i+1)*E[0]->flist[k]->qa);
	}
      n+= E[0]->flist[k]->qa*E[0]->flist[k]->qb;
    }
  }
  else{
    for(k = 0,zone=0; k < E[0]->nel; ++k){
      if(Check_range(E[0]->flist[k])){
	E[0]->flist[k]->coord(&X);
	fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
		++zone,E[0]->flist[k]->qa,E[0]->flist[k]->qb, E[0]->nz+1);
	for(j = 0; j < E[0]->nz; ++j)
	  for(i = 0; i < E[0]->flist[k]->qa*E[0]->flist[k]->qb; ++i){
	    fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
	    for(n = 0; n < nfields; ++n)
	      fprintf(out," %lg",E[n]->flevels[j]->flist[k]->h[0][i]);
	    fputc('\n',out);
	  }
	for(i = 0; i < E[0]->flist[k]->qa*E[0]->flist[k]->qb; ++i){
	  fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
	  for(n = 0; n < nfields; ++n)
	    fprintf(out," %lg",E[n]->flevels[0]->flist[k]->h[0][i]);
	  fputc('\n',out);
	}
      }
    }
  }
  
  free(X.x); free(X.y);
}

#ifdef EXCLUDE
static int Check_range(Element *E){
  if(rnge){
    register int i;

    for(i = 0; i < E->Nverts; ++i){
      if((E->vert[i].x < rnge->x[0])||(E->vert[i].x > rnge->x[1])) return 0;
      if((E->vert[i].y < rnge->y[0])||(E->vert[i].y > rnge->y[1])) return 0;
#if DIM == 3
      if((E->vert[i].z < rnge->z[0])||(E->vert[i].z > rnge->z[1])) return 0;
#endif
    }
  }
  return 1;
}
#else
static int Check_range(Element *E){
  if(rnge){
    register int i;

    for(i = 0; i < E->Nverts; ++i){
#if DIM == 3
      if((E->vert[i].x > rnge->x[0])&&(E->vert[i].x < rnge->x[1]) 
	 && (E->vert[i].y > rnge->y[0])&&(E->vert[i].y < rnge->y[1]) 
         && (E->vert[i].z > rnge->z[0])&&(E->vert[i].z < rnge->z[1])) return 1;
#else
      if((E->vert[i].x > rnge->x[0])&&(E->vert[i].x < rnge->x[1]) 
	 && (E->vert[i].y > rnge->y[0])&&(E->vert[i].y < rnge->y[1])) return 1;
#endif
    }
    return 0;
  }
  else
    return 1;
}
#endif

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  int   i;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }
  iparam_set("Porder",0);
  dparam_set("theta",0.3);

  while (--argc && (*++argv)[0] == '-') {
    while (c = *++argv[0])                  /* more to parse... */
      switch (c) {
      case 'A':
	option_set("Arnoldi",1);
	break;
      case 'b':
	option_set("Body",1);
	break;
      case 'f':
	option_set("FEstorage",1);
	break;
      case 'R':
	option_set("Range",1);
	break;
      case 'q':
	option_set("Qpts",1);
	break;
      case 'p':
	if (*++argv[0]) 
	  iparam_set("Porder", atoi(*argv));
	else {
	  iparam_set("Porder", atoi(*++argv));
	  argc--;
	}
	(*argv)[1] = '\0';
	break;
      case 't':
	if (*++argv[0]) 
	  dparam_set("theta", atof(*argv));
	else {
	  dparam_set("theta", atof(*++argv));
	  argc--;
	}
	(*argv)[1] = '\0';
	break;
      case 'z':                           
	if (*++argv[0]) 
	  option_set("NZTOT", atoi(*argv));
	else {
	  option_set("NZTOT", atoi(*++argv));
	  argc--;
	}
	break;
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }
#if DIM == 2
  if(iparam("NORDER-req") == UNSET) iparam_set("NORDER-req",15);
#endif  
  /* open input file */

  if ((*argv)[0] == '-') {
    f->in.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.fld", *argv);
      if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->in.name = strdup(fname);
  }

  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}

#if DIM == 3
static void Get_Body(FILE *fp){
  register int i;
  char buf[BUFSIZ],*s;
  int  N;

  if(option("Range")){
    rnge = (Range *)malloc(sizeof(Range));
    rewind(fp);  /* search for range data */
    while(s && !strstr((s=fgets(buf,BUFSIZ,fp)),"Range"));

    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->x,rnge->x+1);
    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->y,rnge->y+1);
#if DIM == 3
    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->z,rnge->z+1);
#endif
  }

  if(option("Body")){
    rewind(fp);/* search for body data  */
    while(s && !strstr((s=fgets(buf,BUFSIZ,fp)),"Body"));   
    
    if(s!=NULL){
      
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&N);
      
      bdy.N = N;
      bdy.elmt   = ivector(0,N-1);
      bdy.faceid = ivector(0,N-1);
      
      for(i = 0; i < N; ++i){
	fgets(buf,BUFSIZ,fp);
	sscanf(buf,"%d%d",bdy.elmt+i,bdy.faceid+i);
	--bdy.elmt[i];
	--bdy.faceid[i];
      }
    }
  }
}

static void dump_faces(FILE *out, Element **E, Coord X, int nel, int zone, 
		       int nfields){

  int      qa = (*E)->qa, qb = (*E)->qb, qc = (*E)->qc;  
  register int i,j,k,n;
  
  for(k = 0; k < bdy.N; ++k){
    coord(E[0]+bdy.elmt[k],&X);
    
    
    switch(bdy.faceid[k]){
    case 0:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qa,qb,1);
      for(i = 0; i < qa*qb; ++i){
	fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], X.z[i]);
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][i]);
	fputc('\n',out);
      }
      break;
    case 1:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qa,qc,1);
      for(i = 0; i < qc; ++i){
	for(j = 0; j < qa; ++j){
	  fprintf(out,"%lg %lg %lg", X.x[qa*qb*i+j],
		X.y[qa*qb*i+j], X.z[qa*qb*i+j]);
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][qa*qb*i+j]);
	fputc('\n',out);
	}
      }
      break;
    case 2:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qb,qc,1);
      for(i = 0; i < qb*qc; ++i){
	fprintf(out,"%lg %lg %lg", X.x[qa-1 + i*qa],
		X.y[qa-1 + i*qa], X.z[qa-1 + i*qa]);
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][qa-1 + i*qa]);
	fputc('\n',out);
      }
      break;
    case 3:
      fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,qb,qc,1);
      for(i = 0; i < qb*qc; ++i){
	fprintf(out,"%lg %lg %lg", X.x[i*qa],X.y[i*qa], X.z[i*qa]);
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n][bdy.elmt[k]].h[0][0][i*qa]);
	fputc('\n',out);
      }
      break;
    }
  }
}
#endif

#ifdef EDGES
static void dump_edgebox(FILE *out, Coord *X, Element **E, 
		  int edge, int zone, int eid, int nfields){

  register int i,j,k,l;
  const int    qa = E[0][eid].qa, qb= E[0][eid].qb,qc= E[0][eid].qc;
  int      q,p;
  double   cx[2],cy[2],cz[2],**x,**y,**z,*h;
  double   energy, theta;
  Element  *U = E[0]+eid;
  Basis    *b = getbasis(E[0]+eid);

  p     = iparam("Porder");
  theta = dparam("theta");

  x = dmatrix(0,2,0,QGmax-1);
  y = dmatrix(0,2,0,QGmax-1);
  z = dmatrix(0,2,0,QGmax-1);
  
  /* calculate the center points of the two adjacent faces of the edge */
  switch(edge){
  case 0:
    q = qa;

    for(i = 0; i < DIM; ++i){
      dcopy(q,X->x,1,x[i],1);
      dcopy(q,X->y,1,y[i],1);
#if DIM == 3
      dcopy(q,X->z,1,z[i],1);
#endif
    }

#if DIM == 2
    cx[0] = (U->vert[0].x + U->vert[1].x + U->vert[2].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[1].y + U->vert[2].y)/3.0;
#else    
    cx[0] = (U->vert[0].x + U->vert[1].x + U->vert[3].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[1].y + U->vert[3].y)/3.0;
    cz[0] = (U->vert[0].z + U->vert[1].z + U->vert[3].z)/3.0;
    
    cx[1] = (U->vert[0].x + U->vert[1].x + U->vert[2].x)/3.0;
    cy[1] = (U->vert[0].y + U->vert[1].y + U->vert[2].y)/3.0;
    cz[1] = (U->vert[0].z + U->vert[1].z + U->vert[2].z)/3.0;
#endif
    break;
  case 1:
    q = qb;

    for(i = 0; i < DIM; ++i){
      dcopy(q,X->x + qa-1,qa,x[i],1);
      dcopy(q,X->y + qa-1,qa,y[i],1);
#if DIM == 3
      dcopy(q,X->z + qa-1,qa,z[i],1);
#endif
    }
#if DIM == 2
    cx[0] = (U->vert[0].x + U->vert[1].x + U->vert[2].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[1].y + U->vert[2].y)/3.0;
#else
    cx[0] = (U->vert[1].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[0] = (U->vert[1].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[0] = (U->vert[1].z + U->vert[2].z + U->vert[3].z)/3.0;
    
    cx[1] = (U->vert[0].x + U->vert[1].x + U->vert[2].x)/3.0;
    cy[1] = (U->vert[0].y + U->vert[1].y + U->vert[2].y)/3.0;
    cz[1] = (U->vert[0].z + U->vert[1].z + U->vert[2].z)/3.0;
#endif
    break;
  case 2:
    q = qb;

    for(i = 0; i < DIM; ++i){
      dcopy(q,X->x,qa,x[i],1);
      dcopy(q,X->y,qa,y[i],1);
#if DIM == 3
      dcopy(q,X->z,qa,z[i],1);
#endif
    }
    
    cx[0] = (U->vert[0].x + U->vert[1].x + U->vert[2].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[1].y + U->vert[2].y)/3.0;
#if DIM == 3
    cz[0] = (U->vert[0].z + U->vert[1].z + U->vert[2].z)/3.0;

    cx[1] = (U->vert[0].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[1] = (U->vert[0].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[1] = (U->vert[0].z + U->vert[2].z + U->vert[3].z)/3.0;
    break;
  case 3:
    q = qc;

    for(i = 0; i < 3; ++i){
      dcopy(q,X->x,qa*qb,x[i],1);
      dcopy(q,X->y,qa*qb,y[i],1);
      dcopy(q,X->z,qa*qb,z[i],1);
    }
    
    cx[0] = (U->vert[0].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[0] = (U->vert[0].z + U->vert[2].z + U->vert[3].z)/3.0;

    cx[1] = (U->vert[0].x + U->vert[1].x + U->vert[3].x)/3.0;
    cy[1] = (U->vert[0].y + U->vert[1].y + U->vert[3].y)/3.0;
    cz[1] = (U->vert[0].z + U->vert[1].z + U->vert[3].z)/3.0;


    break;
  case 4:
    q = qc;

    for(i = 0; i < 3; ++i){
      dcopy(q,X->x+qa-1,qa*qb,x[i],1);
      dcopy(q,X->y+qa-1,qa*qb,y[i],1);
      dcopy(q,X->z+qa-1,qa*qb,z[i],1);
    }
    
    cx[0] = (U->vert[0].x + U->vert[1].x + U->vert[3].x)/3.0;
    cy[0] = (U->vert[0].y + U->vert[1].y + U->vert[3].y)/3.0;
    cz[0] = (U->vert[0].z + U->vert[1].z + U->vert[3].z)/3.0;

    cx[1] = (U->vert[1].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[1] = (U->vert[1].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[1] = (U->vert[1].z + U->vert[2].z + U->vert[3].z)/3.0;

    break;
  case 5:
    q = qc;

    for(i = 0; i < 3; ++i){
      dcopy(q,X->x+qa*qb-1,qa*qb,x[i],1);
      dcopy(q,X->y+qa*qb-1,qa*qb,y[i],1);
      dcopy(q,X->z+qa*qb-1,qa*qb,z[i],1);
    }
    
    cx[0] = (U->vert[1].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[0] = (U->vert[1].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[0] = (U->vert[1].z + U->vert[2].z + U->vert[3].z)/3.0;

    cx[1] = (U->vert[0].x + U->vert[2].x + U->vert[3].x)/3.0;
    cy[1] = (U->vert[0].y + U->vert[2].y + U->vert[3].y)/3.0;
    cz[1] = (U->vert[0].z + U->vert[2].z + U->vert[3].z)/3.0;

    break;
#endif
  }
  
  /* calculate (1-theta)*x_i + xc */
  for(i = 1; i < 3; ++i){
    dsmul(q,1.0-theta,x[i],1,x[i],1);
    dsmul(q,1.0-theta,y[i],1,y[i],1);
#if DIM == 3
    dsmul(q,1.0-theta,z[i],1,z[i],1);
#endif

    dsadd(q,theta*cx[i-1],x[i],1,x[i],1);
    dsadd(q,theta*cy[i-1],y[i],1,y[i],1);
#if DIM == 3
    dsadd(q,theta*cz[i-1],z[i],1,z[i],1);
#endif
  }    
  
#if DIM == 2
  fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, F=POINT\n", zone,2,q);
#else
  fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n", zone,2,2,q);
#endif  
  h = dvector(0,qa-1);

  for(j = 0; j < q; ++j){
    for(i = 0; i < DIM; ++i){
#if DIM == 2
      fprintf(out,"%lg %lg ", x[i][j],y[i][j]);
#else
      fprintf(out,"%lg %lg %lg ", x[i][j],y[i][j],z[i][j]);
#endif
      fprintf(out," %d ",E[0][eid].edge[edge].l+2 );

      if(p < E[0][eid].edge[edge].l)
	for(k = 0; k < nfields; ++k){
	  dzero(q,h,1);
	  for(l = p; l < E[k][eid].edge[edge].l; ++l)
	    daxpy(qa,E[k][eid].edge[edge].hj[l],b->edge[0][l].a,1,h,1);
	  fprintf(out," %lg",fabs(h[idamax(qa,h,1)]));
	}
      else 
	for(k = 0; k < nfields; ++k)
	  fprintf(out," %lg",0.0);
      fputc('\n',out);
    }
#if DIM == 3
    fprintf(out,"%lg %lg %lg ", x[2][j],y[2][j],z[2][j]);
    fprintf(out," %d ",E[0][eid].edge[edge].l+2 );
    
    if(p < E[0][eid].edge[edge].l)
	for(k = 0; k < nfields; ++k){
	  dzero(q,h,1);
	  for(l = p; l < E[k][eid].edge[edge].l; ++l)
	    daxpy(qa,E[k][eid].edge[edge].hj[l],b->edge[0][l].a,1,h,1);
	  fprintf(out," %lg",fabs(h[idamax(qa,h,1)]));
	}
    else 
	for(k = 0; k < nfields; ++k)
	  fprintf(out," %lg",0.0);
    fputc('\n',out);

/*      for(k = 0; k < nfields; ++k)
	fprintf(out," %lg\n",fabs(E[k][eid].edge[edge].hj[p]));*/
#endif
    }    
  free(h);
  free_dmatrix(x,0,0);  free_dmatrix(y,0,0);  free_dmatrix(z,0,0);
}
#endif


