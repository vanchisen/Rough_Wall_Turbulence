#include <nektarF.h>
#include <map.h>
#include <gen_utils.h>
#include <rfftw.h>
extern rfftw_plan rplan, rplan_inv;
extern rfftw_plan rplan32, rplan_inv32;

Mapping *allocate_map (int NZ)
{
  Mapping *newmap    = (Mapping *) calloc (1, sizeof(Mapping));
  
  newmap->NZ   = NZ;                                     /* number of z-plns */
  newmap->time = 0.0;                                    /* time             */

  if (option("dealias")) NZ = 3*NZ/2; // make space for dealiasing

  newmap->d    = (double *) calloc (NZ, sizeof(double)); /* displacement     */
  newmap->z    = (double *) calloc (NZ, sizeof(double)); /* z   - derivative */
  newmap->zz   = (double *) calloc (NZ, sizeof(double)); /* zz  - derivative */
  newmap->t    = (double *) calloc (NZ, sizeof(double)); /* t   - derivative */
  newmap->tt   = (double *) calloc (NZ, sizeof(double)); /* tt  - derivative */
  newmap->tz   = (double *) calloc (NZ, sizeof(double)); /* tz  - derivative */
  newmap->tzz  = (double *) calloc (NZ, sizeof(double)); /* tzz - derivative */
  newmap->f    = (double *) calloc (NZ, sizeof(double)); /* forcing          */
  
  return newmap;
}

void mapField (Element_List **E, Mapping *mapx, Mapping *mapy, int dir)
{
  Element_List *U = E[0],
               *V = E[1],
               *W = E[2];
  Nek_Trans_Type f_to_p = F_to_P,
                 p_to_f = P_to_F;
  int revert = 0, mdir = dir;
  if (option("dealias")) {
      f_to_p = F_to_P32;
      p_to_f = P_to_F32;
  }

  // make sure velocity fields are in quadrature space
  if (U->fhead->state == 't') { // all 3 velocity fields should be same type
    U->Trans(U, J_to_Q);
    V->Trans(V, J_to_Q);
    W->Trans(W, J_to_Q);
    revert++;
  }

  U->Trans(U, f_to_p);
  V->Trans(V, f_to_p);
  W->Trans(W, f_to_p);

  if (dir == 0) mdir = -1;
  mapfield (E, mapx, mapy, mdir);

  U->Trans(U, p_to_f);
  V->Trans(V, p_to_f);
  W->Trans(W, p_to_f);

  if (revert && (dir != 0)) {
    U->Trans(U, Q_to_J);
    V->Trans(V, Q_to_J);
    W->Trans(W, Q_to_J);
  }

  return;
}

/* ------------------------------------------------------------------------ *
 * Mapfield() - computes U = U' - xt - xz W' and V = V' - yt - yz W'
 *              (argument and result in Physical Quadrature space)
 * ------------------------------------------------------------------------ */

void mapfield (Element_List **E, Mapping *mapx, Mapping *mapy, int dir)
{
  Element_List *U = E[0],
               *V = E[1],
               *W = E[2];
  register int k, j, i;
  rfftw_plan MPlan     = rplan, 
             MPlan_inv = rplan_inv;


  if (abs(dir) == 2) dir /= 2; // handle the extra cases due to MapField

  int NZ = U->nz;
  int NZTOT = U->nztot;
  int nZtot = NZTOT; // keep this value as it may change because of dealiasing

  if (option("dealias")) {
    NZ    = 3*NZ/2;
    NZTOT = 3*NZTOT/2;
    MPlan     = rplan32;    
    MPlan_inv = rplan_inv32;

    // zero out for dealiasing
    dzero (NZTOT-nZtot, mapx->z+nZtot, 1);
    dzero (NZTOT-nZtot, mapy->z+nZtot, 1);
#ifdef TMAP
    dzero (NZTOT-nZtot, mapx->t+nZtot, 1);
    dzero (NZTOT-nZtot, mapy->t+nZtot, 1);
#endif
  }

  // invFFT the maps to physical space
  rfftw(MPlan_inv, 1, (FFTW_COMPLEX *) mapx->z, 1, 0, 0, 0, 0);
  rfftw(MPlan_inv, 1, (FFTW_COMPLEX *) mapy->z, 1, 0, 0, 0, 0);
#ifdef TMAP
  rfftw(MPlan_inv, 1, (FFTW_COMPLEX *) mapx->t, 1, 0, 0, 0, 0);
  rfftw(MPlan_inv, 1, (FFTW_COMPLEX *) mapy->t, 1, 0, 0, 0, 0);
#endif

  for (k = 0; k < NZ; k++) {
    j = k*W->htot;
    for (i = 0; i < W->htot; i++) {
#ifdef TMAP // time dependent mesh
      U->base_h[j+i] -= dir * (mapx->t[k] + mapx->z[k] * W->base_h[j+i]);
      V->base_h[j+i] -= dir * (mapy->t[k] + mapy->z[k] * W->base_h[j+i]);
#else // only Z-deformation
      U->base_h[j+i] -= dir * mapx->z[k] * W->base_h[j+i];
      V->base_h[j+i] -= dir * mapy->z[k] * W->base_h[j+i];
#endif
    }
  }

  // FFT the maps back to fourier space
  rfftw(MPlan, 1, (FFTW_COMPLEX *) mapx->z, 1, 0, 0, 0, 0);
  rfftw(MPlan, 1, (FFTW_COMPLEX *) mapy->z, 1, 0, 0, 0, 0);
#ifdef TMAP
  rfftw(MPlan, 1, (FFTW_COMPLEX *) mapx->t, 1, 0, 0, 0, 0);
  rfftw(MPlan, 1, (FFTW_COMPLEX *) mapy->t, 1, 0, 0, 0, 0);
#endif
  return;
}

/* ------------------------------------------------------------------------ *
 * readMap() - read a single map
 * ------------------------------------------------------------------------ */

void readMap (FILE *fp, Mapping *map)
{
  char   buf[BUFSIZ];
  int    k, NZ, nZ;
  double time, dummy;

  /* read up to -- and then past -- next set of comment lines */
  
  while ((*buf = getc(fp)) != '#') fgets (buf, BUFSIZ, fp); ungetc (*buf, fp); 
  while ((*buf = getc(fp)) == '#') fgets (buf, BUFSIZ, fp); ungetc (*buf, fp); 
  
  fscanf (fp, "%lf", &time);
  map->time = time;

  fscanf (fp, "%d",  &NZ);
  nZ = min(NZ,map->NZ); // To avoid overwrites
  
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->d   + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy); // skip over rest of line
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->z   + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->zz  + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->t   + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->tt  + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->tz  + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->tzz + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);
  for (k = 0; k < nZ; k++) fscanf (fp, "%lf", map->f   + k);
  for (; k < NZ; k++) fscanf (fp, "%lf", &dummy);

  if (option("nomean")) {
    /* We explicitly force all of the variables below to be zero */
    map->d[0] = map->t[0] = map->tt[0] = 0.;
  }

  return;
}
