/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/vort_core.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <nektarF.h>
#include <gen_utils.h>
#include <rfftw.h>
#ifdef MAP
#include <map.h>
#endif
extern rfftw_plan rplan, rplan_inv;
extern rfftw_plan rplan32, rplan_inv32;

#define dnull ((double *) NULL)
#define Enull ((Element_List *) NULL)

/* Each of the following strings MUST be defined */

char *prog   = "vort";
char *usage  = "vort:  [options]  -r file[.rea]  input[.fld]\n";
char *author = "T.C.E. Warburton, C. Evangelinos";
char *rcsid  = "$Revision: 1.1 $";
char *help   = 
  "-q      ... quadrature point spacing. Default is even spacing\n"
  "-R      ... range data information. must have mesh file specified\n"
  "-b      ... make body elements specified in mesh file\n"
  "-s      ... project derivatives using the mass matrix\n"
  "-f      ... FEM storage \n"
  "-z #    ... use # planes\n"
  "-Q      ... use Q-Criterion default is Lambda2-Criterion\n"
#ifdef MAP
  "-d      ... use dealiasing\n"
  "-M file ... load in the map file\n"
  "-0      ... zero-out the average displacement and derivatives\n"
#endif
  "-n #    ... Number of mesh points. Default is 15\n";

typedef struct body{
  int N;       /* number of faces    */
  int *elmt;   /* element # of face  */ 
  int *faceid; /* face if in element */
} Body;

static Body bdy;

typedef struct range{
  double x[2];
  double y[2];
  double z[2];
} Range;

static Range *rnge;

static int  setup (FileList *f, Element_List **U, Field *fld);
static void Get_Body(FILE *fp);
#ifdef TO_FIX
static void dump_faces(FILE *out,Element_List **E, Coord X, int nel, int zone,
		       int nfields);
#endif
static void parse_util_args (int argc, char *argv[], FileList *f);
#ifdef MAP
static void Write(Element_List **E, Mapping *mapx, Mapping *mapy, FILE *out, 
		  int nfields);
#else
static void Write(Element_List **E, FILE *out, int nfields);
#endif
Bsystem *gen_bsystem(Element_List *E, Bndry *Ebc);
int readHeaderF(FILE* fp, Field *f);

void solve(Element_List *U, Element_List *Uf, 
	   Bndry *Ubc, Bsystem *Ubsys,SolveType Stype)
{
  SetBCs (U,Ubc,Ubsys);
  Solve  (U,Uf,Ubc,Ubsys,Stype);
}

#ifdef MAP
static FILE *MapFile;
static Mapping *mapx, *mapy;
#endif

main (int argc, char *argv[])
{
  int       dump=0,nfields;
  Field     fld;
  FileList  f;
  Element_List **master;
  
  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

  memset(&fld, '\0', sizeof (Field));
  dump = readHeaderF (f.in.fp, &fld);
  if (!dump) error_msg(Restart: no dumps read from restart file);

  if (fld.dim != DIM) error_msg(Restart: file is wrong dimension);

  master = (Element_List **) malloc(_MAX_FIELDS*sizeof(Element_List *));
  
  nfields = setup (&f, master, &fld);

#ifdef MAP
  Write(master,mapx,mapy,f.out.fp, nfields);
#else
  Write(master,f.out.fp, nfields);
#endif
  
  return 0;
}



/* Inner project w.r.t. orthogonal modes */

void OrthoInnerProduct(Element_List *EL, Element_List *ELf){
  Element *U, *Uf;

  for (int k = 0; k < EL->nz; k++)
    for(U=EL->flevels[k]->fhead,Uf = ELf->flevels[k]->fhead;
	U;U = U->next,Uf = Uf->next)
      Uf->Ofwd(U->h[0], Uf->h[0], Uf->lmax);

  return;
}

void OrthoJTransBwd(Element_List *EL, Element_List *ELf){
  Element *U, *Uf;

  for (int k = 0; k < EL->nz; k++)
    for(U=EL->flevels[k]->fhead,Uf = ELf->flevels[k]->fhead;
	U;U = U->next,Uf = Uf->next)
      Uf->Obwd(U->h[0], Uf->h[0], Uf->lmax);

  return;
}


void init_ortho_basis(void);

int setup (FileList *f, Element_List **U, Field *fld)
{
  register int i,j,k;
  int nfields = strlen(fld->type);
//  int nfields = 4;
  //  int nftot = strlen(fld->type) + 3;
  int nftot = nfields + 4 + 1 ;  // --> CS
  double *z, *w;
  int NZ;

/* declare new variables used for the computation of the vortex core */
  int INFO;
  double S11,S12,S13,S22,S23,S33,T12,T13,T23,p11,p12,p13,p22,p23,p33 ;
  double *EigV = dvector(0,5);
  double *Lam = dvector(0,2);
  double **Z = dmatrix(0, 2, 0, 2); 
  double **WORK = dmatrix(0, 8, 0, 8);

  ReadParams  (f->rea.fp);

  // use all the Fourier planes as a default
  if ((NZ = option("NZTOT")) < 4) {
    option_set("NZ", fld->nz);
    option_set("NZTOT", fld->nz);
    NZ = fld->nz;
  } else // otherwise use value set at command line
    option_set("NZ", NZ);

  init_rfft_struct(); // initialize RFFT structures

  if((i=iparam("NORDER-req"))!=UNSET){
    if(option("Qpts")){
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i);
    }
    else{
      iparam_set("LQUAD",i+1);
      iparam_set("MQUAD",i+1);
    }
  }
  else if(option("Qpts")){
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax);
  }
  else{
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax+1);
  }    
  
  iparam_set("MODES",iparam("LQUAD")-1);

  /* Generate the list of elements */
  U[0] = ReadMesh(f->rea.fp, strtok(f->rea.name,".")); 

  init_ortho_basis();
 
  if(f->mesh.name) Get_Body(f->mesh.fp);

  U[0]->fhead->type = fld->type[0];

  for(i = 1; i < nfields; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i];
  }

  if(1||option("oldhybrid")) // at present need this to read in old files
    set_nfacet_list(U[0]);

//  readField(f->in.fp,fld);
  readFieldF(f->in.fp, fld, U[0]);

  for(i = 0; i < nfields; ++i)
    copyfieldF(fld,i,U[i]);
  
  freeField (fld);

  for(i = nfields; i < nftot; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = 'W';
  }

  for(i=0;i<nfields;++i)
    U[i]->Trans(U[i],J_to_Q);

#ifdef MAP
  // allocate the maps
  mapx = allocate_map (NZ);
  mapy = allocate_map (NZ);

  // Read in the map file
  if (MapFile) {
    readMap (MapFile, mapx);
    readMap (MapFile, mapy);
    fclose  (MapFile);
  }

  // get the un-mapped values of the velocities
  mapField(U, mapx, mapy, -1);
#endif

  int ntot = U[0]->htot,
      nq = U[0]->nz*ntot;

// declare additional variables for the CS scheme 
  double *Ux,*Uy,*Uz,*Vx,*Vy,*Vz,*Wx,*Wy,*Wz;
  Ux=dvector(0, nq-1),Uy=dvector(0, nq-1),Uz=dvector(0, nq-1);
  Vx=dvector(0, nq-1),Vy=dvector(0, nq-1),Vz=dvector(0, nq-1);
  Wx=dvector(0, nq-1),Wy=dvector(0, nq-1),Wz=dvector(0, nq-1);
 // end declaration for CS
 
 
  // WX = Wy -  Vz
  U[1]->Grad_z (U[nfields+1]);
  dcopy(nq,U[nfields+1]->base_h,1,Vz,1);  // -->  CS
  U[2]->Grad(Enull, U[nfields], Enull, 'y');
  daxpy(nq, -1.0, U[nfields+1]->base_h, 1, U[nfields]->base_h, 1);
  U[nfields]->Set_state('p');

  // WY = Uz - Wx
  U[0]->Grad_z(U[nfields+1]);
  dcopy(nq,U[nfields+1]->base_h,1,Uz,1);  // --> CS
  U[2]->Grad  (U[nfields+2], Enull, Enull, 'x');
  daxpy(nq, -1.0, U[nfields+2]->base_h, 1, U[nfields+1]->base_h, 1);  
  U[nfields+1]->Set_state('p');  

  // WZ = Vx - Uy
  U[1]->Grad(U[nfields+2], Enull, Enull, 'x');
  U[0]->Grad(Enull, U[nfields+3], Enull, 'y');
  daxpy(nq, -1.0, U[nfields+3]->base_h, 1, U[nfields+2]->base_h, 1);
  U[nfields+2]->Set_state('p');

  // D = Ux + Vy + Wz
  U[2]->Grad_z(U[nfields+3]);
  dcopy(nq,U[nfields+3]->base_h,1,Wz,1);  // --> CS

  double *d;
  if (option("dealias")) d = dvector(0, 3*nq/2-1);
  else d = dvector(0, nq-1);

           
  dcopy(nq, U[nfields+3]->base_h, 1, d, 1);

  U[1]->Grad  (Enull, U[nfields+3], Enull, 'y');
  daxpy(nq, 1.0, U[nfields+3]->base_h, 1, d, 1);

  U[0]->Grad  (U[nfields+3], Enull, Enull, 'x');
  daxpy(nq, 1.0, d, 1, U[nfields+3]->base_h, 1);

  Nek_Trans_Type f_to_p = F_to_P,
                 p_to_f = P_to_F;
  rfftw_plan CPlan     = rplan, 
             CPlan_inv = rplan_inv;
  char        tripx = 'x',
              tripy = 'y';

  if (option("dealias")) {
    int nZ = NZ;
    NZ = 3*NZ/2;
    f_to_p = F_to_P32;
    p_to_f = P_to_F32;
    tripx = 'X';
    tripy = 'Y';
    CPlan     = rplan32;    
    CPlan_inv = rplan_inv32;
#ifdef MAP
    // zero out for dealiasing
    dzero (NZ-nZ,   mapx->z+nZ, 1);
    dzero (NZ-nZ,   mapy->z+nZ, 1);
#endif
  }

  // Take fields to physical space
  U[0]->Trans(U[0], f_to_p);
  U[1]->Trans(U[1], f_to_p);
  U[2]->Trans(U[2], f_to_p);
  U[nfields]->Trans(U[nfields], f_to_p);
  U[nfields+1]->Trans(U[nfields+1], f_to_p);
  U[nfields+3]->Trans(U[nfields+3], f_to_p);

  // Need to take the z derivatives(Uz,Vz,Wz) to Physical quadrature space 
  // too !! as they are currently in Fourier/quadrature space  --> CS
   
  double *CStmp = dvector(0, NZ -1); // create temporary vector for FFT 
   
  for( i = 0; i < ntot; ++i){
    dcopy(NZ, Vz+i, ntot, CStmp, 1);
    rfftw(rplan_inv, 1, (FFTW_COMPLEX *) CStmp, 1, 0, 0, 0, 0);
    dcopy(NZ, CStmp, 1, Vz+i, ntot);
  }

  for( i = 0; i < ntot; ++i){
    dcopy(NZ, Uz+i, ntot, CStmp, 1);
    rfftw(rplan_inv, 1, (FFTW_COMPLEX *) CStmp, 1, 0, 0, 0, 0);
    dcopy(NZ, CStmp, 1, Uz+i, ntot);
  }
  
 
  for(i = 0; i < ntot; ++i){
    dcopy(NZ, Wz+i, ntot, CStmp, 1);
    rfftw(rplan_inv, 1, (FFTW_COMPLEX *) CStmp, 1, 0, 0, 0, 0);
    dcopy(NZ, CStmp, 1, Wz+i, ntot);
  }
  
  free(CStmp);

#ifdef MAP
  // invFFT the maps to physical space
  rfftw(CPlan_inv, 1, (FFTW_COMPLEX *)   mapx->z, 1, 0, 0, 0, 0);
  rfftw(CPlan_inv, 1, (FFTW_COMPLEX *)   mapy->z, 1, 0, 0, 0, 0);
#endif

  // Correction terms for x-component of vorticity
  // Calculate Vx 
  U[1]->Grad_h (U[1]->base_h, d, dnull, dnull, tripx);
  dcopy(nq,d,1,Vx,1);  // --> CS 
#ifdef MAP
 // add the correction term
  for (k = 0; k < NZ; k++){
    daxpy (ntot, mapx->z[k], d+k*ntot, 1, U[nfields]->base_h+k*ntot, 1);
    daxpy (ntot, -mapx->z[k], d+k*ntot, 1, Vz+k*ntot, 1);  // --> CS
  }
#endif

  // Calculate Vy
  U[1]->Grad_h (U[1]->base_h, dnull, d, dnull, tripy);
  dcopy(nq,d,1,Vy,1);  // --> CS
#ifdef MAP
  // add the correction term
  for (k = 0; k < NZ; k++){
    daxpy (ntot, mapy->z[k], d+k*ntot, 1, U[nfields]->base_h+k*ntot, 1);
    daxpy (ntot, -mapy->z[k], d+k*ntot, 1, Vz+k*ntot, 1);  // --> CS
  }
#endif

  // Correction terms for y-component of vorticity
  // Calculate Ux
  U[0]->Grad_h (U[0]->base_h, d, dnull, dnull, tripx);
  dcopy(nq,d,1,Ux,1);  // --> CS
#ifdef MAP
  // add the correction term
  for (k = 0; k < NZ; k++){
    daxpy (ntot, -mapx->z[k], d+k*ntot, 1, U[nfields+1]->base_h+k*ntot, 1);
    daxpy (ntot, -mapx->z[k], d+k*ntot, 1, Uz+k*ntot, 1);  // --> CS
  }
#endif

  // Calculate Uy
  U[0]->Grad_h (U[0]->base_h, dnull, d, dnull, tripy);
  dcopy(nq,d,1,Uy,1);  // --> CS
#ifdef MAP
  // add the correction term
  for (k = 0; k < NZ; k++){
    daxpy (ntot, -mapy->z[k], d+k*ntot, 1, U[nfields+1]->base_h+k*ntot, 1);
    daxpy (ntot, -mapy->z[k], d+k*ntot, 1, Uz+k*ntot, 1);  // --> CS
  }
#endif

  // Correction terms for divergence
  // Calculate Wx
  U[2]->Grad_h (U[2]->base_h, d, dnull, dnull, tripx);
  dcopy(nq,d,1,Wx,1);  // --> CS
#ifdef MAP
  // add the correction term
  for (k = 0; k < NZ; k++){
    daxpy (ntot, -mapx->z[k], d+k*ntot, 1, U[nfields+3]->base_h+k*ntot, 1);
    daxpy (ntot, -mapx->z[k], d+k*ntot, 1, Wz+k*ntot, 1);  // --> CS
  }
#endif

  // Calculate Wy
  U[2]->Grad_h (U[2]->base_h, dnull, d, dnull, tripy);
  dcopy(nq,d,1,Wy,1);  // --> CS
#ifdef MAP
  // add the correction term
  for (k = 0; k < NZ; k++){
    daxpy (ntot, -mapy->z[k], d+k*ntot, 1, U[nfields+3]->base_h+k*ntot, 1);
    daxpy (ntot, -mapy->z[k], d+k*ntot, 1, Wz+k*ntot, 1);  // --> CS
  }
#endif
  
  // Start the CS identification scheme   
  // Set up the symmetric (Sij) and anti-symmetric parts of the velocity 
  // gradient tensor at each quadrature points  
  if(option("QCRITERION"))
    fprintf(stderr,"Using Q-Criterion... \n");
  else
    fprintf(stderr,"Using Lambda2-Criterion... \n");


   for (k = 0; k < NZ; k++){
     for (i = 0; i < ntot; i++){
       
       S11=S12=S13=S22=S23=S33=T12=T13=T23=0.0;/* initialise */
       p11=p12=p13=p22=p23=p33=0.0;
       U[nfields+4]->base_h[i+k*ntot]=0.0;
       
       S11 = Ux[i+k*ntot]                                              ;
       S12 = 0.5*(Uy[i+k*ntot] + Vx[i+k*ntot])                         ;
       S13 = 0.5*(Uz[i+k*ntot] + Wx[i+k*ntot])                         ;
       S22 = Vy[i+k*ntot]                                              ;
       S23 = 0.5*(Vz[i+k*ntot] + Wy[i+k*ntot])                         ;
       S33 = Wz[i+k*ntot]                                              ;
       
      if(option("QCRITERION")) {
       U[nfields+4]->base_h[i+k*ntot] = -0.5*(S11*S11+S22*S22+S33*S33)
                -(Uy[i+k*ntot]*Vx[i+k*ntot]+Wy[i+k*ntot]*Vz[i+k*ntot]+Uz[i+k*ntot]*Wx[i+k*ntot]);

      }
      else//default is lambda2 
      {
       T12 = 0.5*(Uy[i+k*ntot] - Vx[i+k*ntot])                         ;
       T13 = 0.5*(Uz[i+k*ntot] - Wx[i+k*ntot])                         ;
       T23 = 0.5*(Vz[i+k*ntot] - Wy[i+k*ntot])                         ;
       
       /* now set up pij = (Sij)**2 + (Tij)**2.  Then extract the 
	  eigenvalues of this symmetric matrix. */
       p11 = pow(S11,2)+pow(S12,2)+pow(S13,2)-pow(T12,2)-pow(T13,2)     ;
       p12 = S11*S12+S12*S22+S13*S23-T13*T23                            ;
       p13 = S11*S13+S12*S23+S13*S33+T12*T23                            ;
       p22 = pow(S12, 2)+pow(S22, 2)+pow(S23,2)-pow(T12,2)-pow(T23,2)   ;
       p23 = S12*S13+S22*S23+S23*S33-T12*T13                            ;
       p33 = pow(S13, 2)+pow(S23, 2)+pow(S33, 2)-pow(T13, 2)-pow(T23, 2);
       
       /* Store the matrix pij in a packed form */
       EigV[0] = p11      ;
       EigV[1] = p12      ;
       EigV[2] = p22      ;
       EigV[3] = p13      ;
       EigV[4] = p23      ;
       EigV[5] = p33      ;
	       

       /* Call the lapack routine DSPEV to compute the eigenvalues of 
	  EigV matrix */
       
       dspev('N','U',3,EigV,Lam,*Z,3,*WORK,INFO);       
       if (INFO) error_msg("WARNING: Vortex Core Method -dspev- INFO is not zero !!");
       U[nfields+4]->base_h[i+k*ntot] = Lam[1];
      }//end of lambda2-Criterion

     }
   }
   
  // Bring fields back to fourier space
  U[0]->Trans(U[0], p_to_f);
  U[1]->Trans(U[1], p_to_f);
  U[2]->Trans(U[2], p_to_f);
  U[nfields]->Trans(U[nfields], p_to_f);
  U[nfields+1]->Trans(U[nfields+1], p_to_f);
  U[nfields+3]->Trans(U[nfields+3], p_to_f);  
  U[nfields+4]->Trans(U[nfields+4], p_to_f); // --> CS
  
#ifdef MAP
  // FFT the maps back to fourier space
  rfftw(CPlan, 1, (FFTW_COMPLEX *)   mapx->z, 1, 0, 0, 0, 0);
  rfftw(CPlan, 1, (FFTW_COMPLEX *)   mapy->z, 1, 0, 0, 0, 0);
#endif
  
  free (d),free(Ux),free(Uy),free(Uz),free(Vx),free(Vy),
    free(Vz),free(Wx),free(Wy),free(Wz);
  
  if(option("SOLVE")){

    Element_List *T  = U[0]->flevels[0]->gen_aux_field('T');
    T->Cat_mem();
    Bsystem *Bsys = gen_bsystem(T, (Bndry*)NULL);
    Element_List *Tf = T->gen_aux_field('T');
    Tf->Cat_mem();
    Bsys->lambda = (Metric*) calloc(U[0]->nel, sizeof(Metric));
    GenMat(T, NULL, Bsys, Bsys->lambda, Mass);
    
  if(option("QCRITERION"))
    fprintf(stderr,"Projecting Q and Vorticity \n");
  else
    fprintf(stderr,"Projecting Lamb and Vorticity \n");

    for (k = 0; k < U[0]->nz; k++) {
      dcopy(U[nfields]->htot, U[nfields]->flevels[k]->base_h, 1, 
	    Tf->base_h, 1);
      Tf->Set_state('p');
 //zwang 06032018
      Tf->Iprod(Tf);
      solve(T, Tf, NULL, Bsys, Mass);
      T->Trans(U[nfields]->flevels[k], J_to_Q);
      
      dcopy(U[nfields+1]->htot, U[nfields+1]->flevels[k]->base_h, 1, 
	    Tf->base_h, 1);
      Tf->Set_state('p');
 //zwang 06032018
      Tf->Iprod(Tf);
      solve(T, Tf, NULL, Bsys, Mass);
      T->Trans(U[nfields+1]->flevels[k], J_to_Q);
      
      dcopy(U[nfields+2]->htot, U[nfields+2]->flevels[k]->base_h, 1, 
	    Tf->base_h, 1);
      Tf->Set_state('p');
 //zwang 06032018
      Tf->Iprod(Tf);
      solve(T, Tf, NULL, Bsys, Mass);
      T->Trans(U[nfields+2]->flevels[k], J_to_Q);
      
      dcopy(U[nfields+3]->htot, U[nfields+3]->flevels[k]->base_h, 1, 
	    Tf->base_h, 1);
      Tf->Set_state('p');
 //zwang 06032018
      Tf->Iprod(Tf);
      solve(T, Tf, NULL, Bsys, Mass);
      T->Trans(U[nfields+3]->flevels[k], J_to_Q);


      dcopy(U[nfields+4]->htot, U[nfields+4]->flevels[k]->base_h, 1, 
            Tf->base_h, 1);
      Tf->Set_state('p');
 //zwang 06032018
      Tf->Iprod(Tf);
      solve(T, Tf, NULL, Bsys, Mass);
      T->Trans(U[nfields+4]->flevels[k], J_to_Q);

      //      dcopy(T->hjtot, T->base_hj, 1, U[nfields+3]->base_hj, 1);
    }
  }

  for(i=0;i<nftot;++i)
    OrthoInnerProduct(U[i],U[i]);
  
  if(!option("Qpts")){  /* reset quadrature points */ 
    init_ortho_basis();
    reset_bases();
    
    for(j=2;j<QGmax+5;++j){
      getzw(j,&z,&w,'a');
      for(i = 0; i < j; ++i) z[i] = 2.0*i/(double)(j-1) -1.0;
      
      getzw(j,&z,&w,'b');
      for(i = 0; i < j; ++i) z[i] = 2.0*i/(double)(j-1) -1.0;
    } 
  }

  for(i=0;i<nftot;++i)
    OrthoJTransBwd(U[i],U[i]);

  for(i = 0; i < nftot; ++i){
    U[i]->Set_state('p');
    U[i]->Trans(U[i], F_to_P);
  }

#ifdef MAP
  CPlan_inv = rplan_inv;
  // invFFT the maps to physical space
  rfftw(CPlan_inv, 1, (FFTW_COMPLEX *)   mapx->d, 1, 0, 0, 0, 0);
  rfftw(CPlan_inv, 1, (FFTW_COMPLEX *)   mapy->d, 1, 0, 0, 0, 0);
#endif

  return nftot; 
}

static int Check_range(Element *E);

#ifdef MAP
static void Write(Element_List **E, Mapping *mapx, Mapping *mapy, FILE *out, 
		  int nfields)
#else
static void Write(Element_List **E, FILE *out, int nfields)
#endif
{
  register int i,j,k,n;
  const int    qa = (*E)->fhead->qa, qb = (*E)->fhead->qb, 
               qc = (*E)->fhead->qc;
  int      qt,zone;
  //  int      qa,qb,qc,qt,zone;
  const int    nel = E[0]->nel,
               nz  = E[0]->nz;
  //  double   *z,*w, ave;
  Coord    X;
  //  char     *outformat;
  //  char     Der[] = {'x','y','z'};
  Element  *F;

  /* take derivative of first field */

  X.x = dvector(0,QGmax*QGmax*nz-1);
  X.y = dvector(0,QGmax*QGmax*nz-1);

  fprintf(out,"VARIABLES = x y z");
  qt = qa*qb;
  
  for(i = 0; i < nfields-5; ++i)
    fprintf(out," %c", E[i]->fhead->type);
  
  if(option("QCRITERION"))
  fprintf(out," Vorticity_x Vorticity_y Vorticity_z Divergence Q");
  else
  fprintf(out," Vorticity_x Vorticity_y Vorticity_z Divergence Lam");
  
  fputc('\n',out);
  
  if(option("FEstorage")){
    int cnt;
    int np=0;
    int nelmts=0;
    int nz = E[0]->nz;
    double ***num;

//first count the number of elements and points
    for(k = 0; k < E[0]->nel; ++k){
      F= E[0]->flist[k];

      if(F->identify() == Nek_Tri){
        nelmts += (qa-1)*(qa-1)*nz;
//        np += qa*((qa+1)/2)*(nz+1);
// NOT sure why for Triangle I should use this....  zwang 071014
        np += qa*qa*(nz+1);
       }
      else{
	    nelmts += (qa-1)*(qa-1)*nz;
	    np += qa*qa*(nz+1);
      }
    }
//number of points and elments
    fprintf(stderr,"number  of points:  %d  number of elements: %d \n",np, nelmts);

    fprintf(out,"ZONE  NODES=%d, ELEMENTS=%d, DATAPACKING=POINT, ZONETYPE=FEBRICK \n",np,nelmts);
    

    for(k = 0,zone=0; k < E[0]->nel; ++k){
      if(Check_range(E[0]->flist[k])){
	    E[0]->flist[k]->coord(&X);
      F= E[0]->flist[k];
      qt = F->qtot;

	for(j = 0; j < E[0]->nz; ++j)
	  for(i = 0; i < qt; ++i){
#ifdef MAP
	   fprintf(out,"%lg %lg %lg", X.x[i] + mapx->d[j], X.y[i] + mapy->d[j], zmesh(j));
#else
	   fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
#endif
	    for(n = 0; n < nfields; ++n)
	      fprintf(out," %lg",E[n]->flevels[j]->flist[k]->h[0][i]);
	    fputc('\n',out);
	  }

// plane nz+1
    for(i = 0; i < F->qtot; ++i){
#ifdef MAP
	fprintf(out,"%lg %lg %lg", X.x[i] + mapx->d[0], X.y[i] + mapy->d[0], zmesh(j));
#else
	fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
#endif
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n]->flevels[0]->flist[k]->h[0][i]);
	fputc('\n',out);
      }

      }
    }
//conectivity...    
    /* numbering array */
    num = dtarray(0,qa-1,0,qa-1,0,nz);


   for(int eid = 0,n=0; eid < E[0]->nel; ++eid){
      F  = E[0]->flist[eid];

    if(Check_range(F)){
     switch(F->identify()){
    
     case Nek_Tri:
     case Nek_Quad:
     for(cnt = 1, k = 0; k < nz+1; ++k)
      for(j = 0; j < qa; ++j)
        for(i = 0; i < qa; ++i, ++cnt)
          num[i][j][k] = cnt;


         for(k=0; k < nz; ++k)
            for(j = 0; j < qa-1; ++j){
              for(i = 0; i < qa-1; ++i){
                fprintf(out,"%d %d %d %d %d %d %d %d \n",
                        n+(int) num[i][j][k],
                        n+(int) num[i+1][j][k],
                        n+(int) num[i+1][j+1][k],
                        n+(int) num[i][j+1][k],
                        n+(int) num[i][j][k+1],
                        n+(int) num[i+1][j][k+1],
                        n+(int) num[i+1][j+1][k+1],
                        n+(int) num[i][j+1][k+1]);
              }
            }
          n += (nz+1)*qa*qa;
    break;
/*
    case Nek_Tri:

     for(cnt = 1, k = 0; k < nz; ++k)
      for(j = 0; j < qa; ++j)
        for(i = 0; i < qa-j; ++i, ++cnt)
          num[i][j][k] = cnt;

      for(cnt=1, j = 0; j < qa; ++j)
        for(i = 0; i < qa-j; ++i, ++cnt)
          num[i][j][nz] = cnt;

       for(k=0; k < nz; ++k)
          for(j = 0; j < qa-1; ++j){
              for(i = 0; i < qa-1-j; ++i){
                fprintf(out,"%d %d %d %d %d %d %d %d\n",
                        n+(int) num[i][j][k],
                        n+(int) num[i+1][j][k],
                        n+(int) num[i+1][j+1][k],
                        n+(int) num[i][j+1][k],
                        n+(int) num[i][j][k+1],
			n+(int) num[i][j][k+1],
                        n+(int) num[i][j+1][k+1],
			n+(int) num[i][j+1][k+1]
);
			}
	      }
	      n += nz*(qa*(qa+1))/2;

    break;
*/
       }
     }

   }

    free_dtarray(num,0,0,0);

 }//end of FEStorage
 else {
  for(k = 0,zone=0; k < nel; ++k){
    F = E[0]->flist[k];
    if(Check_range(F)){
      F->coord(&X);
      fprintf(out,"ZONE T=\"Element %d\", I=%d, J=%d, K=%d, F=POINT\n",
	      ++zone,F->qa,F->qb,E[0]->nz+1);
      for(j = 0; j < E[0]->nz; ++j)
	for(i = 0; i < F->qtot; ++i){
#ifdef MAP
	  fprintf(out,"%lg %lg %lg", X.x[i] + mapx->d[j], X.y[i] + mapy->d[j], zmesh(j));
#else
	  fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
#endif
	  for(n = 0; n < nfields; ++n)
	    fprintf(out," %lg",E[n]->flevels[j]->flist[k]->h[0][i]);
	  fputc('\n',out);
	}
      for(i = 0; i < F->qtot; ++i){
#ifdef MAP
	fprintf(out,"%lg %lg %lg", X.x[i] + mapx->d[0], X.y[i] + mapy->d[0], zmesh(j));
#else
	fprintf(out,"%lg %lg %lg", X.x[i], X.y[i], zmesh(j));
#endif
	for(n = 0; n < nfields; ++n)
	  fprintf(out," %lg",E[n]->flevels[0]->flist[k]->h[0][i]);
	fputc('\n',out);
      }
    }
  }
}//end of the output format that each element as a zone
  
#ifdef TO_FIX
  if(bdy.N) dump_faces(out,E,X,k,zone,nfields);
#endif
  free(X.x); free(X.y);
  return;
}

#ifdef EXCLUDE
static int Check_range(Element *E){
  if(rnge){
    register int i;

    for(i = 0; i < Nvert; ++i){
      if((E->vert[i].x < rnge->x[0])||(E->vert[i].x > rnge->x[1])) return 0;
      if((E->vert[i].y < rnge->y[0])||(E->vert[i].y > rnge->y[1])) return 0;
    }
  }
  return 1;
}
#else
static int Check_range(Element *E){
  if(rnge){
    register int i;
    
    for(i = 0; i < E->Nverts; ++i){
      if((E->vert[i].x > rnge->x[0])&&(E->vert[i].x < rnge->x[1]) 
	 && (E->vert[i].y > rnge->y[0])&&(E->vert[i].y < rnge->y[1])) return 1;
    }
    return 0;
  }
  else
    return 1;
}
#endif

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }

  iparam_set("Nout", UNSET);

  while (--argc && (*++argv)[0] == '-') {
    //   while (c = *++argv[0])                  /* more to parse... */
      switch (c = *++argv[0]) {
      case 'b':
	option_set("Body",1);
	break;
      case 'f':
	option_set("FEstorage",1);
	break;
      case 'R':
	option_set("Range",1);
	break;
      case 'q':
	option_set("Qpts",1);
	break;
      case 's':
	option_set("SOLVE",1);
	break;
      case 'Q':
      option_set("QCRITERION",1);
	break;
      case 'z':                           
	if (*++argv[0]) 
	  option_set("NZTOT", atoi(*argv));
	else {
	  option_set("NZTOT", atoi(*++argv));
	  argc--;
	}
	break;
#ifdef MAP
      case 'd':
	option_set("dealias",1);
	break;
      case 'M':                           /* read the map from a file */
	if (*++argv[0])
	  strcpy(fname, *argv);
	else {
	  strcpy(fname, *++argv);
	  argc--;
	  ++argv;
	}
	if (!(MapFile = fopen(fname,"r"))) {
	  fprintf(stderr, "%s: unable to open the map file -- %s\n", 
		  prog, *argv);
	  exit(1);
	}
	break;
      case '0':
	option_set("nomean",1);
	break;
#endif
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }
  
  /* open input file */

  if ((*argv)[0] == '-') {
    f->in.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.fld", *argv);
      if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->in.name = strdup(fname);
  }

  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}

static void Get_Body(FILE *fp){
  register int i;
  char buf[BUFSIZ],*s;
  int  N;

  if(option("Range")){
    rnge = (Range *)malloc(sizeof(Range));
    rewind(fp);  /* search for range data */
    while(s && !strstr((s=fgets(buf,BUFSIZ,fp)),"Range"));

    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->x,rnge->x+1);
    fgets(buf,BUFSIZ,fp);
    sscanf(buf,"%lf%lf",rnge->y,rnge->y+1);
  }

  if(option("Body")){
    rewind(fp);/* search for body data  */
    while(s && !strstr((s=fgets(buf,BUFSIZ,fp)),"Body"));   
    
    if(s!=NULL){
      
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&N);
      
      bdy.N = N;
      bdy.elmt   = ivector(0,N-1);
      bdy.faceid = ivector(0,N-1);
      
      for(i = 0; i < N; ++i){
	fgets(buf,BUFSIZ,fp);
	sscanf(buf,"%d%d",bdy.elmt+i,bdy.faceid+i);
	--bdy.elmt[i];
	--bdy.faceid[i];
      }
    }
  }
}

#ifdef TO_FIX
static void dump_faces(FILE *out,Element_List **U, Coord X, int nel, int zone, int nfields){
  Element *F;
  int qa, qb, qc,fac, cnt;
  register int i,j,k,l,n;
  double **tmp; 
  int data_skip = 0;
  int size_skip = 0;
  
  tmp  = dmatrix(0, nfields, 0, QGmax*QGmax*QGmax-1);
  
  k = 0;
  for(l=0;l<bdy.N;++l){
    F = U[0]->flist[bdy.elmt[l]];

    fac = bdy.faceid[l];
    
    if(F->identify() == Nek_Tet)
      switch(fac){
      case 0:
	qa = F->qa;      qb = F->qb;
	break;
      case 1:
	qa = F->qa;      qb = F->qc;
	break;
      case 2: case 3:
	qa = F->qb;      qb = F->qc;
	break;
      }
    else if(F->identify() == Nek_Hex){
      switch(fac){
      case 0: case 5:
	qa = F->qa;      qb = F->qb;
	break;
      case 1: case 3:
	qa = F->qa;      qb = F->qc;
	break;
      case 2: case 4:
	qa = F->qb;      qb = F->qc;
	break;
      }
    }
    else if(F->identify() == Nek_Prism){
      switch(fac){
      case 0: 
	qa = F->qa;      qb = F->qb;
	break;
      case 1: case 3:
	qa = F->qa;      qb = F->qc;
	break;
      case 2: case 4:
	qa = F->qb;      qb = F->qc;
	break;
      }
    }
      
    cnt = F->qa*F->qb;
    
    F->GetFaceCoord(fac, &X);
    
    fprintf(out,"ZONE T=\"Triangle %d\", I=%d, J=%d, K=%d, F=POINT\n",
	    ++zone,qa,qb,1);

#if 0
    for(i = 0; i < cnt; ++i)
      fprintf(out,"%lg ", X.x[i]);
    fputc('\n',out);
    for(i = 0; i < cnt; ++i)
      fprintf(out,"%lg ", X.y[i]);
    fputc('\n',out);
    for(i = 0; i < cnt; ++i)
      fprintf(out,"%lg ", X.z[i]);
    fputc('\n',out);
#endif
    for(n = 0; n < nfields; ++n)
      U[n]->flist[F->id]->GetFace(**U[n]->flist[F->id]->h_3d, fac, tmp[n]);

    for(i = 0; i < cnt; ++i){
      fprintf(out,"%lg %lg %lg ",X.x[i], X.y[i], X.z[i]);
      for(n = 0; n < nfields; ++n)
	fprintf(out,"%lg ",tmp[n][i]);
      fputc('\n',out);
    }
    ++k;
  } 
  free_dmatrix(tmp,0,0);
}
#endif
