/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/extractF.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <nektarF.h>
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
static char  usage_[128];

char *prog   = "extract";
char *usage  = "extract:  [options] -m ext_file -r file[.rea] input[.fld]\n";
char *author = "";
char *rcsid  = "";
char *help   = 
  " This routine will extract data described in the ext_file \n"
  " from the field file input[.fld]. It also requires the file file[.rea]\n";
/* ---------------------------------------------------------------------- */

typedef struct intepts{
  int  npts;
  Coord X;
} Intepts;

static void setup (FileList *f, Element_List **U, Field *fld);
static void parse_util_args (int argc, char *argv[], FileList *f);
static Intepts *Get_interp_pts(FILE *fp);
static void Interp_pts(FILE *fp, Intepts *I, Element_List **U, int nfields);
static void Fourier_interp(Element_List **U, Coord *X, double *ans, int nfields);

int PLANE = 0;
int PLANE_NX, PLANE_NY;

int BOX = 0;
int BOX_NX, BOX_NY, BOX_NZ;
int readHeaderF(FILE* fp, Field *f);

main (int argc, char *argv[])
{
  register int  i,k;
  int       dump=0,nfields;
  Field     fld;
  FileList  f;
  Element_List   **master;
  Intepts   *I;

  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

  memset(&fld, '\0', sizeof (Field));

  dump = readHeaderF (f.in.fp, &fld);
  if (!dump         ) error_msg(Restart: no dumps read from restart file);
  if (fld.dim != DIM) error_msg(Restart: file if wrong dimension);


  option_set("NZTOT", fld.nz);  option_set("NZ", fld.nz);

  master = (Element_List **)
    malloc((nfields = strlen(fld.type)+3)*fld.nz*sizeof(Element_List *));
  
  setup (&f, master, &fld);
  
  I = Get_interp_pts(f.mesh.fp);
  
  Interp_pts(f.out.fp,I,master,nfields);

  return;
}

static void Interp_pts(FILE *fp, Intepts *I, Element_List **U, int nfields){
  register int i,j;
  double  *ui;
  Coord   X;

  ui = dvector(0,nfields-1);
  X.x = dvector(0,DIM+1);
  
  X.y = X.x+1;
  X.z = X.y+1;

  if(PLANE || BOX)
    fprintf(fp, "VARIABLES = ");

  /* print header */
  fprintf(fp,"x y z ");

  for(i = 0; i < nfields; ++i)
    fprintf(fp,"%c ",U[i]->fhead->type);
  fputc('\n',fp);

  if(PLANE)
    fprintf(fp,"ZONE I=%d, J=%d, K=1, F=POINT\n", PLANE_NX, PLANE_NY);
  if(BOX)
    fprintf(fp,"ZONE I=%d, J=%d, K=%d, F=POINT\n", BOX_NX, BOX_NY, BOX_NZ);

  for(i = 0; i < I->npts; ++i){
    X.x[0] = I->X.x[i]; 
    X.y[0] = I->X.y[i];
    X.z[0] = I->X.z[i];

    fprintf(fp,"%lf %lf %lf ",X.x[0],X.y[0],X.z[0]);

    Fourier_interp(U, &X, ui, nfields);
    for(j = 0; j < nfields; ++j)
      fprintf(fp,"%lf ",ui[j]);
    fputc('\n',fp);
  }

  free(ui);
}

static Intepts *Get_interp_pts(FILE *fp){
  int trip = 0;
  register int i,j,k;
  char buf[BUFSIZ],*s;
  Intepts *I;
  
  I = (Intepts *)malloc(sizeof(Intepts));

  /* check for list of data points */
  rewind(fp);
  
  if(fp == stdin) trip = 1;
  if(trip) fprintf(stderr,"What type of input? (list, line, plane, box)\n");

  while(s=fgets(buf,BUFSIZ,fp)){
    if(strstr(s,"list")){
      if(trip) fprintf(stderr,"Number of points in list\n");

      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&I->npts);
      
      I->X.x = dvector(0,I->npts-1);
      I->X.y = dvector(0,I->npts-1);
      I->X.z = dvector(0,I->npts-1);

      for(i = 0; i < I->npts; ++i){
	if(trip) fprintf(stderr,"Enter %d point (x,y,z) value\n",i+1);
	fscanf(fp,"%lf%lf%lf",I->X.x+i,I->X.y+i,I->X.z+i);
      }

      break;
    }
    else if(strstr(s,"line")){
      double start[DIM+1],stop[DIM+1];

      if(trip) fprintf(stderr,"Number of points in line\n");

      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&I->npts);

      /* get co-ordinates of beginning and end of line */
      if(trip) fprintf(stderr,"Enter co-ordinate of beginning of line\n");
      for(i = 0; i < DIM+1; ++i) fscanf(fp,"%lf",start+i);
      if(trip) fprintf(stderr,"Enter end co-ordinate of end of line\n");
      for(i = 0; i < DIM+1; ++i) fscanf(fp,"%lf",stop+i);

      I->X.x = dvector(0,I->npts-1);
      I->X.y = dvector(0,I->npts-1);
      I->X.z = dvector(0,I->npts-1);

      for(i = 0; i < I->npts; ++i){
	I->X.x[i] = i*(stop[0] - start[0])/(I->npts-1.0) + start[0];
	I->X.y[i] = i*(stop[1] - start[1])/(I->npts-1.0) + start[1];
	I->X.z[i] = i*(stop[2] - start[2])/(I->npts-1.0) + start[2];
      }
      break;
    }
    else if(strstr(s,"plane")){
      int nx,ny;
      double X1[DIM+1],X2[DIM+1],X3[DIM+1],X4[DIM+1];
      
      PLANE = 1;
      if(trip) fprintf(stderr,"For a plane specified in anti-clockwise"
		       " direction\n");
      if(trip) fprintf(stderr,"Number of points in line from point 1 to 2\n");
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&nx);

      if(trip) fprintf(stderr,"Number of points in line from point 1 to 4\n");
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&ny);

      PLANE_NX = nx;
      PLANE_NY = ny;

      I->npts = nx*ny;

      /* get co-ordinates of plane in counter clockwise direction */
      if(trip) fprintf(stderr,"Enter co-ordinate of first point\n");
      for(i = 0; i < DIM+1; ++i) fscanf(fp,"%lf",X1+i);
      if(trip) fprintf(stderr,"Enter co-ordinate of second point\n");
      for(i = 0; i < DIM+1; ++i) fscanf(fp,"%lf",X2+i);
      if(trip) fprintf(stderr,"Enter co-ordinate of third point\n");
      for(i = 0; i < DIM+1; ++i) fscanf(fp,"%lf",X3+i);
      if(trip) fprintf(stderr,"Enter co-ordinate of fourth point\n");
      for(i = 0; i < DIM+1; ++i) fscanf(fp,"%lf",X4+i);

      I->X.x = dvector(0,I->npts-1);
      I->X.y = dvector(0,I->npts-1);
      I->X.z = dvector(0,I->npts-1);

      /* bilinear blend of plane */
      for(j = 0; j < ny; ++j)
	for(i = 0; i < nx; ++i){
	  I->X.x[i+j*nx]  = (i*X2[0]/(nx-1.0) + X1[0]*(nx-i-1)/(nx-1.0)) *
	                                              (ny-j-1.0)/(ny-1.0);
	  I->X.x[i+j*nx] += (i*X3[0]/(nx-1.0) + X4[0]*(nx-i-1)/(nx-1.0)) *
	                                                       j/(ny-1.0);

	  I->X.y[i+j*nx]  = (i*X2[1]/(nx-1.0) + X1[1]*(nx-i-1)/(nx-1.0)) *
	                                              (ny-j-1.0)/(ny-1.0);
	  I->X.y[i+j*nx] += (i*X3[1]/(nx-1.0) + X4[1]*(nx-i-1)/(nx-1.0)) *
	                                                       j/(ny-1.0);

	  I->X.z[i+j*nx]  = (i*X2[2]/(nx-1.0) + X1[2]*(nx-i-1)/(nx-1.0)) *
	                                              (ny-j-1.0)/(ny-1.0);
	  I->X.z[i+j*nx] += (i*X3[2]/(nx-1.0) + X4[2]*(nx-i-1)/(nx-1.0)) *
	    j/(ny-1.0);
	}
      break;
    }
    else if(strstr(s,"box")){
      int nx,ny,nz, cnt;
      double X1[DIM+1],X2[DIM+1];
      
      BOX = 1;
      if(trip) fprintf(stderr,"For a (Cartesian) box\n");
      if(trip) fprintf(stderr,"Number of points in x-direction\n");
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&nx);

      if(trip) fprintf(stderr,"Number of points in y-direction\n");
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&ny);

      if(trip) fprintf(stderr,"Number of points in z-direction\n");
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&nz);


      BOX_NX = nx;
      BOX_NY = ny;
      BOX_NZ = nz;

      I->npts = nx*ny*nz;

      /* Get co-ordinates of two opposite corners of box */
      if(trip) fprintf(stderr,"Enter co-ordinate of first vertex of boxt\n");
      for(i = 0; i < DIM+1; ++i) fscanf(fp,"%lf",X1+i);
      if(trip) fprintf(stderr,"Enter co-ordinate of opposite vertex\n");
      for(i = 0; i < DIM+1; ++i) fscanf(fp,"%lf",X2+i);

      I->X.x = dvector(0,I->npts-1);
      I->X.y = dvector(0,I->npts-1);
      I->X.z = dvector(0,I->npts-1);
      
      /* calculate box co-ords */
      for(k = 0; k < nz; ++k)
	for(j = 0; j < ny; ++j)
	  for(i = 0; i < nx; ++i){
	    cnt = i+j*nx+k*nx*ny;
	    I->X.x[cnt] = (X1[0]*(nx-1-i) + X2[0]*i)/(nx-1);
	    I->X.y[cnt] = (X1[1]*(ny-1-j) + X2[1]*j)/(ny-1);
	    I->X.z[cnt] = (X1[2]*(nz-1-k) + X2[2]*k)/(nz-1);
	  }
      
      break;
    }

  }

  if(!s){ fprintf(stderr,"No extract  info found\n"), exit(-1);}

  return I;
}

static void setup (FileList *f, Element_List **U, Field *fld)
{
  int i,k;
  int nfields = strlen(fld->type);

  ReadParams  (f->rea.fp);

  iparam_set("LQUAD",fld->lmax+1);
  iparam_set("MQUAD",fld->lmax);
  
  iparam_set("MODES",fld->lmax);

  /* Generate the list of elements */
  U[0] = ReadMesh(f->rea.fp, strtok(f->rea.name,".")); 
  /* This must be set for library to work properly */
  ReadSetLink     (f->rea.fp,U[0]->fhead);
  
  readFieldF(f->in.fp, fld, U[0]);
  U[0]->fhead->type = fld->type[0];
  copyfieldF(fld,0,U[0]);
  
  for(i = 1; i < nfields; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i];
    copyfieldF(fld,i,U[i]);
    U[i]->Trans(U[i], J_to_Q);
  }
  
  U[nfields]   = U[0]->gen_aux_field('a');
  U[nfields+1] = U[0]->gen_aux_field('b');
  U[nfields+2] = U[0]->gen_aux_field('c');

  double  *d = dvector(0, U[0]->nz*U[0]->htot-1);
  int nq = U[0]->nz*U[0]->htot;
  // WX = Vz - Wy
  U[0]->Grad_z(U[nfields]);
  U[1]->Grad(0, U[nfields+1], 0, 'y');
  daxpy(nq, -1.0, U[nfields+1]->base_h, 1, U[nfields]->base_h, 1);
  U[nfields]->Set_state('p');
  
  // WY = Uz - Wx
  U[0]->Grad_z(U[nfields+1]);
  U[2]->Grad  (U[nfields+2], 0, 0, 'x');
  daxpy(nq, -1.0, U[nfields+2]->base_h, 1, U[nfields+1]->base_h, 1);  
  U[nfields+1]->Set_state('p');  
  
  // WZ = Uy - Vx
  U[1]->Grad(U[nfields+2], 0, 0, 'x');
  dcopy(nq, U[nfields+2]->base_h, 1, d, 1);
  U[0]->Grad(0, U[nfields+2], 0, 'y');
  daxpy(nq, -1.0, d, 1, U[nfields+2]->base_h, 1);
  U[nfields+2]->Set_state('p');
  free(d);
  return;
}

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  int   i;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }

  while (--argc && (*++argv)[0] == '-') {
    while (c = *++argv[0])                  /* more to parse... */
      switch (c) {
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }

  /* open input file */
  if ((*argv)[0] == '-') {
    f->in.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.fld", *argv);
      if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->in.name = strdup(fname);
  }

  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}




static void Fourier_interp(Element_List **U, Coord *X, double *ans, int nfields){
  int     nz = option("NZ"), i, j;
  double* ui = dvector(0, nfields*nz);
  Element_List **V = (Element_List**) malloc(U[0]->nz*nfields*sizeof(Element_List*));
  
  for(j=0;j<nfields;++j)
    for(i=0;i<U[0]->nz;++i)
      V[j+i*nfields] = U[j]->flevels[i];
  
  dzero(nfields, ans, 1);
  
  Interp_point(V, nfields*U[0]->nz, X, ui);
  
  for(j = 0;j < nfields; ++j){
    ans[j] = cos(Beta(nz)*X->z[0])*ui[j+nfields];
    for(i = 0; i < nz; i+=2)
      ans[j] += cos(Beta(i)*X->z[0])*ui[j+i*nfields];
    if(nz > 2)
      for(i = 3; i < nz; i+=2)
	ans[j] -= sin(Beta(i)*X->z[0])*ui[j+i*nfields];
  }
  free(ui);
  free(V);
}






