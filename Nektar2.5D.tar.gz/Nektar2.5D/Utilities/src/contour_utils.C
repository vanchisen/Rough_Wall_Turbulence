//
//  Generic utility for iso-contour extractions...
//
//

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include <nektarF.h>
#include <contour_utils.h>
#include <rfftw.h>
#ifdef MAP
#include <map.h>
#endif

//#ifdef MAP
//extern  FILE *MapFile;
//extern Map *mapx, *mapy;
//#endif

// local functions //

#ifdef MAP
void loop_up_low(Element_List *A,  int Kpl,  int iel, Map *mapx, Map *mapy);
void set_flag( int ,int ,int , int, int ,Element_List *,int, Map *mapx, Map *mapy);
void iso_triangle( int **flag,  int Kpl,  int iel, Element_List *A, Map *mapx, Map *mapy);
void iso_quad( int **flag,  int Kpl,  int iel, Element_List *A,  Map *mapx, Map *mapy);
void interpolate(Element_List *A,int **flag,int i,int j,double *xl,double *yl,double *zl, int Kpl,  int iel,
     double **X, Map *mapx, Map *mapy);
#else
void loop_up_low(Element_List *A,  int Kpl,  int iel);
void set_flag( int ,int ,int , int, int ,Element_List *,int);
void iso_triangle( int **flag,  int Kpl,  int iel, Element_List *A);
void iso_quad( int **flag,  int Kpl,  int iel, Element_List *A);
void interpolate(Element_List *A,int **flag,int i,int j,double *xl,double *yl,double *zl, int Kpl,  int iel,  double **X);
#endif


void dump_iso(FILE *out);
/* iso-contour triangle info */

typedef struct isoinfo {
  int    el; /* element to which this triangle is attached */
  double *x;   /* x-coordinate   */
  double *y;   /* y-coordiante */
  double *z;   /* z-coordiante */
  struct isoinfo *next;
} ISOinfo;

/*-------------------------------------------------------------------*
 *  link list for iso-contours.  Each node corresponds to one    *
 *  triangle specified by the local x,  y,  z coordinates .       *
 *-------------------------------------------------------------------*/
  
static ISOinfo *isoinf,*isobase;
static ISOinfo *addiso(double *xi, double *yi, double *zi, int iel);

void  getiso(double *x, double *y, double *z, int iel){
    
  /* create link list */
  
  isoinf         = isobase;
  isobase        = addiso(x, y, z, iel);
  isobase->next  = isoinf;
  
}


static ISOinfo *addiso(double *xi, double *yi, double *zi, int iel){  
   register int i;

  ISOinfo *iso = (ISOinfo *)malloc(sizeof(ISOinfo));

  iso->el   = iel;
  
  
  iso->x = dvector(0,2);
  iso->y = dvector(0,2);
  iso->z = dvector(0,2);
  
  // copy values
  for (i=0;i<3;++i) iso->x[i] = xi[i];
  for (i=0;i<3;++i) iso->y[i] = yi[i];
  for (i=0;i<3;++i) iso->z[i] = zi[i];
  

  return iso;
}


#ifdef MAP
void iso_contour(Element_List **U, Map *mapx, Map *mapy,  int nfields, FILE *out)
#else
void iso_contour(Element_List **U,  int nfields,  FILE *out)
#endif
{
    int     CF = option("Cont_Field") ;
    
    register int iel, Kpl; 
    Element_List *A = U[CF];
    int qa ;
    
 for(iel = 0; iel < A->nel; ++iel)
   for(Kpl=0; Kpl < A->nz; ++Kpl){
#ifdef MAP
     loop_up_low(A , Kpl, iel, mapx, mapy);
#else
     loop_up_low(A , Kpl, iel);
#endif	   	   
   }
    
 dump_iso(out);  
    
}

void dump_iso(FILE *out){
    
  char Var[9][4]={"u", "v", "w", "p", "Wx", "Wy", "Wz", "Div", "La"};
  int     CF = option("Cont_Field") ;
  double  CL = dparam("Cont_Level") ;
  int zone =0, npts, i;
  fprintf(out,"VARIABLES = x y z\n");
  
  // loop over ISOinfo link list  
  for(isoinf = isobase; isoinf; isoinf = isoinf->next) ++zone;
  printf("There are %d iso zones \n",  zone);
  
  npts = 3*zone;
  fprintf(out,"ZONE T=\"iso-cont %s = %lf\" N=%d, E=%d, F=FEPOINT, ET=TRIANGLE\n",Var[CF],CL,  npts, zone);
  for(isoinf = isobase; isoinf; isoinf = isoinf->next){
    for (i=0; i<3; ++i)
      fprintf(out,"%.5f %.5f %.5f \n", isoinf->x[i],isoinf->y[i], isoinf->z[i]); 
  }
  
  for (i=0; i< npts; ++i){
    fprintf(out,"%d %d %d \n",i+1, i+2, i+3);
    i+=2;
  }
}

#ifdef MAP
void loop_up_low(Element_List *A,  int Kpl,  int iel, Map *mapx, Map *mapy)
#else
 void loop_up_low(Element_List *A,  int Kpl,  int iel)
#endif
{
  register int i, j, k;
  int qa, a, b, c  ;
  Element *F;
  
  F = A->flevels[Kpl]->flist[iel];      
  qa = F->qa;
	   
  
  // loop over "up" elements
  
  int cnt=0;
  for (i=0; i< qa-1;++i){
    for (j=0; j<qa -1-i; ++j){
      
      a  =    j+cnt      ;
      b  =   j+1+cnt     ;
      c  =  j+(qa-i)+cnt ;
#ifdef MAP
      set_flag(a, b, c, Kpl, iel, A, 1, mapx, mapy);
      set_flag(a, b, c, Kpl, iel, A, 2, mapx, mapy ); 
      set_flag(a, b, c, Kpl, iel, A, 3, mapx, mapy); 
#else 	      
      set_flag(a, b, c, Kpl, iel, A, 1);
      set_flag(a, b, c, Kpl, iel, A, 2); //2
      set_flag(a, b, c, Kpl, iel, A, 3); //3
#endif   
    }  
    cnt += qa-i;   
  } 	   
  
  // loop over "down" elements
  
  cnt=0;
  for (i=0; i< qa-2;++i){
    for (j=0; j<qa -2-i; ++j){
      
      a  =    j+1+cnt        ;
      b  =    j+(qa-i+1+cnt)   ;
      c  =    j+(qa-i)+cnt  ;
#ifdef MAP
      set_flag(a, b, c, Kpl, iel, A, 1, mapx, mapy);
      set_flag(a, b, c, Kpl, iel, A, 2, mapx, mapy);
      set_flag(a, b, c, Kpl, iel, A, 3, mapx, mapy);
#else	       	      
      set_flag(a, b, c, Kpl, iel, A, 1);
      set_flag(a, b, c, Kpl, iel, A, 2);
      set_flag(a, b, c, Kpl, iel, A, 3);
#endif   
    }  
    cnt += qa-i;   
  } 	   
  
}	   


#ifdef MAP
void set_flag( int a ,int b ,int c, int Kpl, int iel ,Element_List *A , int trip,  Map *mapx,  Map *mapy)
#else
void set_flag( int a ,int b ,int c, int Kpl, int iel ,Element_List *A , int trip)
#endif
{
  register int i, j;
  int sum, Kpl_next;
  Element *G;
  int **flag = imatrix(0, 3, 0, 2);
  izero(4*3, flag[0], 1);
  
  double  CL = dparam("Cont_Level") ;
  
  
  Element *F = A->flevels[Kpl]->flist[iel];
  if ( Kpl == A->nz-1 ) {
    G = A->flevels[0]->flist[iel];
  }
  else {
    G = A->flevels[Kpl+1]->flist[iel];
  }
  Kpl_next = Kpl+1;
  
  switch(trip){
  case 1: 
    
    if ( F->h[0][a] > CL ) flag[0][2] = 1;
    else if ( F->h[0][a] < CL ) flag[0][2] = 0;
    else if ( F->h[0][a] == CL  ){
      printf("Warning: skipping Tet 1 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel, Kpl);
      break;
    }
    
    
    if ( F->h[0][c] > CL ) flag[1][2] = 1;
    else if ( F->h[0][c] < CL ) flag[1][2] = 0;
    else if ( F->h[0][c] == CL  ){
      printf("Warning: skipping Tet 1 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel, Kpl);
      break;
    }
    
    if ( F->h[0][b] > CL ) flag[2][2] = 1;
    else if ( F->h[0][b] < CL ) flag[2][2] = 0;
    else if ( F->h[0][b] == CL  ){
      printf("Warning: skipping Tet 1 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel, Kpl);
      break;
    }
    
    if ( G->h[0][c] > CL ) flag[3][2] = 1;
    else if ( G->h[0][c] < CL ) flag[3][2] = 0;
    else if ( G->h[0][c] == CL  ){
      printf("Warning: skipping Tet 1 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel, Kpl);
      break;
    }
    
    
    flag[0][0]=a;flag[1][0]=c;flag[2][0]=b;flag[3][0]=c;
    flag[0][1] = flag[1][1] = flag[2][1] = Kpl ;flag[3][1]=Kpl_next;
    break;
    
    
  case 2: 
    
    if ( G->h[0][a] > CL ) flag[0][2] = 1;
    else if ( G->h[0][a] < CL ) flag[0][2] = 0;
    else if ( G->h[0][a] == CL  ){
      printf("Warning: skipping Tet 2 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel, Kpl_next);
      break;
    }
    
    
    if ( G->h[0][b] > CL ) flag[1][2] = 1;
    else if ( G->h[0][b] < CL ) flag[1][2] = 0;
    else if ( G->h[0][b] == CL  ){
      printf("Warning: skipping Tet 2 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel, Kpl_next);
      break;
    }
    
    if ( G->h[0][c] > CL ) flag[2][2] = 1;
    else if ( G->h[0][c] < CL ) flag[2][2] = 0;
    else if ( G->h[0][c] == CL  ){
      printf("Warning: skipping Tet 2 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel, Kpl_next);
      break;
    }
    
    if ( F->h[0][a] > CL ) flag[3][2] = 1;
    else if ( F->h[0][a] < CL ) flag[3][2] = 0;
    else if ( F->h[0][a] == CL  ){
      printf("Warning: skipping Tet 2 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel, Kpl);
      break;
    }
    
    
    flag[0][0]=a;flag[1][0]=b;flag[2][0]=c;flag[3][0]=a;
    flag[0][1] = flag[1][1] = flag[2][1] = Kpl_next  ;flag[3][1]=Kpl;
    break;
    
    
  case 3: 
    
    if ( F->h[0][a] > CL ) flag[0][2] = 1;
    else if ( F->h[0][a] < CL ) flag[0][2] = 0;
    else if ( F->h[0][a] == CL  ){
      printf("Warning: skipping Tet 3 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel, Kpl_next);
      break;
    }
    
    
    if ( F->h[0][b] > CL ) flag[1][2] = 1;
    else if ( F->h[0][b] < CL ) flag[1][2] = 0;
    else if ( F->h[0][b] == CL  ){
      printf("Warning: skipping Tet 3 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel,Kpl_next );
      break;
    }
    
    if ( G->h[0][b] > CL ) flag[2][2] = 1;
    else if ( G->h[0][b] < CL ) flag[2][2] = 0;
    else if ( G->h[0][b] == CL  ){
      printf("Warning: skipping Tet 3 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel, Kpl_next);
      break;
    }
    
    if ( G->h[0][c] > CL ) flag[3][2] = 1;
    else if ( G->h[0][c] < CL ) flag[3][2] = 0;
    else if ( G->h[0][c] == CL  ){
      printf("Warning: skipping Tet 3 of sub-element(%d, %d, %d) of element %d and plane %d \n", a, b, c, iel, Kpl);
      break;
    }
    
    
    flag[0][0]=a;flag[1][0]=b;flag[2][0]=b;flag[3][0]=c;
    flag[0][1] = flag[1][1] = Kpl; flag[2][1] = flag[3][1]=Kpl_next;
    break;
  }
	
	
  //	check summ of the flag vector:  
  for (sum =0, i=0; i<4; ++i) sum += flag[i][2];   
  
  
  if ( sum == 0 || sum == 4) {
    free_imatrix(flag,0,0);     
    return;
  }
  
  else if ( sum == 1 || sum ==3)
#ifdef MAP	   
    iso_triangle(flag, Kpl, iel, A,  mapx,  mapy);
#else
  iso_triangle(flag, Kpl, iel, A);
#endif	 
  
  else if ( sum == 2)
#ifdef MAP	   
    iso_quad(flag, Kpl, iel, A,  mapx,  mapy);
#else
  iso_quad(flag, Kpl, iel, A);
#endif	  
  
  free_imatrix(flag,0,0);
  
} 



#ifdef MAP
void iso_triangle( int **flag,  int Kpl,  int iel, Element_List *A ,  Map *mapx,  Map *mapy)
#else	  
void iso_triangle( int **flag,  int Kpl,  int iel, Element_List *A )
#endif
{
  register int i, j;
  int l=0;
  
  //Get the coordinate symmpts
  Element *F = A->flevels[Kpl]->flist[iel];
  Coord  XP;
  double **X;   
  double *x= dvector(0, 2);dzero(3, x, 1);
  double *y= dvector(0, 2);dzero(3, y, 1);
  double *z= dvector(0, 2);dzero(3, z, 1);
  
  X = dmatrix(0,2,0,QGmax*QGmax-1);
  XP.x = X[0]; XP.y = X[1];
  F->coord(&XP);
  Interp_symmpts(F,F->qa,XP.x,XP.x,'p'); 
  Interp_symmpts(F,F->qa,XP.y,XP.y,'p'); 

  for(i=0;i<3;++i)
    for(j=i+1;j<4 ;++j)
      if ( flag[i][2] != flag[j][2] ) {
#ifdef MAP
	interpolate( A,flag, i, j, x+l, y+l, z+l,  Kpl,  iel, X, mapx,  mapy);
#else		
	interpolate( A,flag, i, j, x+l, y+l, z+l,  Kpl,  iel, X);
#endif		 
	++l;
      }   
  
  // create link list here later 
  getiso(x, y, z, iel);       
  free_dmatrix(X,0,0);free(x);free(y);free(z);
  
}

#ifdef MAP
void iso_quad( int **flag,  int Kpl,  int iel, Element_List *A,  Map *mapx,  Map *mapy)
#else
  void iso_quad( int **flag,  int Kpl,  int iel, Element_List *A)
#endif
{
  
  register int i, j;
  
  //Get the coordinate symmpts
  Element *F = A->flevels[Kpl]->flist[iel];
  Coord  XP;
  double **X;   
  int l=0, x,  start;
  int S[]={0, 0, 0};
  int T[]={0, 0, 0};
  int **sort = imatrix(0, 3, 0, 1); izero(4*2, sort[0], 1);         

  X = dmatrix(0,1,0,QGmax*QGmax-1);
  XP.x = X[0]; XP.y = X[1];
  F->coord(&XP);
  Interp_symmpts(F,F->qa,XP.x,XP.x,'p'); 
  Interp_symmpts(F,F->qa,XP.y,XP.y,'p'); 

  
  // first create sort list
  
  for(i=0;i<3;++i)
    for(j=i+1;j<4 ;++j)
      if ( flag[i][2] != flag[j][2] ) {
	sort[l][0]=i;
	sort[l][1]=j; 
	++l;
      }   
  
  // find first triangle --> A 
  
  i=1;S[0]=0;
  x=sort[0][1];
  l=0;
  while( i < 4 ){
    
    if ( x == sort[i][0] ) {
      ++l;
      S[l]=i;
      x = sort[i][1];
    }	
    else if ( x == sort[i][1] ){
      ++l;
      S[l]=i;
      x = sort[i][0];
    }
    
    ++i;
    
  }
  
  // find second triangle --> B
  
  for(i=0;i<4;++i)
    if ( i != S[0] && i != S[1] && i != S[2]) start = i ;
  
  T[0]=start;
  x= sort[start][0];
  l =0;
  i = 0;
  while( i < 4 ){
    
    if ( x == sort[i][0] ) {
      ++l;
      T[l]=i;
      x = sort[start][1];
    }	
    else if ( x == sort[i][1] ){
      ++l;
      T[l]=i;
      x = sort[start][1];
    }
    
    ++i;
    if ( i == start) i = start+1;
  }
  
  
  // interpolate 1st triangle
  double *x_1= dvector(0, 2);dzero(3, x_1, 1);
  double *y_1= dvector(0, 2);dzero(3, y_1, 1);
  double *z_1= dvector(0, 2);dzero(3, z_1, 1);
  
  for(i=0;i<3;++i)
#ifdef MAP		 
    interpolate( A,flag, sort[S[i]][0], sort[S[i]][1], x_1+i, y_1+i, z_1+i,  Kpl,  iel, X,  mapx,  mapy);
#else
  interpolate( A,flag, sort[S[i]][0], sort[S[i]][1], x_1+i, y_1+i, z_1+i,  Kpl,  iel, X);
#endif		   
  
  // interpolate 2nd triangle
  double *x_2= dvector(0, 2);dzero(3, x_2, 1);
  double *y_2= dvector(0, 2);dzero(3, y_2, 1);
  double *z_2= dvector(0, 2);dzero(3, z_2, 1);
  
  for(i=0;i<3;++i)
#ifdef MAP
    interpolate( A,flag, sort[T[i]][0], sort[T[i]][1], x_2+i, y_2+i, z_2+i,  Kpl,  iel, X,  mapx,  mapy);
#else		 
  interpolate( A,flag, sort[T[i]][0], sort[T[i]][1], x_2+i, y_2+i, z_2+i,  Kpl,  iel, X); 
#endif		           
  
  // create link list
    
  getiso(x_1, y_1, z_1, iel); // 1st triangle
  getiso(x_2, y_2, z_2, iel); // 2nd triangle
  
  free_dmatrix(X,0,0);free(x_1);free(y_1);free(z_1);
  free(x_2);free(y_2);free(z_2);
  free_imatrix(sort,0,0);
  
}  

	  








	  
	  
#ifdef MAP
void interpolate(Element_List *A,int **flag,int i,int j,double *xl,double *yl,double *zl, int Kpl,  int iel,double **X,  
      Map *mapx, Map *mapy)     
#else	  
void interpolate(Element_List *A,int **flag,int i,int j,double *xl,double *yl,double *zl, int Kpl,  int iel,double **X)
#endif
{
                double xi,  yi,  zi   ;
		double xj,  yj,  zj   ;
		double xo,  yo,  zo   ;
		double fac, sig_i, sig_j;
		double  CL = dparam("Cont_Level") ;
		int Ki, Kj; 
		
	       // need to check for last plane
	          Ki = flag[i][1];
		  Kj = flag[j][1];
	       if ( Ki == A->nz ) Ki = 0;
	       if ( Kj == A->nz ) Kj = 0;
	       	
#ifdef MAP
 	       xi = X[0][flag[i][0]] + mapx->d[Ki];
	       yi = X[1][flag[i][0]] + mapy->d[Ki];
#else
               xi = X[0][flag[i][0]];
	       yi = X[1][flag[i][0]];
#endif	       
               zi = zmesh(flag[i][1]);
	
#ifdef MAP
	       xj = X[0][flag[j][0]] + mapx->d[Kj];
	       yj = X[1][flag[j][0]] + mapy->d[Kj];
#else		       
	       xj = X[0][flag[j][0]];
	       yj = X[1][flag[j][0]];
#endif	  
               zj = zmesh(flag[j][1]);
	       
	
		   sig_i = A->flevels[Ki]->flist[iel]->h[0][flag[i][0]];
	           sig_j = A->flevels[Kj]->flist[iel]->h[0][flag[j][0]];
	       
	     
	       
	       fac = (sig_j -CL)/(sig_j-sig_i);
	       
	      
	       xo = xj + fac * ( xi - xj);
	       yo = yj + fac * ( yi - yj);
	       zo = zj + fac * ( zi - zj);
	       
	       *xl = xo;
	       *yl = yo;
	       *zl = zo;

} 	  
      
      
          
     
     
    
     
     
     

