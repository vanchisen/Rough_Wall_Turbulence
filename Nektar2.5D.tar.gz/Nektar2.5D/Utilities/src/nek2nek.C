/*---------------------------------------------------------------------------*
 *                        RCS Information                                    *
 *                                                                           *
 * $Source: /homedir/cvs/Nektar/Utilities_F/src/nek2nek.C,v $
 * $Revision: 1.1 $
 * $Date: 2004/09/26 11:11:37 $ 
 * $Author: ssherw $ 
 * $State: Exp $ 
 *---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <math.h>
#include <veclib.h>
#include "polylib.h"
#include <nektarF.h>
#include <gen_utils.h>

/* Each of the following strings MUST be defined */
static char  usage_[128];

char *prog   = "extract";
char *usage  = "extract:  [options] -m new_rea[.rea]  -r file[.rea] input[.fld]\n";
char *author = "";
char *rcsid  = "";
char *help   = " This routine will interpolate from one mesh to another from the field file input[.fld]. It also requires the file file[.rea]\n";
/* ---------------------------------------------------------------------- */

typedef struct intepts{
  int  npts;
  Coord X;
} Intepts;

static void setup           (FileList *f, Element_List **U, Field *fld);
static void parse_util_args (int argc, char *argv[], FileList *f);
static void Interp_point(Element_List **U, int nfields, Coord *X, double *ui);
static void Interp_pts(FILE *fp, Element_List **U, int nfields);
static void Write(FileList *f, Field *fld, int nfields, Element_List **V);
int readHeaderF(FILE* fp, Field *f);

main (int argc, char *argv[])
{
  register  int i,k;
  int       dump=0,nfields;
  Field     fld;
  FileList  f;
  Element_List   **master;

  parse_util_args(argc = generic_args (argc, argv, &f), argv, &f);

  memset(&fld, '\0', sizeof (Field));
  dump = readHeaderF (f.in.fp, &fld);
  if (!dump         ) error_msg(Restart: no dumps read from restart file);
  if (fld.dim != DIM) error_msg(Restart: file if wrong dimension);

  master = (Element_List **) malloc((nfields = strlen(fld.type))*2*sizeof(Element_List *));
  setup (&f, master, &fld);

  Interp_pts(f.out.fp,master,nfields);

  Write (&f, &fld, nfields, master+nfields);

  return 0;
}


static void Write(FileList *f, Field *fld, int nfields, Element_List **V)
{
  for(int i=0;i<nfields;++i)
    V[i]->Trans(V[i],Q_to_J);
  WritefieldF (f->out.fp, f->out.name, fld->step, fld->time, nfields, V);
}


static void Interp_pts(FILE *fp, Element_List **U, int nfields){
  Coord X,Y;
  int i,j,k,id, qmax, ntot, fl;
  double *tmp;
  Element *E,*F;

  qmax = QGmax*QGmax;
  
  tmp = dvector(0,nfields*U[0]->nz-1);
  X.x = dvector(0,qmax-1);  X.y = dvector(0,qmax-1);
  Y.x = dvector(0,1);  Y.y = Y.x+1;  Y.x[0] = Y.y[0] = 0.0;
  
  for(E=U[nfields]->fhead;E;E=E->next)
    {
      ntot = E->qa*E->qb;
      fl = 0;
      E->coord(&X);	    
      for(i=0;i<ntot;++i){
	Y.x[0] = X.x[i];      Y.y[0] = X.y[i];
	Interp_point(U,nfields,&Y,tmp);
	for(k=0;k<U[0]->nz;++k)
	  for(j=0;j<nfields;++j)
	    *(U[j+nfields]->flevels[k]->flist[E->id]->h[0]+i) 
	      = tmp[j+nfields*k];
      }
      fprintf(stderr,"Interpolated Element: %d\n", E->id);
    }
  
  free(tmp);  free(X.x);  free(X.y);  free(Y.x);  
}


static void setup (FileList *f, Element_List **U, Field *fld)
{
  int i,k;
  int nfields = strlen(fld->type);
  Element_List *V;
  
  ReadParams  (f->rea.fp);
  
  option_set("NZ", fld->nz);
  option_set("NZTOT", fld->nz);
  
  if((i=iparam("NORDER-req"))!=UNSET){
    iparam_set("LQUAD",i);
    iparam_set("MQUAD",i);
  }
  else if(option("Qpts")){
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax);
  }    
  else{
    iparam_set("LQUAD",fld->lmax+1);
    iparam_set("MQUAD",fld->lmax+1);
  }    
  
  iparam_set("MODES",fld->lmax);

  U[0] = ReadMesh(f->rea.fp,strtok(f->rea.name,"."));     
  
  init_ortho_basis();
 
  if(f->mesh.name) Get_Body(f->mesh.fp);
  
  for(i = 1; i < nfields; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i];
  }
  
  if(1||option("oldhybrid")) // at present need this to read in old files
    set_nfacet_list(U[0]);

  readFieldF(f->in.fp, fld, U[0]);
//  U[0]->fhead->type = fld->type[0];
  
  copyfieldF(fld,0,U[0]);
  
  for(i = 1; i < nfields; ++i){
    U[i] = U[0]->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i];
    copyfieldF(fld,i,U[i]);
  }
  
  /* New section */
  /* Generate the list of elements */
  V     = ReadMesh(f->mesh.fp, strtok(f->mesh.name,"."));
  V->fhead->type = fld->type[0];

  for(i = nfields; i < 2*nfields; ++i){
    U[i] = V->gen_aux_field('u');
    U[i]->fhead->type = fld->type[i-nfields];
  }

  return;
}

/* --------------------------------------------------------------------- *
 * parse_args() -- Parse application arguments                           *
 *                                                                       *
 * This program only supports the generic utility arguments.             *
 * --------------------------------------------------------------------- */

static void parse_util_args (int argc, char *argv[], FileList *f)
{
  char  c;
  int   i;
  char  fname[FILENAME_MAX];

  if (argc == 0) {
    fputs (usage, stderr);
    exit  (1);
  }

  while (--argc && (*++argv)[0] == '-') {
    while (c = *++argv[0])                  /* more to parse... */
      switch (c) {
      default:
	fprintf(stderr, "%s: unknown option -- %c\n", prog, c);
	break;
      }
  }

  /* open input file */
  if ((*argv)[0] == '-') {
    f->in.fp = stdin;
  } else {
    strcpy (fname, *argv);
    if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
      sprintf(fname, "%s.fld", *argv);
      if ((f->in.fp = fopen(fname, "r")) == (FILE*) NULL) {
	fprintf(stderr, "%s: unable to open the input file -- %s or %s\n",
		prog, *argv, fname);
	exit(1);
      }
    }
    f->in.name = strdup(fname);
  }

  if (option("verbose")) {
    fprintf (stderr, "%s: in = %s, rea = %s, out = %s\n", prog,
	     f->in.name   ? f->in.name   : "<stdin>",  f->rea.name,
	     f->out.name  ? f->out.name  : "<stdout>");
  }

  return;
}


/* local functions */
static void set_normals (Element_List *E);
static void X2A         (Element *E, Coord *X, Coord *A);
static int  find_eid    (Element_List *E, Coord *X);

/* Interpolate the nfields fields stored in U to points described by X
   and return values in ui. */

void Interp_point(Element_List **U, int nfields, Coord *X, double *ui){
  register int i,j,n;
  int      eid, qa, qb;
  Coord    A;
  double   *ha,*hb,*z,*w, *tmp;
  Element  *E;

  A.x = dvector(0,DIM-1);
  A.y = A.x+1;

  /* find element that contains points */
  eid = find_eid(U[0],X);
  if(eid == -1){
    dzero(U[0]->nz*nfields, ui, 1);	  
    for(i=0;i<nfields;++i)
      ui[i] = (U[i]->fhead->type == 'u') ? 1.0 : 0.0;
    return;
  }
  
  /* convert X co-ordinates to local a,b,c points */
  X2A(U[0]->flist[eid],X,&A);

  qa = U[0]->flist[eid]->qa;
  qb = U[0]->flist[eid]->qb;
  
  ha = dvector(0,qa-1);
  getzw(qa,&z,&w,'a');
  for(i = 0; i < qa; ++i)
    ha[i] = hgll(i,A.x[0],z,qa);
  
  hb = dvector(0,qb-1);
  getzw(qb,&z,&w,'b');
  for(i = 0; i < qb; ++i)
    hb[i] = hgrj(i,A.x[1],z,qb,1.0,0.0);

  tmp = dvector(0,qb-1);

  /* Interpolate to point using lagrange interpolation in the physical space */
  for(j = 0; j < U[0]->nz; ++j)
    for(n = 0; n < nfields; ++n){
      E = U[n]->flevels[j]->flist[eid];
      if(E->state == 't')
	E->Trans(E, J_to_Q);
      
      /* interpolation in the `a' direction */
      for(i = 0; i < qb; ++i)
	tmp[i] = ddot(qa,ha,1,E->h[i],1);
      
      /* interpolation in the `b' direction */
      ui[n+j*nfields] = ddot(qb,hb,1,tmp,1);
    }
  
  free(ha); free(hb); free(tmp);
}

typedef struct nmls{
  double n[DIM+1][DIM];
} Nmls;

static Nmls *Nmals;

/* function to set up inward normals (not normalised) for straight
   sided elements. Needs to be set up for most of these functions  */

static void set_normals(Element_List *E){  
  if(!Nmals){
    register int k;
    const    int nel = E->nel;
    Element *F;

    Nmals = (Nmls *)malloc(nel*sizeof(Nmls));
    
    for(k = 0; k < nel; ++k){
      F = E->flist[k];
      /* edge 1 */
      Nmals[k].n[0][0] = -(F->vert[1].y - F->vert[0].y);
      Nmals[k].n[0][1] =   F->vert[1].x - F->vert[0].x;
      
      /* edge 2 */
      Nmals[k].n[1][0] = -(F->vert[2].y - F->vert[1].y);
      Nmals[k].n[1][1] =   F->vert[2].x - F->vert[1].x;
      
      /* edge 3 */
      Nmals[k].n[2][0] = -(F->vert[0].y - F->vert[2].y);
      Nmals[k].n[2][1] =   F->vert[0].x - F->vert[2].x;
    }
  }
}

void free_normals(void){
  free(Nmals);
}

/* Given a points (x,y) stored in X->x[0] Y->y[0] find the points
   (a.b) and return in A->x[0] A->y[0]. The derivation of this algorithm
   involves describing the point in vector as:

   X - X1 = 2(1+r)/2 (X2 - X1) + 2(1+s)/2 (X3 - X1) 

   where X1,X2 and X3 are the (x,y) points of the vertices. Then r and
   s are evaluated by taking the inner product of this equation with the
   normals to (X2-x1) and (X3-X1). A similar approach can be used in 3D
   except you need to use the normals of the faces.

   Note: this function assumes that the element is straight sides
   (Curved sided has no explicit formulae) and that the normals have
   been set up already by either calling `set_normals' or `get_eid'. */

static void X2A(Element *E, Coord *X, Coord *A){
  const  int k = E->id;
  double r,s;
  double x = X->x[0], y = X->y[0];
  double x1 = E->vert[0].x, y1 = E->vert[0].y;
  double x2 = E->vert[1].x, y2 = E->vert[1].y;
  double x3 = E->vert[2].x, y3 = E->vert[2].y;

  /* first calculate r and s */

  r  = 2*((x  - x1)*Nmals[k].n[2][0] + (y  - y1)*Nmals[k].n[2][1]);
  r /=    (x2 - x1)*Nmals[k].n[2][0] + (y2 - y1)*Nmals[k].n[2][1];
  r -= 1.0;

  s  = 2*((x  - x1)*Nmals[k].n[0][0] + (y  - y1)*Nmals[k].n[0][1]);
  s /=    (x3 - x1)*Nmals[k].n[0][0] + (y3 - y1)*Nmals[k].n[0][1];
  s -= 1.0;

  A->x[0] = (1.0-s)? 2*(1.0+r)/(1.0-s) - 1.0: 1.0;
  A->y[0] = s;
}


/* Find and return the element id of which contains the points (x,y,z) 
   stored in (X->x[0],X->y[0],Z->z[0]). This is achieved by checking the
   sign of the inner product between the inner normal and a vector from 
   the point to a positionn on the edge. */

static int EID;

static int find_eid(Element_List *E, Coord *X){
  register int k,j,cnt;

  set_normals(E);
  
  for(k = EID; k < E->nel; ++k){
    for(cnt = 0, j = 0; j < DIM+1; ++j)
      if(((X->x[0] - E->flist[k]->vert[j].x)*Nmals[k].n[j][0] +
	  (X->y[0] - E->flist[k]->vert[j].y)*Nmals[k].n[j][1]) >= 0) ++cnt;
    if(cnt == DIM+1){EID = k;  return k;}
  }
  
  for(k = 0; k < EID; ++k){
    for(cnt = 0, j = 0; j < DIM+1; ++j)
      if(((X->x[0] - E->flist[k]->vert[j].x)*Nmals[k].n[j][0] +
	  (X->y[0] - E->flist[k]->vert[j].y)*Nmals[k].n[j][1]) >= 0) ++cnt;
    if(cnt == DIM+1){EID = k;  return k;}
  }
  
  return -1;
}
