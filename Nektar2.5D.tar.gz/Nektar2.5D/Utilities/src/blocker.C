#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <veclib.h>

/*-------------------------------------------------------------------------*
 * This is a routine to add +xvalue to the x coordinate and +yvalue        *
 * to the y coordinate of an rea file.                                     *
 * Usage:    mvgrid +xvalue +yvalue file[.rea]                             *
 *-------------------------------------------------------------------------*/

/* Each of the following strings MUST be defined */
static char  usage_[128];

char *prog   = "blocker";
char *usage  = "blocker:  file\n";
char *author = "";
char *rcsid  = "";
char *help   = "";



main(int argc, char *argv[])
{
  double x[4],y[4];
  int i,j,nx,ny;
  char file[BUFSIZ],buf[BUFSIZ],info_file[BUFSIZ];
  FILE *fp,*fp_new;
  
  sprintf(info_file,"%s",argv[argc-1]);
  
  if(!(fp = fopen(info_file,"r"))){
    fprintf(stdout,"File %s does not exist\n",file);
    exit(-1);
  }
  int cnt = 1;

  while(fgets(buf,BUFSIZ,fp)){
    if(strstr(buf, "Block")){
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d %d",&nx,&ny);
      for(i=0;i<4;++i){
	fscanf(fp,"%lf %lf",x+i,y+i);
	fgets(buf,BUFSIZ,fp);
      }
      double **tmp_x = dmatrix(0,nx,0,ny);
      double **tmp_y = dmatrix(0,nx,0,ny);

      
      for(i = 0; i < ny+1; ++i)
	for(j = 0; j < nx+1; ++j){
	  tmp_x[j][i] =  (x[0]*(nx-j)*(ny-i) + x[1]*j*(ny-i)
			  + x[2]*j*i + x[3]*(nx-j)*i)/(nx*ny);
	  tmp_y[j][i] =  (y[0]*(nx-j)*(ny-i) + y[1]*j*(ny-i)
			  + y[2]*j*i + y[3]*(nx-j)*i)/(nx*ny);
	}
      for(i = 0; i < ny; ++i)
	for(j = 0; j < nx; ++j){
	  fprintf(stdout, "Element %d Quad\n",cnt);
	  fprintf(stdout, "%lf %lf %lf %lf\n",
		  tmp_x[j][i], tmp_x[j+1][i],tmp_x[j+1][i+1],tmp_x[j][i+1]);
	  fprintf(stdout, "%lf %lf %lf %lf\n",
		  tmp_y[j][i], tmp_y[j+1][i],tmp_y[j+1][i+1],tmp_y[j][i+1]);
	  ++cnt;
	}
      free(*tmp_x);      free(*tmp_y);
    }
    if(strstr(buf, "Inter")){
      fgets(buf,BUFSIZ,fp);
      sscanf(buf,"%d",&nx);

      for(i=0;i<4;++i){
	fscanf(fp,"%lf %lf",x+i,y+i);
	fgets(buf,BUFSIZ,fp);
      }
      double **tmp_x = dmatrix(0,nx,0,1);
      double **tmp_y = dmatrix(0,nx,0,1);
      
      for(j = 0; j < nx+1; ++j){
	tmp_x[j][0] =  (x[0]*(nx-j) + x[1]*j)/nx;
	tmp_y[j][0] =  (y[0]*(nx-j) + y[1]*j)/nx;
      }

      // assumes equal number of spaces
      for(j = 0; j < nx+1; j+=2){
	tmp_x[j/2][1] =  (x[3]*(nx-j) + x[2]*j)/nx;
	tmp_y[j/2][1] =  (y[3]*(nx-j) + y[2]*j)/nx;
      }
      
      for(j = 0; j < nx/2; ++j){
	fprintf(stdout, "Element %d Tri\n",cnt);
	fprintf(stdout, "%lf %lf %lf %lf\n",
		tmp_x[2*j][0], tmp_x[2*j+1][0],tmp_x[j][1],-100.0);
	fprintf(stdout, "%lf %lf %lf %lf\n",
		tmp_y[2*j][0], tmp_y[2*j+1][0],tmp_y[j][1],-100.0);
	++cnt;
	fprintf(stdout, "Element %d Tri\n",cnt);
	fprintf(stdout, "%lf %lf %lf %lf\n",
		tmp_x[2*j+1][0], tmp_x[2*j+2][0],tmp_x[j+1][1],-100.0);
	fprintf(stdout, "%lf %lf %lf %lf\n",
		tmp_y[2*j+1][0], tmp_y[2*j+2][0],tmp_y[j+1][1],-100.0);
	++cnt;
	fprintf(stdout, "Element %d Tri\n",cnt);
	fprintf(stdout, "%lf %lf %lf %lf\n",
		tmp_x[j][1], tmp_x[2*j+1][0],tmp_x[j+1][1],-100.0);
	fprintf(stdout, "%lf %lf %lf %lf\n",
		tmp_y[j][1], tmp_y[2*j+1][0],tmp_y[j+1][1],-100.0);
	++cnt;
      }
      free(*tmp_x);      free(*tmp_y);
    }
  }
  return 0;
}
    

