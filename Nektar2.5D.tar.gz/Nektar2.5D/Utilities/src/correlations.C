#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <unistd.h>
#include <math.h>
#include <veclib.h>
#include <rfftw.h>
#include "statistics.h"

main(int argc, char *argv[])
{
  register int i, j;
  double dvar[5];
  int ivar;

  if (argc != 5) {
    printf ("%s infile nzin nz nsamples\n");
    printf ("infile:   stripped single point 3d history point input file\n");
    printf ("nzin:     input number of physical planes\n");
    printf ("nz:       number of physical planes to use\n");
    printf ("nsamples: number of distinct time samples\n");
    printf ("Output is to file Rl\n");
    exit (-1);
  }

  FILE *fp = fopen (*(argv+1), "r");
  int nzin = atoi(*(argv+2));
  int nz = atoi(*(argv+3));
  int nsamples = atoi(*(argv+4));
  int NZ = nz/2+1;

  double **u = dmatrix(0, nsamples-1, 0, nz-1); dzero(nsamples*nz, u[0], 1);
  double **v = dmatrix(0, nsamples-1, 0, nz-1); dzero(nsamples*nz, v[0], 1);
  double **w = dmatrix(0, nsamples-1, 0, nz-1); dzero(nsamples*nz, w[0], 1);
  double **p = dmatrix(0, nsamples-1, 0, nz-1); dzero(nsamples*nz, p[0], 1);
  
  double *ua = dvector(0, nz-1); dzero (nz, ua, 1);
  double *va = dvector(0, nz-1); dzero (nz, va, 1);
  double *wa = dvector(0, nz-1); dzero (nz, wa, 1);
  double *pa = dvector(0, nz-1); dzero (nz, pa, 1);

  double **au = dmatrix(0, nsamples-1, 0, NZ-1); dzero(nsamples*NZ, au[0], 1);
  double **av = dmatrix(0, nsamples-1, 0, NZ-1); dzero(nsamples*NZ, av[0], 1);
  double **aw = dmatrix(0, nsamples-1, 0, NZ-1); dzero(nsamples*NZ, aw[0], 1);

  double *aua = dvector(0, NZ-1); dzero (NZ, aua, 1);
  double *ava = dvector(0, NZ-1); dzero (NZ, ava, 1);
  double *awa = dvector(0, NZ-1); dzero (NZ, awa, 1);

  for (i = 0; i < nsamples; i++) {
    fscanf(fp, "%lf %lf %lf %lf %lf ", dvar, dvar+1, dvar+2, dvar+3, dvar+4);
    for (j = 0; j < nzin; j++)
      fscanf(fp, "%lf ", u[i]+j);
    for (j = 0; j < nzin; j++)
      fscanf(fp, "%lf ", v[i]+j);
    for (j = 0; j < nzin; j++)
      fscanf(fp, "%lf ", w[i]+j);
    for (j = 0; j < nzin; j++)
      fscanf(fp, "%lf ", p[i]+j);
    fscanf (fp, ":%d\n", &ivar);
  }

  FFTsamples(u, nz, nsamples);
  FFTsamples(v, nz, nsamples);
  FFTsamples(w, nz, nsamples);
  FFTsamples(p, nz, nsamples);

  TimeAverage(u, ua, nz, nsamples);
  TimeAverage(v, va, nz, nsamples);
  TimeAverage(w, wa, nz, nsamples);
  TimeAverage(p, pa, nz, nsamples);

  GetDevs(u, ua, nz, nsamples);
  GetDevs(v, va, nz, nsamples);
  GetDevs(w, wa, nz, nsamples);

  for (i = 0; i < nsamples; i++) {
    AutoCorrelateP(u[i], au[i], NZ, nz);
    AutoCorrelateP(v[i], av[i], NZ, nz);
    AutoCorrelateP(w[i], aw[i], NZ, nz);
  }

  for (i = 0; i < nsamples; i++) {
    AutoNormalize(au[i], NZ);
    AutoNormalize(av[i], NZ);
    AutoNormalize(aw[i], NZ);
  }

  TimeAverage(au, aua, NZ, nsamples);
  TimeAverage(av, ava, NZ, nsamples);
  TimeAverage(aw, awa, NZ, nsamples);

  FILE *Rl = fopen ("Rl", "w");

  double dz = 4.*M_PI/nz;

  fprintf (Rl, "# z Ruu Rvv Rww\n", dz*i, aua[i], ava[i], awa[i]);

  for (i = 0; i < NZ; i++)
    fprintf (Rl, "%lf %lf %lf %lf\n", dz*i, aua[i], ava[i], awa[i]);

  fclose(Rl);

  return 0;
}
