#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include <string.h>

/*-------------------------------------------------------------------------*
 * This is a routine to add +xvalue to the x coordinate and +yvalue        *
 * to the y coordinate of an rea file.                                     *
 * Usage:    mvgrid +xvalue +yvalue file[.rea]                             *
 *-------------------------------------------------------------------------*/

main(int argc, char *argv[])
{
  register i;
  double x[4],y[4],z[4],x1[4],y1[4],z1[4],xr,yr,zr;
  char file[BUFSIZ],buf[BUFSIZ];
  FILE *fp,*fp_new;
  
#if DIM == 3
  if(argc != 5){
    fprintf(stdout,"Usage:    rotgrid +xrot +yrot +zrot file[.rea] \n");
    exit(-1);
  }
#else
  if(argc != 2){
    fprintf(stdout,"Usage:    rotgrid +rot file[.rea] \n");
    exit(-1);
  }
#endif
  
  if(!strstr(argv[argc-1],".rea"))
    sprintf(file,"%s.rea",argv[argc-1]);
  else
    sprintf(file,"%s",argv[argc-1]);
  
#if DIM == 3
  xr = atof(argv[argc-4])*M_PI/180.0;
  yr = atof(argv[argc-3])*M_PI/180.0;
  zr = atof(argv[argc-2])*M_PI/180.0;
#else
  xr = atof(argv[argc-3])*M_PI/180.0;
  yr = atof(argv[argc-2])*M_PI/180.0;
#endif

  if(!(fp = fopen(file,"r"))){
    fprintf(stdout,"File %s does not exist\n",file);
    exit(-1);
  }

  sprintf(file,"%s.1",file);

  fp_new = stdout;
  
  while(fgets(buf,BUFSIZ,fp)){
      fputs(buf,fp_new);
      if(strstr(buf,"ELEMENT")){
	fgets(buf,BUFSIZ,fp);
	sscanf(buf,"%lf%lf%lf%lf",x,x+1,x+2,x+3);
	fgets(buf,BUFSIZ,fp);
	sscanf(buf,"%lf%lf%lf%lf",y,y+1,y+2,y+3);
#if DIM == 3
	fgets(buf,BUFSIZ,fp);
	sscanf(buf,"%lf%lf%lf%lf",z,z+1,z+2,z+3);
#endif
	for(i = 0; i < 4; ++i){
	  x1[i] = x[i]*cos(zr) - y[i]*sin(zr);
	  y1[i] = x[i]*sin(zr) + y[i]*cos(zr);
#if DIM == 3
	  z1[i] = z[i]*cos(yr) - x1[i]*sin(yr);
	  x1[i] = z[i]*sin(yr) + x1[i]*cos(yr);

	  y [i] = y1[i]*cos(xr) - z1[i]*sin(xr);
	  z1[i] = y1[i]*sin(xr) + z1[i]*cos(xr);
	  
	  y1[i] = y[i];
#endif
	}
	sprintf(buf," %lf %lf %lf %lf \n",x1[0],x1[1],x1[2],x1[3]);
	fputs(buf,fp_new);
	sprintf(buf," %lf %lf %lf %lf \n",y1[0],y1[1],y1[2],y1[3]);
	fputs(buf,fp_new);
#if DIM == 3
	sprintf(buf," %lf %lf %lf %lf \n",z1[0],z1[1],z1[2],z1[3]);
	fputs(buf,fp_new);
#endif
      }      
    }
  fclose(fp);
  fclose(fp_new);
 
  return 0;
}
    
